function [EigOut,NoEig] = MinResEigFA(X,MissingVal,MaxNo)
%Performs an iterative principal axes factor analysis as per Comrey (1966).
%Fits off diagonal correlations.  Performs repeated eigenvalue decompositions
%until convergence. 
%INPUTS
%X    		- An n (the variables the correlations are taken on)*m data matrix.
%MissingVal - An indicator for missing data values
%MaxNo 		- The maximum number of eigenvalues to be taken
%OUTPUTS
%EigOut  	- The output eigenvectors
%NoEig   	- The number of eigenvectors taken
%Version     Author            Date
%   0.10     Stephen France    04/01/2012
%   2.00     Stephen France    04/02/2016

EigOut=[];
NoEig=0;

P=+~(X==MissingVal);
[n,m]=size(X);
%Create correlation matrix
XStar=P.*(X-spmean(X,P,2)*ones(1,m));
XNorm=(sum(((XStar.^2).*P),2)).^0.5;
XNorm(XNorm==0)=1;
XStar=XStar./(XNorm*ones(1,m)); 
Res = (XStar.*P)*(XStar.*P)';
RunNo=1;
Run=true;
while (Run==true)&&(RunNo<=MaxNo)
  %Remove initial diagonal
  Res=Res-diag(diag(Res));
  %Calculate factor loadings
  [U,D] = eig(Res);
  %Matlab doesn't guarantee order of eigenvalues
  [D,I] = sort(diag(D),'descend');
  U = U(:,I);
  %Communalities are squares of factor loading
  F=U(:,1)*(D(1,1).^0.5);
  Eig=D(1);
  if Eig>0
    EigOut=[EigOut;D(1)];
    NoEig=NoEig+1;
    Est=F*F';
    Res=Res-Est;
  else
    Run=false;
  end
  RunNo=RunNo+1;
end


