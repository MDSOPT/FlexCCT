function [LBVal,UBVal,MeanVal,MedianVal]=CreateBootstrapStats(Technique,Samples,NoVar,NoResample,NoData,Alpha,ParamEst)
%Creates a set of bootstrap statistics for a single CCT variable.  Utilizes
%a set of samples (without replacement) and calculates confidence
%intervals, mean, and median.
%INPUTS
%Technique  - 0 Percentile Bootstrap, 1 Centered Percentile Bootstrap, 2 t-test Bootstrap, 3 Jackknife
%Samples    - A NoVar*NoResamples matrix of resamples
%NoVar      - The number of variables being sampled
%NoResample - The number of resamples taken for each variable
%NoData     - The sample size for each variable
%Alpha      - The value of alpha, the Type I error, for created confidence intervals
%ParamEst   - A NoVar*1 vector of the point estimates of the model parameters
%Bootstrap  - True/false indicators on whether or not to bootstap the variable
%OUTPUTS
%LBVal      - A NoVar*1 vector of the lower bounds for confidence intervals
%UBVal      - A NoVar*1 vector of the upper bounds for confidence intervals
%MeanVal    - A NoVar*1 vector of the mean of the confidence intervals
%MedianVal    - A NoVar*1 vector of the median of the confidence intervals
%Reliability for continuous cultural consensus analysis.  This procedure
%returns the continuous reliability metric iota, as defined by Janson and Olson (2001)
%and also the consensus adjusted reliability metric, as defined by France
%and Batchelder.  Works for all models except for the additive item easiness model
%Version     Author            Date
%   2.00     Stephen France    04/02/2016
switch Technique
  case {0,1,3}
    %This is the basic percentile bootstrap
    LBPos=round(NoResample*Alpha);
    %On the slight chance that this results in a 0!
    LBPos=max(1,LBPos);
    UBPos=round(NoResample*(1-Alpha));
    UBPos=min(NoResample,UBPos);
    if (Technique==0)||(Technique==3)
    
      %Both percentile bootstrap and jackknife calculate mean from data
      MeanVal=mean(Samples,2);
      if mod(NoResample,2)==0
       %Even median
       MedianVal=Samples(:,round(((NoResample-1)/2)*0.5))+Samples(:,round(((NoResample+1)/2)*0.5));
      else
       %Odd median
       MedianVal=Samples(:,round(NoResample/2));
      end
      if (Technique==0)
        %Calculate parameter values at the set percentile values for
        %percentage bootstrap
        LBVal=Samples(:,LBPos);
        UBVal=Samples(:,UBPos);
      else
        %Calculate the standard error and use normal distribution for
        %Jackknife
        StdVal=(1/(NoVar-1))*sum((Samples-repmat(ParamEst,1,NoResample)).^2,2);
        StdVal=StdVal.^0.5;
        NormLB =  norminv(Alpha);
        NormUB =  norminv(1-Alpha);
        LBVal=MeanVal+StdVal*NormLB;
        UBVal=MeanVal+StdVal*NormUB;
      end
    else
      %Centered bootstrap
      LBVal=2*ParamEst-Samples(:,UBPos);
      UBVal=2*ParamEst-Samples(:,LBPos);
      MedianVal=ParamEst;
      MeanVal=2*ParamEst-mean(Samples,2);
    end
  case 2 
    %This is the t-bootstrap.  First need to estimate the standard error
    MeanVal=mean(Samples,2);
    StDev=(std(Samples'))';
    %Use the number of items to calulate the statistics to estimate
    %standard error
    StError=StDev;
    %Calculate the estimated t distribution
    t=(Samples-repmat(ParamEst,1,NoResample))./repmat(StError,1,NoResample);
    %No find the t value for each of the parameter rows.  Degrees of
    %freedom is N-1
    tLB =  tinv(Alpha,NoData-1);
    tUB =  tinv(1-Alpha,NoData-1);
    %Find first position in row that is greater than the constraint
    [r,c,val]=find(t'>tLB);
    LBPos=r(c-[0;c(1:size(c,1)-1)]==1);
    LPos=max(LBPos,2);
    LBPosLeft=max(LBPos-1,1);
    Ind=spconvert([[NoResample,NoVar,0];[LBPos,[1:NoVar]',ones(NoVar,1)]]);
    Temp=Samples';
    Res1=Temp(find(Ind));
    Ind=spconvert([[NoResample,NoVar,0];[LBPosLeft,[1:NoVar]',ones(NoVar,1)]]);
    Res2=Temp(find(Ind));
    LBVal=(Res1+Res2)./2;
    [r,c,val]=find((1-t'<tUB)); %Use minus one to put 1s to the right
    UBPos=r(c-[0;c(1:size(c,1)-1)]==1);
    UBPos=min(NoResample-UBPos,NoResample-1);
    UBPosRight=min(UBPos+1,NoResample);
    Ind=spconvert([[NoResample,NoVar,0];[UBPos,[1:NoVar]',ones(NoVar,1)]]);
    Res1=Temp(find(Ind));
    Ind=spconvert([[NoResample,NoVar,0];[UBPosRight,[1:NoVar]',ones(NoVar,1)]]);
    Res2=Temp(find(Ind));
    clear Temp
    UBVal=Res1+Res2./2;

    %The t-distribution is symmetric, so the mean and median are equal
    MedianVal=ParamEst;
    MeanVal=ParamEst;
end

