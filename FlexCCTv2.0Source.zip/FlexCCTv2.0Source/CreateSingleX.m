function [X] = CreateSingleX(X,NoTraits,DATCombine,DATStandard,MissingVal)
%Creates a single X matrix from possibly multitrait data by either adding the 
%data values across traits or using correspondence analysis.
%INPUTS
%X - An n rater*(m item * NoTraits) data matrix to be decomposed
%NoTraits - The number of individual traits in the data
%DATCombine - How to combine traits (0 - add traits, 1 - correspondence analysis)
%DATStandard - The transformation to apply to combined data. 
%            - 0 No transform, 1 standardize, 2 range scale, 3 log transform
%MissingVal  - The missing data indicator for the data
%OUTPUTS
%X - The combined and transformed n*m ratings matrix.
%Version     Author            Date
%   0.10     Stephen France    01/30/2014
%   2.00     Stephen France    04/01/2016

%Raise an error as the number of columns needs to be divisible by the
%number of attributes
[n,tm]=size(X);

if NoTraits==0
  Exception = MException('InputError:MinimumTraits',...
              'The number of traits must be at least one.');
  throw(Exception);
end
if mod(tm,NoTraits)>0
  Exception = MException('InputError:DivisibleColumns',...
              'The number of columns must be divisible by the number of attributes.');
  throw(Exception);       
end

if (NoTraits==1)&&(DATCombine==1)
  Exception = MException('InputError:CorrespondanceTraits',...
              'The multiple correspondance analysis method of combining data requires more than one trait.');
  throw(Exception);   
end

m=tm/NoTraits;

%Calculate the single X from the multitrait X
if (NoTraits>1)
  %Add traits
  XNew=zeros(n,m);
  XMissing=zeros(n,m);
  %Work through, adding items for traits
  for j=1:m
    XNew(:,j)=sum(X(:,(j-1)*NoTraits+1:j*NoTraits),2);
    %If one trait is missing then all of the traits are considered to be
    %missing
    XMissing(:,j)=sum(X(:,(j-1)*NoTraits+1:j*NoTraits)==MissingVal,2); %#ok<AGROW>
  end
  XAdd=XNew;
  if DATCombine==0
    X=XAdd;
  else
    %Ensure that the data are integer
    if sum(sum(mod(X,1)))>0
      Exception = MException('InputError:NonIntegerData',...
              'Your data contain noninteger variables.  Integer values are required for correspondence analysis');
      throw(Exception);  
    end
    %Get the range of categorical variables
    MinX=X;
    MinX(find(X==MissingVal))=max(max(X));
    MaxX=X;
    MaxX(find(X==MissingVal))=min(min(X));  
    Categories=[min(min(MinX)):max(max(MaxX))];
    NoCategories=size(Categories,2);  
      
    %Firstly stack the data, so that each combination of user and question
    %is an observation.  Matrix is (n*m)*t
    Tempx=reshape(X',NoTraits,n*m)';
    Tempx2=zeros(n*m,NoTraits*NoCategories);
    %Now need to split each of the traits
    for t=1:NoTraits
      %Match the traits. 1st repmat extends the actual trait values across,
      %2nd extends the template down
      Tempx2(:,1+(t-1)*NoCategories:t*NoCategories)=repmat(Tempx(:,t),1,NoCategories)==repmat(Categories,n*m,1);
    end 
    %Now perform correspondance analysis on the remaining data;
    Correspond = Tempx2/sum(sum(Tempx2));
    ColTotal=sum(Correspond,1);
    RowTotal = sum(Correspond,2);
    if isempty(find(ColTotal==0))==0
      Exception = MException('CAError:ColTotals',...
              'Some column totals for the correspondence table are equal to 0.  Cannot perform multiple correspondence analysis.');
      throw(Exception);  
    end
    if isempty(find(RowTotal==0))==0
      Exception = MException('CAError:RowTotals',...
              'Some row totals for the correspondence table are equal to 0.  Cannot perform multiple correspondence analysis.');
      throw(Exception);  
    end
    
    %Calculate the chi-squared distances
    ChiSqDist = sqrt(inv(diag(RowTotal)))*(Correspond-RowTotal*ColTotal)*sqrt(inv(diag(ColTotal)));
    [Z,D,U] = svd(ChiSqDist);
    XNew = inv(diag(RowTotal))*sqrt(diag(RowTotal))*Z*D;
    SingleTrait=XNew(:,1);
    %Put in a similar range to additive data
    X=reshape(SingleTrait',m,n)';
     
    MinXAdd=min(min(XAdd));MaxXAdd=max(max(XAdd));
    MinX=min(min(X));MaxX=max(max(X));
    X=MinXAdd+(X-MinX)*(MaxXAdd-MinXAdd)/(MaxX-MinX);
  end
  %Ensure that missing values are still missing
  X=X.*(+(XMissing==0))+MissingVal.*(+(XMissing>0));
end

%Have single trait matrix, so standardize/normalize
XTemp=X;
XMissing=(X==MissingVal);
%Make missing values as NaN, so then we can use nan functions.
XTemp(XMissing)=NaN;

switch DATStandard
  case 1
    %Standardize to z variable for each individual column
    MeanX=nanmean(XTemp,1);
    StdX=nanstd(XTemp,1);
    X=(X-repmat(MeanX,n,1))./(repmat(StdX,n,1));
  case 2
    %Range scale for each individual columnss
    MinX=nanmin(XTemp,[],1);
    MaxX=nanmax(XTemp,[],1);
    X=(X-repmat(MinX,n,1))./(repmat(MaxX,n,1)-repmat(MinX,n,1));
  case 3
    %Perform the log transform
    X=log(X);
end

%Ensure that the missing values are kept
X(XMissing)=MissingVal;
end

