function [IBOut] = ItemBootstrap(Bootstrap,X,EstMethod,BiasType,OptMethod,FixParams,OptParams,XSpec,DMax,IEMax,IBOut)
%Bootstrap/Jackknife for item based parameters z and IE.  Performs resampling and then from parameter estimates of
%resamples, builds confidence interval information.
%INPUTS
%Bootstrap - HasItemBootstrap 1 if CIs for raters, 0 otherwise
%          - HasRaterBootstrap 1 if CIs for raters, 0 otherwise
%          - Technique - The bootstrap technique
%          - Alpha - The value of alpha, the Type I error, for created confidence intervals
%          - NoResample - The number of resamples for the bootstrap/jackknife
%          - Technique - %  0 Percentile Bootstrap, 1 Centered Percentile Bootstrap, 2 t-test Bootstrap, 3Jackknife
%          - CIz,CIIE, CId, CIbadd, CIbmult - 1 if CI for variable, 0 otherwisw
%X         - The n rater*m item ratings matrix
%EstMethod - The estimation method
%          - 0 Average value
%          - 1 Minimum Residual factor analysis
%          - 2 Maximum likelihood estimation
%          - 3 Item difficulty model no 1 Additive Variances
%          - 4 Item difficulty model no 2 dij=alpha(i)*beta(j)
%          - 5 Item difficulty model no 3 dij=alpha(i)+beta(j)   
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          - 3 Fit additive and multiplicative bias
%          Currently bias 1 and 2 are only available for estimation methods
%          0,2,3,4, and 5
%          - 4 Fit a bias that declines linearly in proportion to the
%          remaining length of interval         
%OptMethod - 0 Fixed point: Fixed point estimation.
%          - 1 Two Stage Fixed Point. The values of z and d are estimated first, followed by other parameters.
%          - 2 Derivative Free: Standard MATLAB routine.
%          - 3 Gradient: MATLAB Gradient descent optimization, utilizing first order derivatives
%FixParams - A row vector containing the parameter fixing/identifiability parameters.  See ContinuousCCT3 header for more details 
%OptParms  - A row vector containing the optimization parameters.  See ContinuousCCT3 header for more details
%MissingVal- The indicator for a missing value boundary of max(abs-1)
%DMax      - The maximum value of D
%IEMax     - The maximum value of the item easiness IE
%OUTPUTS
%IBout 	   - An outout structure containing confidence interval information
%		   - zLB, zUB,zMean,zMedian - Confidence interval lower bound, upper bound, mean, and median for z
%	       - IELB, IEUB, IEMean,IEMedian - Confidence interval lower bound, upper bound, mean, and median for IE
%Version     Author            Date
%   2.00     Stephen France    04/02/2016
[n,m]=size(X);

%for Jacknife if the number of resamples is not equal to m,
%we need to set random remove
if Bootstrap.Technique==3
  %Can only remove each rater once
  if Bootstrap.NoResample>n
    Bootstrap.NoResample=n;
  end
  RemoveNos=randperm(n);
  RemoveNos=RemoveNos(1:Bootstrap.NoResample);
end

%Create resamples, sampling users with replacement from X.
if Bootstrap.CIz==true
  zSample=zeros(Bootstrap.NoResample,m);
end
if Bootstrap.CIIE==true
  IESample=zeros(Bootstrap.NoResample,m);
end

for i=1:Bootstrap.NoResample
  drawnow();
  %Sample rows with replacement from X
  if Bootstrap.Technique==3
    %remove ith row for the jackknife sample
    XRS=[X(1:RemoveNos(i)-1,:);X(RemoveNos(i)+1:n,:)];
  else
    XRS=X(floor(rand(1,n)*n+1),:);
  end
  %Now perform the CCT
  switch OptMethod
  case 1
    %Gradient
    [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT3(XRS,EstMethod,BiasType,FixParams,OptParams,XSpec,1,DMax,IEMax);
  case 2
    %Derivative free
    [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT3(XRS,EstMethod,BiasType,FixParams,OptParams,XSpec,0,DMax,IEMax);
  case 3
    %Fixed point optimization
    [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT5(XRS,EstMethod,BiasType,FixParams,OptParams,XSpec,DMax,IEMax);
  end
  
  if Bootstrap.CIz==true
    zSample(i,:)=z;
  end
  if Bootstrap.CIIE==true
    IESample(i,:)=QE;
  end
end

%Order the values into percentiles
if Bootstrap.CIz==true
  zSample=sort(zSample,1);
  %CreateBootstrapStats assumes variables on rows and samples on columns,
  %so need to transpose
  [IBOut.zLB,IBOut.zUB,IBOut.zMean,IBOut.zMedian]=CreateBootstrapStats(Bootstrap.Technique,zSample',m,Bootstrap.NoResample,n,Bootstrap.Alpha,Bootstrap.z');
end
if Bootstrap.CIIE==true
  IESample=sort(IESample,1);
  [IBOut.IELB,IBOut.IEUB,IBOut.IEMean,IBOut.IEMedian]=CreateBootstrapStats(Bootstrap.Technique,IESample',m,Bootstrap.NoResample,n,Bootstrap.Alpha,Bootstrap.IE');
end



