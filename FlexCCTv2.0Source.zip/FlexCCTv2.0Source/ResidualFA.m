function [F,Residual] = ResidualFA(X,InitialMode,Epsilon,InitialF,MaxIter)
%Residual factor analysis using the Comrey and Al Ahumada (1964)
%algorithm.
%INPUTS
%X - An n*n data matrix to be decomposed
%InitialMode - The mode for the initial solution
%            - 0 A fixed soln, defaults to all entries equal to 0.5
%            - 1 A random soln, with all elements drawn from uniform - [0.1]
%Epsilon     - The convergence criteria
%InitialF 	 - An n*1 initial soln.  Defaults to a random solution from uniform
%distribution in range [0,1]
%MaxIter     - The maximum number of iterations
%PUTPUTS
%F 			 - (n*NFactor) - The factors to be extracted to approximate (F-X'X)
%Lambda 	 - (NFactor) - The values of the eigenvalues
%Residual    -  X-F'F
%Version     Author            Date
%   0.10     Stephen France    04/01/2012
%   2.00     Stephen France    04/02/2016
n=size(X,1);

X=X-diag(diag(X));

if ~exist('Epsilon','var')
  Epsilon=1e-6;
end

%Configure initial solution
if (InitialMode == 0)
  %Fixed solution
  if ~exist('InitialF','var')
    InitialF=ones(n,1).*0.5;
  end
else
  %Random solution
  InitialF=rand(n,1);
end

Terminate=false;
A0=InitialF;
while (Terminate==false)
  Num=X.*(ones(n,1)*A0');
  Denom=(ones(n,1)*(A0'.^2));
  Denom=Denom-diag(diag(Denom));
  A1=sum(Num,2)./sum(Denom,2);
  Num=X.*(ones(n,1)*A1');
  Denom=(ones(n,1)*(A1'.^2));
  Denom=Denom-diag(diag(Denom));
  A2=sum(Num,2)./sum(Denom,2);
  RatioSSQ=(A2.^2)./(A1.^2);
  A0=A1.*(RatioSSQ.^(1/4));
  %Check the termination criteria
  Chk=abs(abs(A1)-abs(A2))<Epsilon;
  if (sum(Chk)==n)
    %All differences are less than Epsilon
    Terminate=true;
  end
end

%Return the average of A1 and A2
F=(A1+A2)./2;

SqF=F*F';
Residual=X-(SqF-diag(diag(SqF)));

  
  
  






