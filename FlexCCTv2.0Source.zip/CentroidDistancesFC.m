function [Dist,NewU,ChangeU] = CentroidDistancesFC(X,P,zAll,AddBiasAll,MultBiasAll,p1,p2,Fuzzyq,CurU)
%Calculate distances between a set of items and a set of centroids.
%If missing data are present for an item, then the dimensions for which
%data are missing are ignored (this is the same for all clusters).  The
%cluster centroids cannot contain missing data.  Calculate the fuzzy
%assignment matrix U.
%INPUTS
%X - Then user * m item input data matrix.
%P - An n*m indicator matrix of missing values for X 1 Present 0 Missing (user *
%item)
%zAll - A No clusters l*m matrix of cluster centroids
%AddBiasAll - An n*l matrix of additive bias values
%MultBiasAll - An n*l matrix of multiplicative bias values
%p1 - The inner power p1 for Minkowski metric
%p2 - The outer power p2 for Minkowski metric
%Fuzzyq - The fuzzy clustering parameter q
%CurU - Optional, current fuzzy cluster assignments
%OUTPUTS
%D - The n*l user * cluster distance matrix
%NewU - The new fuzzy assignment matrix U
%ChangeU - The change in the fuzzy assignement matrix U
%Version     Author            Date
%   0.10    Stephen France    10/13/2013
%   2.00    Stephen France    04/01/2016

%find the size variables
[n,m]=size(X);
l=size(zAll,1);  %l is the number of clusters

[Dist] = zeros(n,l);  %D is users*clusters

%Calculate distances for each user between all centroids
% for i=1:n
%   XMap=ones(l,1)*X(i,:);
%   PMap=ones(l,1)*P(i,:);
%   %No contribution from 
%   SubD=sum((PMap.*(XMap-AddBiasAll(i,:)'*ones(1,m)-(MultBiasAll(i,:)'*ones(1,m)).*zAll)).^p1,2);
%   Dist(i,:)=(SubD.^p2)'; 
% end

for k=1:l
  zAdj=repmat(AddBiasAll(:,k),1,m)+MultBiasAll(:,k)*zAll(k,:);
  SubD=sum(P.*(X-zAdj).^p1,2);
  Dist(:,k)=(SubD.^p2)'; 
end

%Calculate the value of U(ik) for each cluster k
%using U(ik)=1/(sum_{k2}((dik/dik2).^(2./(Fuzzyq-1))))
FuzzyPower=2./(Fuzzyq-1);
NewU=zeros(n,l);
for k=1:l
  DistRatio=repmat(Dist(:,k),1,l)./Dist;
  NewU(:,k)=1./sum(DistRatio.^FuzzyPower,2);
end

%Can only calculate the change in U if it is not the initial run
if exist('CurU','var')
  ChangeU=sum(sum(abs(NewU-CurU)));
end

