% The Advanced form contains options for variable identifiablity, confidence intervals,
% and multiple culture options.
%Version     Author            Date
%   2.00     Stephen France    03/31/2016
function varargout = Advanced(varargin)
% ADVANCED MATLAB code for Advanced.fig
%      ADVANCED, by itself, creates a new ADVANCED or raises the existing
%      singleton*.
%
%      H = ADVANCED returns the handle to a new ADVANCED or the handle to
%      the existing singleton*.
%
%      ADVANCED('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ADVANCED.M with the given input arguments.
%
%      ADVANCED('Property','Value',...) creates a new ADVANCED or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Advanced_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Advanced_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE'cmdDefault Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Advanced

% Last Modified by GUIDE v2.5 20-Mar-2016 20:02:42

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Advanced_OpeningFcn, ...
                   'gui_OutputFcn',  @Advanced_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Advanced is made visible.
function Advanced_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Advanced (see VARARGIN)

% Choose default command line output for Advanced
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

set(hObject ,'WindowStyle','modal');
javaFrame = get(handle(hObject),'JavaFrame');
javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));

% UIWAIT makes Advanced wait for user response (see UIRESUME)
% uiwait(handles.Advanced);
% The available parameters depend on the bias type.



%Competencies dependent on estimation type
GUIEstMethod=getappdata(0,'EstMethod');
if (GUIEstMethod==1)||((GUIEstMethod==2))
  %Cannot fix z or d
  set(handles.cboFixz,'Value',1);
  set(handles.chkCIz,'Value',0);
  set(handles.cboFixz,'Enable','off');
  set(handles.chkCIz,'Enable','off');
  set(handles.cboFixd,'Value',1);
  set(handles.chkCId,'Value',0);
  set(handles.cboFixd,'Enable','off');
  set(handles.chkCId,'Enable','off');
else
  set(handles.cboFixd,'Value',getappdata(0,'Fixd'));
  set(handles.chkCId,'Value',getappdata(0,'CId'));
  set(handles.cboFixz,'Value',getappdata(0,'Fixz'));
  set(handles.chkCIz,'Value',getappdata(0,'CIz'));
  set(handles.cboFixd,'Enable','on')
  set(handles.chkCId,'Enable','on')
  set(handles.cboFixz,'Enable','on')
  set(handles.chkCIz,'Enable','on')

end
%Check for availability of biases
GUIBiasType=getappdata(0,'BiasType');
%Additive bias
if (GUIBiasType==1)||((GUIBiasType==3))
  set(handles.cboFixbA,'Value',1)
  set(handles.chkCIbA,'Value',0)
  %Disable the bias controls
  set(handles.cboFixbA,'Enable','off')
  set(handles.chkCIbA,'Enable','off')
else
  set(handles.cboFixbA,'Value',getappdata(0,'FixbA'));
  set(handles.chkCIbA,'Value',getappdata(0,'CIbA'));
  %Enable the bias controls
  set(handles.cboFixbA,'Enable','on')
  set(handles.chkCIbA,'Enable','on')
end

%Multiplicative bias
if (GUIBiasType==1)||((GUIBiasType==2))
  set(handles.cboFixbM,'Value',1)
  set(handles.chkCIbM,'Value',0)
   %Disable the bias controls
  set(handles.cboFixbM,'Enable','off')
  set(handles.chkCIbM,'Enable','off')
else
  set(handles.cboFixbM,'Value',getappdata(0,'FixbM'));
  set(handles.chkCIbM,'Value',getappdata(0,'CIbM'));
  %Enable the bias controls
  set(handles.cboFixbM,'Enable','on')
  set(handles.chkCIbM,'Enable','on')
end

%Item easiness only if estimation type is 4 or 5
%Multiplicative bias
if (GUIEstMethod<4)
  set(handles.chkCIIE,'Value',0)
  set(handles.chkCIIE,'Enable','off')
else
  set(handles.chkCIIE,'Value',getappdata(0,'CIIE'));
  set(handles.chkCIIE,'Enable','on')
end

set(handles.txtCIAlpha,'String',getappdata(0,'CIAlpha'));
set(handles.txtNoResamples,'String',getappdata(0,'NoResamples'));
set(handles.cboIntervalType,'Value',getappdata(0,'IntervalType'));

%Set the cluster biases
NoCultures=getappdata(0,'NoCultures');
set(handles.txtNoCultures,'String',NoCultures);
if NoCultures=='1'
  %The other clustering details are not enabled
  set(handles.txtNoClusteringRuns,'String','');
  set(handles.txtNoClusteringRuns,'Enable','off');
  set(handles.chkClusterBias,'Value',0);
  set(handles.chkClusterBias,'Enable','off');
else
  set(handles.txtNoClusteringRuns,'String',getappdata(0,'NoClusteringRuns'));
  set(handles.txtNoClusteringRuns,'Enable','on');
  set(handles.chkClusterBias,'Value',getappdata(0,'ClusterBias'));
  set(handles.chkClusterBias,'Enable','on');  
end

set(handles.cmdSave,'Enable','off')




% --- Outputs from this function are returned to the command line.
function varargout = Advanced_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in cmdDefault.
function cmdDefault_Callback(hObject, eventdata, handles)
% hObject    handle to cmdDefault (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


selection = MFquestdlg([0.3,0.5],'Are you sure that you would like to return to default settings?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes',
set(handles.cboFixz,'Value',2);
set(handles.cboFixd,'Value',2);
set(handles.cboFixbA,'Value',1);
set(handles.cboFixbM,'Value',1);
set(handles.chkCIz,'Value',0);
set(handles.chkCId,'Value',0);
set(handles.chkCIbA,'Value',0);
set(handles.chkCIbM,'Value',0);
set(handles.chkCIIE,'Value',0);
set(handles.txtCIAlpha,'string','0.05');
set(handles.txtNoResamples,'string','1000');
set(handles.cboIntervalType,'Value',1);
set(handles.txtNoCultures,'String','1');
cmdSave_Callback(hObject, eventdata, handles)
set(handles.cmdSave,'Enable','off')
case 'No'
return
end %switch




% --- Executes on button press in cmdSave.
function cmdSave_Callback(hObject, eventdata, handles)
% hObject    handle to cmdSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
setappdata(0,'Fixz',get(handles.cboFixz,'Value'));
setappdata(0,'Fixd',get(handles.cboFixd,'Value'));
setappdata(0,'FixbA',get(handles.cboFixbA,'Value'));
setappdata(0,'FixbM',get(handles.cboFixbM,'Value'));
setappdata(0,'CIz',get(handles.chkCIz,'Value'));
setappdata(0,'CIIE',get(handles.chkCIIE,'Value'));
setappdata(0,'CId',get(handles.chkCId,'Value'));
setappdata(0,'CIbA',get(handles.chkCIbA,'Value'));
setappdata(0,'CIbM',get(handles.chkCIbM,'Value'));
setappdata(0,'CIAlpha',get(handles.txtCIAlpha,'String'));
setappdata(0,'NoResamples',get(handles.txtNoResamples,'String'));
setappdata(0,'IntervalType',get(handles.cboIntervalType,'Value'));
%Save the cluster details
setappdata(0,'NoCultures',get(handles.txtNoCultures,'String'));
setappdata(0,'NoClusteringRuns',get(handles.txtNoClusteringRuns,'String'));
setappdata(0,'ClusterBias',get(handles.chkClusterBias,'Value'));

set(handles.cmdSave,'Enable','off')

% --- Executes on button press in chkMultipleStag.
function chkMultipleStag_Callback(hObject, eventdata, handles)
% hObject    handle to chkMultipleStag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkMultipleStag
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes on selection change in cboFixz.
function cboFixz_Callback(hObject, eventdata, handles)
% hObject    handle to cboFixz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboFixz contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboFixz
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

if getappdata(0,'OptMethod')==3
  %z and d default to 1, but only if allowed.
  if get(handles.cboFixz,'Value')==4
    if getappdata(0,'EstMethod')>2
      set(handles.cboFixz,'Value',2);  %partial variable fix
    else
      set(handles.cboFixz,'Value',1) %No variable fix
    end
    message=sprintf('FixAverage identifiability not allowed for fixed point optimization.  FixAverage identifiability value has been returned to its default value.\nClick the OK button to continue.');
    h=msgbox(message,'FlexCCT Message');
    javaFrame = get(handle(h),'JavaFrame');
    javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
    uiwait(h);
  end
end
  

% --- Executes during object creation, after setting all properties.
function cboFixz_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboFixz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on selection change in cboFixd.
function cboFixd_Callback(hObject, eventdata, handles)
% hObject    handle to cboFixd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboFixd contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboFixd
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end
if getappdata(0,'OptMethod')==3
  %z and d default to 1, but only if allowed.
  if get(handles.cboFixd,'Value')==4
    if getappdata(0,'EstMethod')>2
      set(handles.cboFixd,'Value',2);  %partial variable fix
    else
      set(handles.cboFixd,'Value',1) %No variable fix
    end
    message=sprintf('FixAverage identifiability not allowed for fixed point optimization.  FixAverage identifiability value has been returned to its default value.\nClick the OK button to continue.');
    h=msgbox(message,'FlexCCT Message');
    javaFrame = get(handle(h),'JavaFrame');
    javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
    uiwait(h);
  end
end

% --- Executes during object creation, after setting all properties.
function cboFixd_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboFixd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cboFixbA.
function cboFixbA_Callback(hObject, eventdata, handles)
% hObject    handle to cboFixbA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboFixbA contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboFixbA
HasFixAdd=(get(handles.cboFixbA,'Value')==2)||(get(handles.cboFixbA,'Value')==3);
HasFixMult=(get(handles.cboFixbM,'Value')==2)||(get(handles.cboFixbM,'Value')==3);
ResetValue=false;
if HasFixAdd&&HasFixMult
  message = sprintf('Cannot have partial/full fixes on both additive and multiplicative biases. Identifiability value has been returned to its default value.\nClick the OK button to continue.');
    h=msgbox(message,'FlexCCT Message');
    javaFrame = get(handle(h),'JavaFrame');
    javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
    uiwait(h);
  ResetValue=true;
else
  if (getappdata(0,'OptMethod')==3)&&(get(handles.cboFixbA,'Value')==4)
    message=sprintf('FixAverage identifiability not allowed for fixed point optimization.  FixAverage identifiability value has been returned to its default value.\nClick the OK button to continue.');
    h=msgbox(message,'FlexCCT Message');
    javaFrame = get(handle(h),'JavaFrame');
    javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
    uiwait(h);
    ResetValue=true;
  end
end

if ResetValue==true
  set(handles.cboFixbA,'Value',1) %No variable fix
end

if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end


% --- Executes during object creation, after setting all properties.
function cboFixbA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboFixbA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cboFixbM.
function cboFixbM_Callback(hObject, eventdata, handles)
% hObject    handle to cboFixbM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboFixbM contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboFixbM
HasFixAdd=(get(handles.cboFixbA,'Value')==2)||(get(handles.cboFixbA,'Value')==3);
HasFixMult=(get(handles.cboFixbM,'Value')==2)||(get(handles.cboFixbM,'Value')==3);
ResetValue=false;
if (HasFixAdd&&HasFixMult)
  message = sprintf('Cannot have partial/full fixes on both additive and multiplicative biases. Identifiability value has been returned to its default value.\nClick the OK button to continue.');
  h=msgbox(message,'FlexCCT Message');
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h);
  ResetValue=true;
else
  if (getappdata(0,'OptMethod')==3)&&(get(handles.cboFixbM,'Value')==4)
    message=sprintf('FixAverage identifiability not allowed for fixed point optimization.  FixAverage identifiability value has been returned to its default value.\nClick the OK button to continue.');
    h=msgbox(message,'FlexCCT Message');
    javaFrame = get(handle(h),'JavaFrame');
    javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
    uiwait(h);
    ResetValue=true;
  end
end

if ResetValue==true
  set(handles.cboFixbM,'Value',1) %No variable fix
end

if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes during object creation, after setting all properties.
function cboFixbM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboFixbM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chkCIz.
function chkCIz_Callback(hObject, eventdata, handles)
% hObject    handle to chkCIz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkCIz
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end


% --- Executes on button press in chkCId.
function chkCId_Callback(hObject, eventdata, handles)
% hObject    handle to chkCId (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkCId
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end


% --- Executes on button press in chkCIbA.
function chkCIbA_Callback(hObject, eventdata, handles)
% hObject    handle to chkCIbA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkCIbA
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end


% --- Executes on button press in chkCIbM.
function chkCIbM_Callback(hObject, eventdata, handles)
% hObject    handle to chkCIbM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkCIbM
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end


% --- Executes on button press in chkCIIE.
function chkCIIE_Callback(hObject, eventdata, handles)
% hObject    handle to chkCIIE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkCIIE
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end



function txtCIAlpha_Callback(hObject, eventdata, handles)
% hObject    handle to txtCIAlpha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtCIAlpha as text
%        str2double(get(hObject,'String')) returns contents of txtCIAlpha as a double
Alpha=str2double(get(handles.txtCIAlpha,'string'))
if isnan(Alpha)==1
  set(handles.txtCIAlpha,'string','0.05');
else
  if (Alpha<=0)||(Alpha>1)
    set(handles.txtCIAlpha,'string','0.05');
  end
end
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes during object creation, after setting all properties.
function txtCIAlpha_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtCIAlpha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cboIntervalType.
function cboIntervalType_Callback(hObject, eventdata, handles)
% hObject    handle to cboIntervalType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboIntervalType contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboIntervalType
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes during object creation, after setting all properties.
function cboIntervalType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboIntervalType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtNoResamples_Callback(hObject, eventdata, handles)
% hObject    handle to txtNoResamples (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtNoResamples as text
%        str2double(get(hObject,'String')) returns contents of txtNoResamples as a double
NoResamples=str2double(get(handles.txtNoResamples,'string'));
%if the value is less than zero or not a number change it to default one 
if NoResamples>=1
  %do nothing unless not integer
  RoundNoResamples=round(NoResamples);
  if RoundNoResamples~=NoResamples
    set(handles.txtNoResamples,'string',RoundNoResamples);
  end
else
    set(handles.txtNoResamples,'string',1000);
end
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes during object creation, after setting all properties.
function txtNoResamples_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtNoResamples (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtNoCultures_Callback(hObject, eventdata, handles)
% hObject    handle to txtNoCultures (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtNoCultures as text
%        str2double(get(hObject,'String')) returns contents of txtNoCultures as a double
NoCultures=str2double(get(handles.txtNoCultures,'string'));
%if the value is less than zero or not a number change it to default one 
if NoCultures>=1
  %do nothing unless not integer
  RoundNoCultures=round(NoCultures);
  if RoundNoCultures~=NoCultures
    set(handles.txtNoCultures,'string',RoundNoCultures);
  end
else
  set(handles.txtNoCultures,'string',1);
end
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end
%Now reset the enabling of the cluster options based on the cultures
NoCultures=str2double(get(handles.txtNoCultures,'string'));
if NoCultures==1&& strcmp(get(handles.txtNoClusteringRuns,'Enable'),'on')==1
  %Disable the cultures
  set(handles.txtNoClusteringRuns,'String','');
  set(handles.txtNoClusteringRuns,'Enable','off');
  set(handles.chkClusterBias,'Value',0);
  set(handles.chkClusterBias,'Enable','off');
end
if NoCultures>1&& strcmp(get(handles.txtNoClusteringRuns,'Enable'),'off')==1
  %Enable the cultues
  set(handles.txtNoClusteringRuns,'String','10');
  set(handles.txtNoClusteringRuns,'Enable','on');
  set(handles.chkClusterBias,'Enable','on');  
end
  
  


% --- Executes during object creation, after setting all properties.
function txtNoCultures_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtNoCultures (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtNoClusteringRuns_Callback(hObject, eventdata, handles)
% hObject    handle to txtNoClusteringRuns (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtNoClusteringRuns as text
%        str2double(get(hObject,'String')) returns contents of txtNoClusteringRuns as a double
NoClusteringRuns=str2double(get(handles.txtNoClusteringRuns,'string'));
%if the value is less than zero or not a number change it to default one 
if NoClusteringRuns>0
    %do nothing
else
    set(handles.txtNoClusteringRuns,'string','10');
end

if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes during object creation, after setting all properties.
function txtNoClusteringRuns_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtNoClusteringRuns (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chkClusterBias.
function chkClusterBias_Callback(hObject, eventdata, handles)
% hObject    handle to chkClusterBias (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkClusterBias
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end


% --- Executes when user attempts to close Advanced.
function Advanced_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to Advanced (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = MFquestdlg([0.3,0.5],'Are you sure that you would like to close the advanced settings form?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes',
delete(hObject);
case 'No'
return
end %switch


% --- Executes during object creation, after setting all properties.
function uipIndentify_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipIndentify (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
