function [Dist,NewAssign,ChAssign,Improve] = CentroidDistances(X,P,BiasType,zAll,AddBiasAll,MultBiasAll,p1,p2,CurAssign,MinX,MaxX)
%Calculate distances between a set of items and a set of centroids.
%If missing data are present for an item, then the dimensions for which
%data are missing are ignored (this is the same for all clusters).  The
%cluster centroids cannot contain missing data
%INPUTS
%X - Then user * m item input data matrix.
%P - An n*m indicator matrix of missing values for X 1 Present 0 Missing (user *
%item)
%zAll - A No clusters l*m matrix of cluster centroids
%AddBiasAll - An n*l matrix of additive bias values
%MultBiasAll - An n*l matrix of multiplicative bias values
%p1 - The inner power p1 for Minkowski metric
%p2 - The outer power p2 for Minkowski metric
%CurAssign - Optional, current cluster assignments
%MinX - For weighted bias, the minimum value of X
%MaxX - For weighted bias, the maximum value of X
%OUTPUTS
%Dist - The n*l user * cluster distance matrix
%NewAssign - An n*1 vector of new cluster assignments
%ChAssign - An n*1 vector, true if membership changed, false otherwise
%Improve - An n*1 vector containing improvements in distance for each rater
%Version     Author            Date
%   0.10     Stephen France    08/27/2012
%   2.00     Stephen France    03/31/2016


%find the size variables
[n,m]=size(X);
l=size(zAll,1);

[Dist] = zeros(n,l);

%Calculate distances for each user between all centroids
% for i=1:n
%   XMap=ones(l,1)*X(i,:);
%   PMap=ones(l,1)*P(i,:);
%   %No contribution from 
%   SubD=sum((PMap.*(XMap-AddBiasAll(i,:)'*ones(1,m)-(MultBiasAll(i,:)'*ones(1,m)).*zAll)).^p1,2);
%   Dist(i,:)=(SubD.^p2)';
% end

for k=1:l
  switch BiasType
    case 0
      zAdj=ones(n,1)*zAll(k,:);
    case 1
      zAdj=AddBiasAll(:,k)*ones(1,m)+ones(n,1)*zAll(k,:);
    case 2
      zAdj=MultBiasAll(:,k)*zAll(k,:);
    case 3
      zAdj=AddBiasAll(:,k)*ones(1,m)+MultBiasAll(:,k)*zAll(k,:);
    case 4
      %Adjusted biases
      BiasFull=(AddBiasAll(:,k))*ones(1,m);
      BiasPos=((AddBiasAll(:,k)>0)*ones(1,m));
      WeightedBias=BiasFull.*(BiasPos.*(ones(n,1)*((MaxX-zAll(k,:))./(MaxX-MinX)))+(1-BiasPos).*(ones(n,1)*((zAll(k,:)-MinX)./(MaxX-MinX))));
      zAdj=WeightedBias+MultBiasAll(:,k)*zAll(k,:);
  end
  SubD=sum(P.*(X-zAdj).^p1,2);
  Dist(:,k)=(SubD.^p2)';
end

%Calculate the cluster assignments
[C,NewAssign]=min(Dist,[],2);

%If current assignments exist then 
if exist('CurAssign','var')&&(~isempty(CurAssign))
  ChAssign=+~(CurAssign==NewAssign);
  Improve=zeros(n,1);
  if sum(ChAssign)>0
    ChangedIndexes=find(ChAssign);
    NoChanged=size(ChangedIndexes,1);
    CurIndexes=[[l,n,0];[CurAssign(ChangedIndexes),ChangedIndexes,ones(NoChanged,1)]];
    NewIndexes=[[l,n,0];[NewAssign(ChangedIndexes),ChangedIndexes,ones(NoChanged,1)]];
    %Fin the improvement in SSQ by choosing the new assignments
    CurLogical=logical(spconvert(CurIndexes));
    NewLogical=logical(spconvert(NewIndexes));
    %Create comparison for distances.  Use D' as logical indexing goes
    %columns then rows, while we want rows then columns
    DistPrime=Dist';
    Improve(ChangedIndexes)=DistPrime(CurLogical)-DistPrime(NewLogical);
  end
end

