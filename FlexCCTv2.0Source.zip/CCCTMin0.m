function [f] = CCCTMin0(x,X,P,EstMethod,BiasType,FixParams,z,d,BiasCol,QE)
%Provides the function value for the continuous cultural consensus
%log likelihood function
%INPUTS
%x - The current value of the function parameters (F, but gone with Matlab
%notation) of length 2n*m*1
%X - The n rater*m item input matrix of ratings
%P - An n*m indicator matrix where pij=1 if xij is present and pij=0 if xij is missing.
%EstMethod - See header for ContinuousCCT3
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          - 3 Fit both additive and multiplicative bia
%FixParams - Fix parameters. A one by three array of items that contains
%          the following information.
%Fixz      - 0 Don't fix z at all
%          - -1 Fix z if an initial optimization run using EstMethod=2
%          - ItemNo (Partial fix).  Fix the value of z for the given item
%          number
%FixD      - 0 Don't fix D at all
%          - -1 Fix D if an initial optimization run using EstMethod=2
%          - UserNo (Partial fix).  Fix the  value of D for the given user
%          number
%FixAddBias- 0 Don't fix the additive bias at all
%          - -1 Fix the additive bias first before calculating the
%          multiplicative bias
%          - UserNo Partial fix of the additive bias.  Fix the value of additive
%          bias for the given rater
%          - -99 Set the average additive bias to be 0
%FixMultBias- 0 Don't fix the multiplicative bias at all
%          - -1 Fix the multiplicative bias first before calculating the
%          multiplicative bias
%          - UserNo Partial fix of the multiplicative bias.  Fix the value of additive
%          bias for the given rater
%          - -99 Set the average multiplicative bias to be 1
%Optional parameters passed if values are fixed
%  d - n*1 vector of competencies
%  z - a m*1 vector of answers
%  Bias - a n*1 vector of biases (if BiasType=0, i.e. no bias then all = 1)
%OUTPUTS
%f - The function value for x
%Version     Author            Date
%   0.10     Stephen France    04/01/2012
%   2.00     Stephen France    03/31/2016

%Start by collapsing x (z is a row vector so transform)
[n,m]=size(X);

Fixz=FixParams(1);Fixd=FixParams(2);
FixAddBias=FixParams(3);FixMultBias=FixParams(4);

VarCount=0;
if (EstMethod>0)
  switch Fixz
    case {0,-99}
      %z is freeform
      z=x(1:m)';
      VarCount=VarCount+m;
    case -1
    %z is already fixed and is not included in the optimization
    otherwise
      %z is the value for a single column item, which is to be fixed
      z=[x(1:Fixz-1);z;x(Fixz:m-1)]';
      VarCount=VarCount+m-1;
  end
end
  
%Estimate competency unless simple average
if (EstMethod>0)
  %d is estimated if not provided the procedure.
  switch Fixd
    case {0,-99}
      d=x(VarCount+1:VarCount+n);
      VarCount=VarCount+n;
    case -1
      %D is fixed and is not included in the optimization
    otherwise
      d=[x(VarCount+1:VarCount+Fixd-1);d;x(VarCount+Fixd:VarCount+n-1)];
      VarCount=VarCount+n-1;
  end
else
  d=ones(n,1);
end

if BiasType>0
  %Fit single set of biases
  if BiasType==1||BiasType==2
    Bias=x(VarCount+1:VarCount+n);
    VarCount=VarCount+n;
  elseif BiasType==3
    %Fit both biases together.  If one bias i
    switch FixAddBias
      case {0,-99}
        %Neither column of the bias is fixed
        AddBias=x(VarCount+1:VarCount+n);
        VarCount=VarCount+n;
      case {-1}
        %The additive bias is fixed and is passed to procedure
        AddBias=BiasCol;
      otherwise
        %A single value is fixed
        AddBias=[x(VarCount+1:VarCount+FixAddBias-1);BiasCol;x(VarCount+FixAddBias:VarCount+n-1)];
        VarCount=VarCount+n-1 ;
    end
    switch FixMultBias
      case {0,-99}
        %Neither column of the bias is fixed
        MultBias=x(VarCount+1:VarCount+n);
        VarCount=VarCount+n;
      case {-1}
        %The additive bias is fixed and is passed to procedure
        MultBias=BiasCol;
      otherwise
        %A single value is fixed
        MultBias=[x(VarCount+1:VarCount+FixMultBias-1);BiasCol;x(VarCount+FixMultBias:VarCount+n-1)];
        VarCount=VarCount+n-1; 
    end
    Bias=[AddBias,MultBias];
  end
end

if ~exist('QE','var')
  switch EstMethod
    case {0,2,6}
      %No question easyness in model
      QE=ones(1,m);
    case {3,4,5}
      %Question easyness model
      QE=x(VarCount+1:VarCount+m)';
  end
end


%Set the least squares term for 2
%Term 2 depends on the scaling constant used
switch BiasType
  case {0}
    InnerTerm=(X-ones(n,1)*z);
  case 1
    InnerTerm=(X-Bias*ones(1,m)-ones(n,1)*z);
  case 2
    InnerTerm=(X-Bias*z);  
  case 3
    InnerTerm=(X-(Bias(:,1)*ones(1,m))-Bias(:,2)*z);
end

%Term 1 uses the standard item competency for all terms
switch EstMethod
  case {0,2}
    %Basic maximum likelihood model
    Term1=((d*ones(1,m))./(2*pi)).^0.5;
    Term2=(d*ones(1,m)).*(InnerTerm.^2)./2;
  case {3}
    %Item difficulty variance model
    Term1=((d*QE)./((d*ones(1,m)+ones(n,1)*QE)*2*pi)).^0.5;
    Term2=(d*QE).*(InnerTerm.^2)./((d*ones(1,m)+ones(n,1)*QE)*2);
  case {4}
    %Scalar item difficulty
    Term1=((d*QE)./(2*pi)).^0.5;
    Term2=(d*QE).*(InnerTerm.^2)./2;
  case {5}
    %Additive item difficulty
    Term1=(((d*ones(1,m))+(ones(n,1)*QE))./(2*pi)).^0.5;
    Term2=((d*ones(1,m))+(ones(n,1)*QE)).*(InnerTerm.^2)./2;
  case {6}
    %Weber Fechner law
    Term1=((d*ones(1,m))./(2*pi*(ones(n,1)*(z.^p)))).^0.5;
    Term2=(d*ones(1,m)).*(InnerTerm.^2)./(2.*ones(n,1)*(z.^p));
end
Term1=log(Term1);

Total=(Term1-Term2).*P;
f=-sum(sum(Total));

end

