function [VMatrix,LeanMiss,FatMiss,RowClusters,ColClusters] = VisCONCOR(X,NRowClus,NColClus,SimParams,Converge,MaxIter,EdgeCorrect,MissingVal)
%Creates a CONCUR visualization of binary instance data.  The user supplies
%the number of row clusters and the number of column clusters.  The
%procedure then calls CONCUR and visualizes the resulting clusters.
%INPUTS
%X - An n*m input matrix
%NRowClus - The number of row clusters
%NColClus - The number of column clusters
%        1 Cluster the columns
%SimParms - Parameters for the similarity transformations. [3] gives
%cosine, and [1,3] gives correlation (see CalSimilarity for more details)
%Converge - The convergence value for the similarity transforms
%EdgeCorrect - The number of subjects and items added for the estimation
%procedure (edge correct in order [1 0 1 0 etc] so even recommended
%MaxIter - The maximum number of iterations for the similarity transforms
%MissingVal - The indicator for a missing value boundary of max(abs-1)
%OUTPUTS
%VMatrix - A visualization of the matrix. First row contains column
%indexes, first column contains row indexes.  Inner matrix shows the reordered
%data
%LeanMiss - The number of 1s in clusters where less than 50% of the values
%are 1
%FatMiss - The number of 0s in clusters where more than 50% of the values
%are 1
%Version 0.10 - Stephen France 05/26/2012

[n,m]=size(X);

if EdgeCorrect>0
  %Create additional [1 0 1 0 etc] patten for both rows and columns
  Pattern=mod(find(ones(1,EdgeCorrect)==1),2);
  TopLeft=mod(mod(find(ones(n,1)==1),2)*ones(1,EdgeCorrect)+ones(n,1)*Pattern,2);
  Bottom= mod(Pattern'*ones(1,m+EdgeCorrect)+ ones(EdgeCorrect,1)*mod(find(ones(1,m+EdgeCorrect)==1),2),2);
  X=[X,TopLeft;Bottom];
  n=n+EdgeCorrect;
  m=m+EdgeCorrect;
end

LeanMiss=0;FatMiss=0;
%Call CONCUR for both rows and columns (missing value is optional
if exist('MissingVal','var')
  [ConvergeFail1,RowClusters] = CONCOR(X,NRowClus,0,SimParams,Converge,MaxIter,MissingVal);
  [ConvergeFail2,ColClusters] = CONCOR(X,NColClus,1,SimParams,Converge,MaxIter,MissingVal);
else
  [ConvergeFail1,RowClusters] = CONCOR(X,NRowClus,0,SimParams,Converge,MaxIter);
  [ConvergeFail2,ColClusters] = CONCOR(X,NColClus,1,SimParams,Converge,MaxIter);
end
                               
ConvergeFail=(ConvergeFail1&ConvergeFail2);
if (ConvergeFail==1)
  sprintf('CONCOR failed.  Cannot visualize solutions')
  return;
end

%Start by giving cluster numbers
RowHeaders=[];
ActiveNo=0;
for i=1:RowClusters.Count
  if (RowClusters.Active{i}==1)
    %Find and remove any edge corrected items (last Edgecorrect rows)
    for j=1:EdgeCorrect
      RemoveIX=n-EdgeCorrect+j;
      LocalIX=find(RowClusters.mItemIndexes{i}==RemoveIX)
      if ~isempty(LocalIX)
        switch LocalIX
          case 1
            RowClusters.mItemIndexes{i}=RowClusters.mItemIndexes{i}(2:RowClusters.ItemCount{i});
          case RowClusters.ItemCount{i}
            RowClusters.mItemIndexes{i}=RowClusters.mItemIndexes{i}(1:RowClusters.ItemCount{i}-1);
          otherwise
            RowClusters.mItemIndexes{i}=[RowClusters.mItemIndexes{i}(1:LocalIX-1),RowClusters.mItemIndexes{i}(LocalIX+1:RowClusters.ItemCount{i})];
        end
        RowClusters.ItemCount{i}=RowClusters.ItemCount{i}-1;
      end
    end
    ActiveNo=ActiveNo+1;
    %Header has two cols, 1 is cluster no, 2 is row number
    AddHeader=[ones(RowClusters.ItemCount{i},1).*ActiveNo,RowClusters.mItemIndexes{i}'];
    RowHeaders=[RowHeaders;AddHeader];
  end
end

ColHeaders=[];
ActiveNo=0;   %Only display active (root) clusters
for i=1:ColClusters.Count
  if (ColClusters.Active{i}==1)
    for j=1:EdgeCorrect
      RemoveIX=n-EdgeCorrect+j;
      LocalIX=find(ColClusters.mItemIndexes{i}==RemoveIX);
      if ~isempty(LocalIX)
        switch LocalIX
          case 1
            ColClusters.mItemIndexes{i}=ColClusters.mItemIndexes{i}(2:ColClusters.ItemCount{i});
          case ColClusters.ItemCount{i}
            ColClusters.mItemIndexes{i}=ColClusters.mItemIndexes{i}(1:ColClusters.ItemCount{i}-1);
          otherwise
            ColClusters.mItemIndexes{i}=[ColClusters.mItemIndexes{i}(1:LocalIX-1),ColClusters.mItemIndexes{i}(LocalIX+1:ColClusters.ItemCount{i})];
        end
        ColClusters.ItemCount{i}=ColClusters.ItemCount{i}-1;
      end
    end
    ActiveNo=ActiveNo+1;
    %Header has two rows, 1 is cluster no, 2 is col number
    AddHeader=[ones(1,ColClusters.ItemCount{i}).*ActiveNo;ColClusters.mItemIndexes{i}];
    ColHeaders=[ColHeaders,AddHeader];
  end
end

TopLeft=zeros(2,2);
MainMatrix=zeros(n-EdgeCorrect,m-EdgeCorrect);
StartRow=1;

%Cycle through pairs of clusters and output to the main matrix
for iRowClus=1:RowClusters.Count
  if (RowClusters.Active{iRowClus}==1)
    StartCol=1;
    for jColClus=1:ColClusters.Count
      if (RowClusters.Active{jColClus}==1)
        EndRow=StartRow+RowClusters.ItemCount{iRowClus}-1;
        EndCol=StartCol+ColClusters.ItemCount{jColClus}-1;
        Temp=X(RowClusters.mItemIndexes{iRowClus},ColClusters.mItemIndexes{jColClus});
        MainMatrix(StartRow:EndRow,StartCol:EndCol)=Temp;
        %Check for deviation from lean or from fat fit
        SumVar=sum(sum(Temp));
        MaxSumVar=RowClusters.ItemCount{iRowClus}*ColClusters.ItemCount{jColClus};
        if SumVar<=(MaxSumVar/2);
          LeanMiss=LeanMiss+SumVar;
        else
          FatMiss=FatMiss+(MaxSumVar-SumVar);
        end
        StartCol=EndCol+1;
      end
    end
    StartRow=EndRow+1;
  end
end

VMatrix=[[TopLeft,ColHeaders];[RowHeaders,MainMatrix]];






