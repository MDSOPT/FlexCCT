function [BestClusters,BestMax] = CWKMeansCCT(X,NoClusters,NoStarts,EstMethod,Converge,MaxIter,MissingVal,CWOptParams,DMax,DPrior,AddParams)
%Clusterwise continuous cultural consensus theory.  Follows Batchelder and Romney
%(1989), but assumes multiple cultures. Runs CWkConsensus, the k-meands
%optimization algorithm multiple times. 
%The classical implementation of Cultural Consensus Theory as described
%in Batchelder and Romney (1988)
%Inputs 
%X - An n*m subject*item matrix
%NoClusters - The number of consensus clusters
%EstMethod  - The estimation method for continuous clusterwise cultural
%consensus theory
%          - 0 Average value
%          - 1 Min Res factor analysis
%          - 2 Maximum likelihood estimation
%          - 3 Maximum likelihood estimation with estimation of b (the
%          - scale variable) for the user 
%          - 4 Fit a Rasch model with a competance parameter alpha 
%Coverge   - The converge value (difference between successive f values)
%            for the continuous estimation
%MaxIter   - The maximum number of iterations for the continuous estimation
%MissingVal - The identifier for missing data (should be outside range of
%actual values) 
%CWOptParams - See header for CEkConsensus.m
%DMax        - The maximum value of D
%DPrior      - Prior guess for value D
%AddParams - Additional parameters (see ContinuousCCT header)
%Outputs
%Clusters - For each cluster give the following:
%-------------------------------------------------------------------------
%Count - The number of items in the cluster
%Indexes - The indexes of the items in the cluster
%Z   - A continuous m*1 answer key vector
%D   - An n*1 vector of competencies from initial estimation
%D2  - An n*1 vector of competencies after replacing diagonal with (D^2) and
%performing PCA.
%OP3 - The third output parameter, contigent on the estimation method
%    - if EstMethod=3 then = bz - A continuous m*1 scale varible 
%    - If EstMethod=4 then = Diff - A continuous m*1 vector of Rasch item
%      diffs.
%--------------------------------------------------------------------------
% Give the following overall agregate values
%--------------------------------------------------------------------------
%ZAll - An l*m matrix of all z
%DAll - A n*1 matrix of D's for all users
%DAll - A n*1 matrix of D's for all users
%C - A n*l binary cluster assignment matrix
%
%Version     Author            Date
%   0.10     Stephen France    08/25/2012

[n,m]=size(X);
P=+~(X==MissingVal); 

if CWOptParams(1)>round((n./NoClusters)+1);
  'Value of minimum items is too high.  Please reduce' 
  return
end

BestMax=-1e21;
i=0;
while i<NoStarts
  %k-consensus clustering
  if exist('AddParams','var')
    [Clusters,CurMax,Fail,FinalSSW,FinalSSB]=CWkConsensus(X,NoClusters,CWOptParams,EstMethod,Converge,MaxIter,MissingVal,DMax,DPrior,AddParams);
  else
    [Clusters,CurMax,Fail,FinalSSW,FinalSSB]=CWkConsensus(X,NoClusters,CWOptParams,EstMethod,Converge,MaxIter,MissingVal,DMax,DPrior);
  end  
  %Check if best solution 
  if CurMax>BestMax
    BestMax=CurMax;
    BestClusters=Clusters;
  end
  i=i+1;
end

%Setup aggregate values of C
Clusters.C=zeros(n,NoClusters);
for i=1:NoClusters
  Clusters.C(BestClusters.Indexes{i},i)=1;
end


