function [LKRatio] = LKHoodStats(X,Z,W,P)
%Calculates item statistics for the maximum likelihood function. Give
%piecewise likelihood statistics for each question and then calculate
%an overall likelihood ratio. 
%   Detailed explanation goes here
%X -          An n*m subject*item matrix
%Z -          A 1*m answer key vector
%W -          An n*m matrix of weighting values for the maximum likelihood
%OptFunction-  The function to maximize/minimize
%Outputs
%LKRatio  - A 5*m matrix, with each row consistint of the following
%  Row 1   - Log Likelihood for hits
%  Row 2   - Log Likelihood for false positives
%  Row 3   - Log Likelihood for not hits (1-HR)
%  Row 4   - Log Likelihood for falses (1-FPR)
%  Row 5   - Ratio for getting a 1 (Row1+Row2)./(Row3+Row4)
%RealFP    - An n*1 vector of false positive rates
%Version     Author            Date
%   0.10     Stephen France    04/20/2012

  BigN=1E6;

  [n,m]=size(X);
  
  if ~exist('W','var')
    W=ones(n,m);
  end
  
  if ~exist('P','var')
    P=ones(n,m);
  end
  
  %Firstly calculate the values of D and g
  Hits=X.*(ones(n,1)*Z);
  FPositives=X.*(ones(n,1)*(1-Z));
  %Proportion of hits and false positives)
  %If Z=1 for all items or Z=0 for all items then the problem is not
  %Fully defined (take as 0 (e.g. no false positives or hits)
  RealHR=sum(Hits,2)./(sum(Z));
  HR=sum(Hits,2)./(sum(Z)+((sum(Z))==0));
  RealFPR=sum(FPositives,2)./(sum(1-Z));
  FPR=sum(FPositives,2)./(sum(1-Z)+((sum(1-Z))==0));  

  LogHR=log(HR+(HR==0));
  LogFPR=log(FPR+(FPR==0));
  LogNHR=log((1-HR)+((1-HR)==0));
  LogNFPR=log((1-FPR)+((1-FPR)==0));
    
  %Calculate maximum likelihood components
  HitLK=(LogHR*ones(1,m)).*(W.*X.*(ones(n,1)*Z));
  FPLK= (LogFPR*ones(1,m)).*(W.*X.*(ones(n,1)*(1-Z)));
  NotHitLK=(LogNHR*ones(1,m)).*(W.*(1-X).*(ones(n,1)*Z));
  NotFPLK=(LogNFPR*ones(1,m)).*(W.*(1-X).*(ones(n,1)*(1-Z))); 
    
  LKRatio=zeros(5,m);
  LKRatio(1,:)=sum(HitLK,1);
  LKRatio(2,:)=sum(FPLK,1);
  LKRatio(3,:)=sum(NotHitLK,1);
  LKRatio(4,:)=sum(NotFPLK,1);
  LKRatio(5,:)=(LKRatio(1,:)+LKRatio(4,:))./(LKRatio(1,:)+LKRatio(2,:)+LKRatio(3,:)+LKRatio(4,:));
end

