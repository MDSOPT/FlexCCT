function [Clusters,CIDX] = CWCCTInitialize(X,P,NoClusters,Initialize)
%Generates the initial cluster configuration
%Inputs
%X          - An n*m subject*item input matrix
%P          - An n*m data indicator matrix, 1 if not missing, 0 if missing
%NoClusters - The number of consensus clusters
%Initialize - Initialization method (see CWContinuousCCT)
%Outputs
%Clusters  - Initial values for clustering configuration (see CWContinuousCCT)
%CIDX - An n*1 cluster configuration, giving the number of the assigned
%cluster for each user
%-------------------------------------------------------------------------
%Version     Author            Date
%   0.10     Stephen France    08/07/2012
[n,m]=size(X);
X2=X;
if Initialize==1
  %Random clusters
  %CIDX=floor(rand(n,1)*NoClusters)+1;
  CIDX=ones(n,1);
  Perm=randperm(n);
  Assignments=ones(n,1);
  for i=2:NoClusters
    SubPerm=Perm(floor(n*(i-1)/NoClusters)+1:floor(n*i/NoClusters));
    CIDX(SubPerm)=i;
  end 
else
  %Create distance matrix from configuration with possible missing data
  switch Initialize
    case 2
      %Euclidean
      [D] = pDistMissing(X2,-1,2,2);
    case 3
      %Square Euclidean
      [D] = pDistMissing(X2,-1,2,1);
    case 4
      %City block
      [D] = pDistMissing(X2,-1,1,1);
    case 5
      %Correlation
      X2 = PreProcessX(X2,P,[1,9,2]);
      [D] = pDistMissing(X2,-1,2,2);
    case 6
      %Cosine
      X2 = PreProcessX(X2,P,[9,2]);
      [D] = pDistMissing(X2,-1,2,2);
    case 7
      %Cosine - subtracting column means
      X2 = PreProcessX(X2,P,[2,9,2]);
      [D] = pDistMissing(X2,-1,2,2);
  end
  %Perform classical MDS on the distances to produce dense configuration
  X2 = cmdscale(D);
  FoundkMeans=false;
  while (FoundkMeans==false)
    try
      CIDX = kmeans(X2,NoClusters);
      FoundkMeans=true;
    catch
      %Do nothing
    end
  end
end

Clusters.X=X;
Clusters.NoClusters=NoClusters;
Clusters.UserCount=n;
Clusters.QCount=m;

for i=1:NoClusters
  %Split into clusters
  Clusters.Indexes{i}=find(CIDX==i)';
  Clusters.Count{i}=size(Clusters.Indexes{i},2);
  Clusters.SX{i}=X(Clusters.Indexes{i},:);
end



end

