% The main graphic user interface and entry point to the application.
% Allows users to load data files, set model options, set optimization
% options, run a scree plot analysis, and run the model.
%Version     Author            Date
%   0.10     Mahyar Vaghefi    01/30/2014
%   2.00     Stephen France    04/02/2016
function varargout = gui(varargin)
% The major form and entry point for the FlexCCT application.  Contains functionality for
% loading files, setting model options, setting optimization options, creating scree plots and running models.
% GUI MATLAB code for gui.fig
%      GUI, by itself, creates a new GUI or raises the existing
%      singleton*.
%
%      H = GUI returns the handle to a new GUI or the handle to
%      the existing singleton*.
%
%      GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI.M with the given input arguments.
%
%      GUI('Property','Value',...) creates a new GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui

% Last Modified by GUIDE v2.5 04-Jul-2017 13:42:58

% Begin initialization code - DO NOT EDIT
%Version     Author            Date
%   0.10     Mahyar Vaghefi    01/20/2014
%   2.00     Stephen France    04/02/2016
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui is made visible.
function gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui (see VARARGIN)

%Make the current directory the deploy directory
if isdeployed % Stand-alone mode.
    [status, result] = system('path');
    currentDir = char(regexpi(result, 'Path=(.*?);', 'tokens', 'once'));
    cd(currentDir);
    userpath(currentDir);
end


% Choose default command line output for gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

javaFrame = get(handle(hObject),'JavaFrame');
javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));

% UIWAIT makes gui wait for user response (see UIRESUME)
% uiwait(handles.mainform);
%Set the advanced data
DefaultAdvanced(handles);
DefaultValidation(handles);

set(handles.cmdRun,'enable','off')
set(handles.cmdScree,'enable','off')
%Remove this for the deployment version.  For future versions
%there will be full batch processing
set(handles.cmdBatch,'visible','off')


function DefaultAdvanced(handles)
%Only allowed to fix d or z for ML Model and above
GUIEstimation=get(handles.cboEstimation,'Value');
if GUIEstimation>2
  setappdata(0,'Fixz',2);  %partial variable fix
  setappdata(0,'Fixd',2);
else
  setappdata(0,'Fixz',1);  %partial variable fix
  setappdata(0,'Fixd',1);
end
setappdata(0,'FixbA',1); %Cannot fix the bias if not available
setappdata(0,'FixbM',1);
setappdata(0,'CIz',0);
setappdata(0,'CId',0);
setappdata(0,'CIbA',0);
setappdata(0,'CIbM',0);
setappdata(0,'CIIE',0);
setappdata(0,'CIAlpha','0.05');
setappdata(0,'NoResamples','1000');
setappdata(0,'IntervalType',1);
setappdata(0,'CIReplace',0);
%In addition give the cluster details
setappdata(0,'NoCultures','1');
setappdata(0,'NoClusteringRuns','10');
setappdata(0,'ClusterBias',0);

function DefaultValidation(handles)
setappdata(0,'HOz',0);
setappdata(0,'HOd',0);
setappdata(0,'HObA',0);
setappdata(0,'HObM',0);
setappdata(0,'HOIE',0);
setappdata(0,'HOXPred',0);
setappdata(0,'NoHoldout','1');
setappdata(0,'MaxRuns','100000');
setappdata(0,'MSE',0);
setappdata(0,'MSPE',0);
setappdata(0,'MAE',0);
setappdata(0,'MAPE',0);
setappdata(0,'Correl',0);
setappdata(0,'RunGroundTruth',0)

% --- Outputs from this function are returned to the command line.
function varargout = gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function txtDataFile_Callback(hObject, eventdata, handles)
% hObject    handle to txtDataFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtDataFile as text
%        str2double(get(hObject,'String')) returns contents of txtDataFile as a double

%if run button off and something in data text then enable
if strcmp(get(handles.cmdRun,'Enable'),'off')==1&&strcmp(get(handles.txtDataFile,'string'),'')==0
  set(handles.cmdRun,'enable','on')
  set(handles.cmdScree,'enable','on')
end
%if run button on and nothing in data text then disable
if strcmp(get(handles.cmdRun,'Enable'),'on')==1&&isempty(get(handles.txtDataFile,'string'))==1
  set(handles.cmdRun,'enable','off')
  set(handles.cmdScree,'enable','off')
end


% --- Executes during object creation, after setting all properties.
function txtDataFile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtDataFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cmdBrowse.
function cmdBrowse_Callback(hObject, eventdata, handles)
try
  %set the data file text box.
  [FileName,FilePath]=uigetfile('*.csv');
  ExPath = [FilePath FileName];
  if(FileName~=0)
      set(handles.txtDataFile,'String',ExPath);
      if strcmp(get(handles.cmdRun,'Enable'),'off')==1
        set(handles.cmdRun,'enable','on')
        set(handles.cmdScree,'enable','on')
      end
  end
catch err
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h); 
end

function cmdTraits_Callback(hObject, eventdata, handles)
numTraits=str2num(get(handles.cmdTraits,'string'));
% if the number of traites equal to 1
% disable the Correspondance Analysis option 
% selet the Add Traits option
if numTraits==1
  set(handles.cmdCorrespond,'enable','off')
  set(handles.cmdCorrespond,'value',0);
  set(handles.cmdAddTraits,'value',1);
% if the number of traites is bigger than 1
% Enable Correspondance Analysis
elseif numTraits>1
    set(handles.cmdCorrespond,'enable','on')
% if the user inputs any digit less than 1 or any characters
% the GUI will back to it's default settings 
else
    set(handles.cmdTraits,'string','1');
    set(handles.cmdCorrespond,'enable','off')
    set(handles.cmdCorrespond,'value',0);
    set(handles.cmdAddTraits,'value',1);
end
    


% --- Executes during object creation, after setting all properties.
function cmdTraits_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cmdTraits (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cmdRun.
function cmdRun_Callback(hObject, eventdata, handles)

try  
    set(gcf,'Pointer','watch');
    set(handles.cmdRun,'enable','off');
    drawnow;
  %do some stuff
  
    %load data into the X variable
    X=importdata(get(handles.txtDataFile,'string'),',');
    
    [X,zGround,HasColHeader,HasRowHeader,ColHeader,RowHeader,MissingVal] = ProcessFile(X,handles);
    %Set the row header and column headers for graphs
    setappdata(0,'HasColHeader',HasColHeader);
    setappdata(0,'HasRowHeader',HasRowHeader);
    setappdata(0,'ColHeader',ColHeader);
    setappdata(0,'RowHeader',RowHeader);
    
    %4.Estimation Method
    %for matching the returned value from cboEstimation pop-up menu (started
    %from 1) and the value of estimation method parameter (started from 0),
    %we need to reduce 1 from the cboEstimation pop-up value;
    %SLF 08/29 Have removed the item variance option, so this only applies
    %to the first options
    EstMethod=get(handles.cboEstimation,'value');
    if EstMethod<4
      EstMethod=EstMethod-1;
    end

    %5.Bias Type
    %for matching the returned value from cboBiasType pop-up menu (started
    %from 1) and the value of bias type parameter (started from 0),
    %we need to reduce 1 from the cboBiasType pop-up value;
    BiasType=get(handles.cboBiasType,'value')-1;

    %6.Optimization Method
    %Notice: we arrange as follows because changing the Estimation Method option
    %will change available options in optimization method and with this arrangement
    %the returned value from pop-up menu always match to the fixed option 
    %pop-up menu values: (SF 8/1/2013 - Swapped 3 and 4 to put fixed point
    %first)
    %   1=Gradient
    %   2=Derivative Free
    %   3=Fixed Point
    %However the function's input values are compeletly different
    %   0=Fixed Point
    %   1=Two Stage Fixed Point
    %   2=Derivative Free
    %   3=Gradient
    %slf 08/29 - Converted both fixed point categories into a single
    %category
    if EstMethod==1
      OptMethod=3;  %Ensure fixed point for the factor analysis
    else
      OptMethod=get(handles.cboOptimization,'value');
    end

    %7.Converge
    Converge=str2double(get(handles.txtConverge,'string'));

    %8.Maximum Iteration 
    MaxIter=1000;

    %10.D Max
    DMax=str2num(get(handles.txtdMax,'string'));

    %11.IE Max
    IEMax=str2num(get(handles.txtIEMax,'string'));
    
    %12 Get the fix params 
    Fixz=getappdata(0,'Fixz');  %partial variable fix
    Fixd=getappdata(0,'Fixd');
    FixbA=getappdata(0,'FixbA'); %Cannot fix the bias if not available
    FixbM=getappdata(0,'FixbM');
    FixParams=[Fixz,Fixd,FixbA,FixbM];
    %Convert GUI order to CCT param values
    %1=none,1=partial,-1=full,-99=average
    FixParams(FixParams==4)=-99;
    FixParams(FixParams==1)=0;
    FixParams(FixParams==2)=1;
    FixParams(FixParams==3)=-1;
 
    %Get the cluster options
    ClusterOptions.NoCultures=str2double(getappdata(0,'NoCultures'));
    ClusterOptions.NoClusteringRuns=str2double(getappdata(0,'NoClusteringRuns'));
    ClusterOptions.ClusterBias=getappdata(0,'ClusterBias');
    
    %Get the confidence interval options
    CIOptions.CIz=getappdata(0,'CIz');
    CIOptions.CId=getappdata(0,'CId');
    CIOptions.CIbadd=getappdata(0,'CIbA');
    CIOptions.CIbmult=getappdata(0,'CIbM');
    CIOptions.CIIE=getappdata(0,'CIIE');
    CIOptions.CIReplace=getappdata(0,'CIReplace');
    CIOptions.HasRaterBootstrap=CIOptions.CId||CIOptions.CIbadd||CIOptions.CIbmult;
    CIOptions.HasItemBootstrap=CIOptions.CIz||CIOptions.CIIE;
    %Set the confidence intervatl options for the results form
    setappdata(0,'HasRaterBootstrap',CIOptions.HasRaterBootstrap);
    setappdata(0,'HasItemBootstrap',CIOptions.HasItemBootstrap);

    CIOptions.Alpha=str2double(getappdata(0,'CIAlpha'));
    CIOptions.NoResample=str2double(getappdata(0,'NoResamples'));
    CIOptions.Technique=getappdata(0,'IntervalType')-1;
    
    %Set the validation options
    VldOptions.HOz=getappdata(0,'HOz');
    VldOptions.HOd=getappdata(0,'HOd');
    VldOptions.HObadd=getappdata(0,'HObA');
    VldOptions.HObmult=getappdata(0,'HObM');
    VldOptions.HOIE=getappdata(0,'HOIE');
    VldOptions.HOXPred=getappdata(0,'HOXPred');
    VldOptions.NoHoldout=str2double(getappdata(0,'NoHoldout'));
    VldOptions.MaxRuns=str2double(getappdata(0,'MaxRuns'));
    VldOptions.MSE=getappdata(0,'MSE');
    VldOptions.MSPE=getappdata(0,'MSPE');
    VldOptions.MAE=getappdata(0,'MAE');
    VldOptions.MAPE=getappdata(0,'MAPE');
    VldOptions.Correl=getappdata(0,'Correl');
    VldOptions.RunGroundTruth=((~isempty(zGround))&&(getappdata(0,'RunGroundTruth')));
    VldOptions.HasHoldout=VldOptions.HOd||VldOptions.HObadd||VldOptions.HObmult||VldOptions.HOz||VldOptions.HOIE||VldOptions.HOXPred;
    %N.B. If XPred is selected, we automatically need to holdout
    VldOptions.HasHoldoutCriteria=VldOptions.MSE||VldOptions.MSPE||VldOptions.MAE||VldOptions.MAPE||VldOptions.Correl;
    %Only include ground truth calculation if option is set and is
    %available
        
    %Run the FlexCCT procedure
    if EstMethod==0 || EstMethod==1
      [Results] = FlexCCT(X,zGround,ClusterOptions,CIOptions,VldOptions,EstMethod,BiasType,FixParams,OptMethod,Converge,MaxIter,MissingVal);
    elseif EstMethod==2 
      [Results] = FlexCCT(X,zGround,ClusterOptions,CIOptions,VldOptions,EstMethod,BiasType,FixParams,OptMethod,Converge,MaxIter,MissingVal,DMax);
    else 
      [Results] = FlexCCT(X,zGround,ClusterOptions,CIOptions,VldOptions,EstMethod,BiasType,FixParams,OptMethod,Converge,MaxIter,MissingVal,DMax,IEMax);
    end
      
    [n,m]=size(X);
    Maxnm=max(n,m);
    data=[];Residuals=[];zOut=[];
    NoCols=0;NoResCols=0;NoResRows=0;
    for i=1:ClusterOptions.NoCultures
      NoCols=NoCols+1;
      data=[data,[i;NaN.*ones(Maxnm-1,1)]];
      Cols{NoCols}='Culture';
      NoCols=NoCols+1;
      %Calculate the reliability
      HasMissing=sum(sum(X==MissingVal));
      if (EstMethod==5)
        [Basic,CCT] = CCTReliabilityAdd3(Results.SX{i},MissingVal,Results.D{i},Results.Bias{i},Results.QE{i});
      else
        %Efficient routine with no missing data
        %[Basic,CCT] = CCTReliabilitySp(Results.SX{i},MissingVal,Results.D{i},Results.Bias{i},Results.QE{i});        
        %[Basic,CCT] = CCTReliability2(Results.SX{i},MissingVal,Results.D{i},Results.Bias{i},Results.QE{i});
        [Basic,CCT] = CCTReliability3(Results.SX{i},MissingVal,Results.D{i},Results.Bias{i},Results.QE{i});
      end
      %If running holdout validation with predictions, the sixth value is
      %the log-likelihood over the predicted data
      if VldOptions.HOXPred==true
        data=[data,[Results.MaxCrit{i};Results.Holdout{i}.XPredHOMetrics.Values(6);Basic;CCT;NaN.*ones(Maxnm-4,1)]];
        Cols{NoCols}='LL;LLPred;RB;RCCT';
      else
        %The data cols
        data=[data,[Results.MaxCrit{i};Basic;CCT;NaN.*ones(Maxnm-3,1)]];
        Cols{NoCols}='LL;RB;RCCT';
      end
      
      if ((VldOptions.HasHoldout==true)||VldOptions.RunGroundTruth)&&(VldOptions.HasHoldoutCriteria==true)
        %Has some sort of holdout criteria
        DataRow=[];
        ValidCount=0;
        for j=1:5
          if (VldOptions.RunGroundTruth==true)&&(Results.GTMetrics{i}.Ind(j)==1);
            ValidCount=ValidCount+1;
            ColCell{ValidCount}=['zGr',Results.GTMetrics{i}.Text{j}];
            DataRow=[DataRow;Results.GTMetrics{i}.Values(j)];       
          end
          if (VldOptions.HOz==true)&&(Results.Holdout{i}.zHOMetrics.Ind(j)==1);
            ValidCount=ValidCount+1;
            ColCell{ValidCount}=['z',Results.Holdout{i}.zHOMetrics.Text{j}];
            DataRow=[DataRow;Results.Holdout{i}.zHOMetrics.Values(j)];
          end
          if (VldOptions.HOd==true)&&(Results.Holdout{i}.dHOMetrics.Ind(j)==1);
            ValidCount=ValidCount+1;
            ColCell{ValidCount}=['d',Results.Holdout{i}.dHOMetrics.Text{j}];
            DataRow=[DataRow;Results.Holdout{i}.dHOMetrics.Values(j)];
          end
          if (VldOptions.HObadd==true)&&(Results.Holdout{i}.baddHOMetrics.Ind(j)==1);
            ValidCount=ValidCount+1;
            ColCell{ValidCount}=['badd',Results.Holdout{i}.baddHOMetrics.Text{j}];
            DataRow=[DataRow;Results.Holdout{i}.baddHOMetrics.Values(j)];
          end
          if (VldOptions.HObmult==true)&&(Results.Holdout{i}.bmultHOMetrics.Ind(j)==1);
            ValidCount=ValidCount+1;
            ColCell{ValidCount}=['bmult',Results.Holdout{i}.bmultHOMetrics.Text{j}];
            DataRow=[DataRow;Results.Holdout{i}.bmultHOMetrics.Values(j)];
          end
          if (VldOptions.HOIE==true)&&(Results.Holdout{i}.IEHOMetrics.Ind(j)==1);
            ValidCount=ValidCount+1;
            ColCell{ValidCount}=['IE',Results.Holdout{i}.IEHOMetrics.Text{j}];
            DataRow=[DataRow;Results.Holdout{i}.IEHOMetrics.Values(j)];
          end
          if (VldOptions.HOXPred==true)&&(Results.Holdout{i}.XPredHOMetrics.Ind(j)==1);
            ValidCount=ValidCount+1;
            ColCell{ValidCount}=['XP',Results.Holdout{i}.XPredHOMetrics.Text{j}];
            DataRow=[DataRow;Results.Holdout{i}.XPredHOMetrics.Values(j)];
          end
        end
        %Add the data column for the validation
        NoCols=NoCols+1;
        Cols{NoCols}=strjoin(ColCell, ';');
        data=[data,[DataRow;NaN.*ones(Maxnm-ValidCount,1)]];
      end
      NoCols=NoCols+1;

      data=[data,[Results.D{i};NaN.*ones(Maxnm-Results.Count{i},1)]];
      Cols{NoCols}='d';
      if (CIOptions.CId==true)
        data=[data,[Results.RaterCI{i}.dLB;NaN.*ones(Maxnm-Results.Count{i},1)]];
        data=[data,[Results.RaterCI{i}.dUB;NaN.*ones(Maxnm-Results.Count{i},1)]];
        NoCols=NoCols+1;
        Cols{NoCols}='dCILower';
        NoCols=NoCols+1;
        Cols{NoCols}='dCIUpper';
      end
      NoCols=NoCols+1;
      data=[data,[Results.Bias{i}(:,1);NaN.*ones(Maxnm-Results.Count{i},1)]];
      Cols{NoCols}='badd';
      if (CIOptions.CIbadd==true)
        data=[data,[Results.RaterCI{i}.baddLB;NaN.*ones(Maxnm-Results.Count{i},1)]];
        data=[data,[Results.RaterCI{i}.baddUB;NaN.*ones(Maxnm-Results.Count{i},1)]];
        NoCols=NoCols+1;
        Cols{NoCols}='baddCILower';
        NoCols=NoCols+1;
        Cols{NoCols}='baddCIUpper';
      end
      NoCols=NoCols+1;
      data=[data,[Results.Bias{i}(:,2);NaN.*ones(Maxnm-Results.Count{i},1)]];
      Cols{NoCols}='bmult';
      if (CIOptions.CIbmult==true)
      data=[data,[Results.RaterCI{i}.bmultLB;NaN.*ones(Maxnm-Results.Count{i},1)]];
        data=[data,[Results.RaterCI{i}.bmultUB;NaN.*ones(Maxnm-Results.Count{i},1)]]; 
        NoCols=NoCols+1;
        Cols{NoCols}='bmultCILower';
        NoCols=NoCols+1;
        Cols{NoCols}='bmultCIUpper';
      end
      NoCols=NoCols+1;
      data=[data,[Results.z{i}';NaN.*ones(Maxnm-m,1)]];
      Cols{NoCols}='z'; 
      if (CIOptions.CIz==true)
        data=[data,[Results.ItemCI{i}.zLB;NaN.*ones(Maxnm-m,1)]];
        data=[data,[Results.ItemCI{i}.zUB;NaN.*ones(Maxnm-m,1)]];
        NoCols=NoCols+1;
        Cols{NoCols}='zCILower';
        NoCols=NoCols+1;
        Cols{NoCols}='zCIUpper';
      end
      NoCols=NoCols+1;
      data=[data,[Results.QE{i}';NaN.*ones(Maxnm-m,1)]];
      Cols{NoCols}='IE'; 
   
      if (CIOptions.CIIE==true)
        data=[data,[Results.ItemCI{i}.IELB;NaN.*ones(Maxnm-m,1)]];
        data=[data,[Results.ItemCI{i}.IEUB;NaN.*ones(Maxnm-m,1)]];
        NoCols=NoCols+1;
        Cols{NoCols}='IECILower';
        NoCols=NoCols+1;
        Cols{NoCols}='IECIUpper';
      end      
      
      data=[data,[Results.LLPartial{i}';NaN.*ones(Maxnm-m,3)]];
      NoCols=NoCols+1;
      Cols{NoCols}='LLPartial(LB)';
      NoCols=NoCols+1;
      Cols{NoCols}='LLPartial';
      NoCols=NoCols+1;
      Cols{NoCols}='LLPartial(UB)'; 
      %Now calculate residuals for each cluster
      Residuals{i}=Results.SX{i}-Results.Bias{i}(:,1)*ones(1,m)-Results.Bias{i}(:,2)*Results.z{i};
      Residuals{i}(Results.SX{i}==MissingVal)=NaN;
    end
          
    if ClusterOptions.NoCultures>1
      %Add the cluster number to the headers
      NoResCols=1;
      ColHeaderAll{NoResCols}='Culture';
      ResidualsAll=zeros(n,m);
      CultureNos=zeros(n,1);
      for i=1:ClusterOptions.NoCultures
        ResidualsAll(Results.Indexes{i},:)=Residuals{i};
        CultureNos(Results.Indexes{i})=i;
      end
      ResidualsAll=[CultureNos,ResidualsAll];
    else
      ResidualsAll=Residuals{1};
    end
    for j=1:m
      NoResCols=NoResCols+1;
      if (HasColHeader==true)
        %Column headers are available
        ColHeaderAll{NoResCols}=ColHeader{j};
      else
        %Use column numbers as headers.
        ColHeaderAll{NoResCols}=num2str(j);
      end
    end
    for j=1:n
      NoResRows=NoResRows+1;
      if (HasRowHeader==true)
        %Column headers are available
        RowHeaderAll{NoResRows}=RowHeader{j};
      else
        %Use column numbers as headers.
        RowHeaderAll{NoResRows}=num2str(j);
      end 
    end
    
    %Setup the application data for the output grid
    setappdata(0,'data',data);
    setappdata(0,'colnames',Cols);
    setappdata(0,'Results',Results);
    
    %Setup the application data for the residuals grid
    setappdata(0,'n',n);
    setappdata(0,'m',m);
    setappdata(0,'ColHeaderAll',ColHeaderAll);
    setappdata(0,'RowHeaderAll',RowHeaderAll);
    setappdata(0,'Residuals',Residuals);   
    setappdata(0,'ResidualsAll',ResidualsAll);  
    
    set(gcf,'Pointer','arrow');
    drawnow;
    result;
    set(handles.cmdRun,'enable','on');
    
%     %err.identifier
%     title='Error';
%     if (strcmp(err.identifier,'MATLAB:load:couldNotReadFile'))
%         msg='Could Not Read The File';
%         msg=err.message;
%         title='File Error';
%     elseif (strcmp(err.identifier,'MATLAB:load:emptyFileName'))
%         msg='Select The Data Input File';
%         msg=err.message;
%         title='File Error';
%     else
%         msg=err.message;
%         title=err.identifier;
%     end
    
catch err
  set(gcf,'Pointer','arrow');
  set(handles.cmdRun,'enable','on');
  drawnow;
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h);
end

function RunAll(hObject, eventdata, handles,Mode)
%Run mode if 1 - run the CCT, 2 - Run the test of the factor analysis


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in cmdDefault.
function cmdDefault_Callback(hObject, eventdata, handles)
selection = MFquestdlg([0.3,0.5],'Are you sure that you would like to return to default settings?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes'
  %Set default values in GUI
  set(handles.txtDataFile,'string','');
  set(handles.chkRowHeaders,'Value',0);
  set(handles.chkColHeaders,'Value',0);
  set(handles.chkRowHeaders,'Value',0);
  set(handles.chkGroundTruth,'Value',0);
  set(handles.cmdTraits,'string','1');
  set(handles.cmdAddTraits,'Value',1);
  set(handles.cmdCorrespond,'Value',0);
  set(handles.cmdCorrespond,'enable','off');
  set(handles.cmdNone,'Value',1);
  set(handles.cmdStandardize,'Value',0);
  set(handles.cmdRange,'Value',0);
  set(handles.cmdLog,'Value',0);
  set(handles.cboEstimation,'Value',3);
  set(handles.cboBiasType,'Value',1);
  set(handles.cboOptimization,'Value',1);
  set(handles.txtMissingValue,'string','-1');
  set(handles.txtConverge,'string','1e-6');
  set(handles.txtdMax,'string','10');
  set(handles.txtIEMax,'string','10');
  %Set default values for the advanced options
  DefaultAdvanced(handles);
  DefaultValidation(handles);
  set(handles.cmdRun,'enable','off')
  set(handles.cmdScree,'enable','off')
case 'No'
return
end %switch




% --- Executes on selection change in biiiiiation.
function cboOptimization_Callback(hObject, eventdata, handles)
% hObject    handle to cboOptimization (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboOptimization contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboOptimization
GUIEstimation=get(handles.cboEstimation,'Value');
GUIOptimization=get(handles.cboOptimization,'Value');
%Fixed point optimization cannot have -99
ChangeInstance=false;

if GUIOptimization==3
  
  %z and d default to 1, but only if allowed.
  if getappdata(0,'Fixz')==4
    if (ChangeInstance==false) 
      ChangeInstance=true;
    end
    if GUIEstimation>2
      setappdata(0,'Fixz',2);  %partial variable fix
    else
      setappdata(0,'Fixz',1);  %No variable fix
    end
  end
  if getappdata(0,'Fixd')==4
    if (ChangeInstance==false) 
      ChangeInstance=true;
    end
    if GUIEstimation>2
      setappdata(0,'Fixd',2);  %partial variable fix
    else
      setappdata(0,'Fixd',1);  %No variable fix
    end
  end
  %bA and bM always default to 1
  if getappdata(0,'FixbA')==4
    if (ChangeInstance==false) 
      ChangeInstance=true;
    end
    setappdata(0,'FixbA',1);
  end
  if getappdata(0,'FixbM')==4
    if (ChangeInstance==false) 
      ChangeInstance=true;
    end
    setappdata(0,'FixbM',1);
  end  
  
  %if changed is true then 
  if (ChangeInstance==true)
    message='FixAverage identifiability not allowed for fixed point optimization. FixAverage identifiability values have been returned to its default value. Click the OK button to continue.';
    h=msgbox(message,'FlexCCT Message');
    javaFrame = get(handle(h),'JavaFrame');
    javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
    uiwait(h);
  end
end
% --- Executes during object creation, after setting all properties.
function cboOptimization_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboOptimization (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtConverge_Callback(hObject, eventdata, handles)
converge=str2double(get(handles.txtConverge,'string'));
%if the value is less than zero or not a number change it to default one 
if converge>0
    %do nothing
else
    set(handles.txtConverge,'string','1e-6');
end


% --- Executes during object creation, after setting all properties.
function txtConverge_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtConverge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtdMax_Callback(hObject, eventdata, handles)
dMax=str2double(get(handles.txtdMax,'string'));
%if the value is less than zero or not a number change it to default one 
if dMax>0
    %do nothing
else
    set(handles.txtdMax,'string','');
end


% --- Executes during object creation, after setting all properties.
function txtdMax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtdMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtIEMax_Callback(hObject, eventdata, handles)
IEMax=str2double(get(handles.txtIEMax,'string'));
%if the value is less than zero or not a number change it to default one 
if IEMax>0
    %do nothing
else
    set(handles.txtIEMax,'string','');
end

% --- Executes during object creation, after setting all properties.
function txtIEMax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtIEMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cboEstimation.
function cboEstimation_Callback(hObject, eventdata, handles)
  SetOptimizationOptions(0,handles);

function SetOptimizationOptions(CallType,handles)
%CallType - 0 if called from the estimation callback function
%         - 1 if called from the bias combo callback function

 %get the selected option in Estimation pop-up menu
selectedOption=get(handles.cboEstimation,'Value');
% 1:Simple Average
% 2:Factor Analysis
% 3:ML Model
% 4:IE Error Variance
% 5:IE Multiply
% 6:IE Add

CurOptimization=get(handles.cboOptimization,'Value');
% 1: Gradient
% 2: Derivative Free
% 3: Fixed Point

switch selectedOption
    case 1
        %Simple Average
        %reset the GUI
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        set(handles.cboOptimization,'Enable','on');
        %SF Note that fixed point multiplication is not allowed when both
        %bias types are fit simulataneously
        set(handles.cboOptimization,'String',{'Gradient','Derivative Free','Fixed Point'});
        set(handles.cboOptimization,'Value',CurOptimization);
        %Cannot set bias for  d
        if (getappdata(0,'Fixz')~=1)||(getappdata(0,'Fixd')~=1)
          message='Cannot fix z or d. Defaulting to no fix. Click the OK button to continue.';
          h=msgbox(message,'FlexCCT Message');
          javaFrame = get(handle(h),'JavaFrame');
          javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
          uiwait(h);
          setappdata(0,'Fixz',1);  %No variable fix
          setappdata(0,'Fixd',1);
        end
        %Cannot allow confidence intervals for d,z, or IE.
        setappdata(0,'CIz',0);setappdata(0,'CId',0);setappdata(0,'CIIE',0);
        %Cannot allow holdout validation (except for z)
        setappdata(0,'HOd',0);setappdata(0,'HOIE',0); 
    case 2
        %Factor analysis
        %in cboBiasType, Value 1 is stands for 'No Bias'
        set(handles.cboBiasType,'Value',1);
        %Disable bias pop-up menu when Factor Analysis is selected
        set(handles.cboBiasType,'Enable','off');
        %invisible the optimization options 
        set(handles.cboOptimization,'Visible','off');
        %set the optimization method to the fixed point. Although this option
        %should be invisible, we need to pass 3 for optimization when the 
        %factor analysis is selected.So, we set the optimization to fixed point
        %which will return 3
        %set(handles.cboOptimization,'Value',3);
        %Cannot set any type of bias 
        if (getappdata(0,'Fixz')~=1)||(getappdata(0,'Fixd')~=1)||(getappdata(0,'FixbA')~=1)||(getappdata(0,'FixbM')~=1)
          message='Cannot fix z or d, or bias. Defaulting to no fix. Click the OK button to continue.';
          h=msgbox(message,'FlexCCT Message');
          javaFrame = get(handle(h),'JavaFrame');
          javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
          uiwait(h);
          setappdata(0,'Fixz',1);  %No variable fix
          setappdata(0,'Fixd',1);
          setappdata(0,'FixbA',1); %Cannot fix the bias if not available
          setappdata(0,'FixbM',1);
        end

        %Cannot allow any confidence intervals
        setappdata(0,'CIz',0);setappdata(0,'CIIE',0);
        setappdata(0,'CId',0);setappdata(0,'CIbA',0);setappdata(0,'CIbM',0);  
        %Cannot allow any holdout validation for fixed values (except for z)
        setappdata(0,'CIIE',0);setappdata(0,'CId',0);setappdata(0,'CIbA',0);
        setappdata(0,'CIbM',0);
    case 3
        %Basic maximum likelihood model
        %reset the GUI
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        set(handles.cboOptimization,'Enable','on');
        set(handles.cboOptimization,'String',{'Gradient','Derivative Free','Fixed Point'});
        set(handles.cboOptimization,'Value',CurOptimization);
        %Cannot allow confidence intervals for IE
        setappdata(0,'CIIE',0);
        %Holdout validation
        setappdata(0,'HOIE',0);     
    case 4   %Multiplicative item easiness
        %reset GUI
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        set(handles.cboOptimization,'Enable','on');
        set(handles.cboOptimization,'String',{'Gradient','Derivative Free','Fixed Point'});
        set(handles.cboOptimization,'Value',CurOptimization);
    case 5   %Additive item easiness
        %reset GUI
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        set(handles.cboOptimization,'Enable','on');
        %Change the avaialable options in optimiziation pop-up menu
        set(handles.cboOptimization,'String',{'Gradient','Derivative Free'});
        if CurOptimization==3
          message='Fixed Point optimization is not available for the additive item easiness model. The optimization method has defaulted to Gradient. Click the OK button to continue.';
          h=msgbox(message,'FlexCCT Message');
          javaFrame = get(handle(h),'JavaFrame');
          javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
          uiwait(h);
          set(handles.cboOptimization,'Value',1);
        else
          set(handles.cboOptimization,'Value',CurOptimization);
        end
end

function SetBiasOptions(CallType,handles)
selectedOption=get(handles.cboBiasType,'Value');
switch selectedOption
  case 1
    setappdata(0,'FixbA',1); %Cannot fix the bias if not available
    setappdata(0,'FixbM',1);
    setappdata(0,'CIbA',0);
    setappdata(0,'CIbM',0);
    setappdata(0,'HObA',0);
    setappdata(0,'HObM',0);
  case 2
    %Additive bias only
    setappdata(0,'FixbM',1);
    setappdata(0,'CIbM',0);
    setappdata(0,'HObM',0);
  case 3
    %Multiplicative bias onlly
    setappdata(0,'FixbA',1);
    setappdata(0,'CIbA',0);
    setappdata(0,'HObA',0);
  case 4
    %Don't reset anythin.  Additive and multiplicative biases are 0
end


% --- Executes during object creation, after setting all properties.
function cboEstimation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboEstimation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cboBiasType.
function cboBiasType_Callback(hObject, eventdata, handles)
% hObject    handle to cboBiasType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboBiasType contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboBiasType

%Get the current value of the bias type, which is the value - 1
%  SetOptimizationOptions(1,handles);
%SF 8/01/2013 - Remove as fixed point can now cope with all bias types
SetBiasOptions(0,handles);

% --- Executes during object creation, after setting all properties.
function cboBiasType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboBiasType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cmdAddTraits.
function cmdAddTraits_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Combination
if get(handles.cmdCorrespond,'Value')==1
    set(handles.cmdAddTraits,'Value',1);
    set(handles.cmdCorrespond,'Value',0);
else
    set(handles.cmdAddTraits,'Value',1);
end

% --- Executes on button press in cmdCorrespond.
function cmdCorrespond_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Combination
if get(handles.cmdAddTraits,'Value')==1
    set(handles.cmdAddTraits,'Value',0);
    set(handles.cmdCorrespond,'Value',1);
else
    set(handles.cmdCorrespond,'Value',1);
end



% --- Executes on button press in cmdNone.
function cmdNone_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Standardization
if get(handles.cmdRange,'Value')==1 || get(handles.cmdStandardize,'Value')|| get(handles.cmdLog,'Value')==1 
    set(handles.cmdNone,'Value',1);
    set(handles.cmdStandardize,'Value',0);
    set(handles.cmdRange,'Value',0);
    set(handles.cmdLog,'Value',0);
else
    set(handles.cmdNone,'Value',1);
end 


% --- Executes on button press in cmdStandardize.
function cmdStandardize_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Standardization
if get(handles.cmdRange,'Value')==1 || get(handles.cmdStandardize,'Value')|| get(handles.cmdLog,'Value')==1 
    set(handles.cmdNone,'Value',0);
    set(handles.cmdStandardize,'Value',1);
    set(handles.cmdRange,'Value',0);
    set(handles.cmdLog,'Value',0);
else
    set(handles.cmdStandardize,'Value',1);
end



% --- Executes on button press in cmdRange.
function cmdRange_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Standardization
if get(handles.cmdNone,'Value')==1 || get(handles.cmdStandardize,'Value')|| get(handles.cmdLog,'Value')==1 
    set(handles.cmdNone,'Value',0);
    set(handles.cmdStandardize,'Value',0);
    set(handles.cmdRange,'Value',1);
    set(handles.cmdLog,'Value',0);
else
    set(handles.cmdRange,'Value',1);
end

% --- Executes on button press in cmdLog.
function cmdLog_Callback(hObject, eventdata, handles)
% hObject    handle to cmdLog (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Manage Radio Buttons on Data Standardization
if get(handles.cmdNone,'Value')==1 || get(handles.cmdStandardize,'Value')|| get(handles.cmdRange,'Value')==1 
    set(handles.cmdNone,'Value',0);
    set(handles.cmdStandardize,'Value',0);
    set(handles.cmdRange,'Value',0);
    set(handles.cmdLog,'Value',1);
else
    set(handles.cmdRange,'Value',1);
end


function txtMissingValue_Callback(hObject, eventdata, handles)
% hObject    handle to txtMissingValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtMissingValue as text
%        str2double(get(hObject,'String')) returns contents of txtMissingValue as a double


% --- Executes during object creation, after setting all properties.
function txtMissingValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtMissingValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over cmdCorrespond.
function cmdCorrespond_ButtonDownFcn(hObject, eventdata, handles)
try
    %do nothing
catch err
end


% --- Executes when user attempts to close mainform.
function mainform_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to mainform (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = MFquestdlg([0.3,0.5],'Are you sure that you would like to close the GUI?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes',
delete(hObject);
case 'No'
return
end %switch


% --- Executes on button press in chkHeaderRow.
function chkHeaderRow_Callback(hObject, eventdata, handles)
% hObject    handle to chkHeaderRow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkHeaderRow


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in cmdAdvanced.
function cmdAdvanced_Callback(hObject, eventdata, handles)
% hObject    handle to cmdAdvanced (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Load the advanced settings with the handles from the current GUI

try  
    set(gcf,'Pointer','watch');
    set(handles.cmdAdvanced,'enable','off');
    drawnow;

    
    %4.Estimation Method
    %for matching the returned value from cboEstimation pop-up menu (started
    %from 1) and the value of estimation method parameter (started from 0),
    %we need to reduce 1 from the cboEstimation pop-up value;
    setappdata(0,'EstMethod',get(handles.cboEstimation,'value'));
    %5.Bias Type
    %for matching the returned value from cboBiasType pop-up menu (started
    %from 1) and the value of bias type parameter (started from 0),
    %we need to reduce 1 from the cboBiasType pop-up value;
    setappdata(0,'BiasType',get(handles.cboBiasType,'value'));

    %6.Optimization Method
    %Notice: we arrange as follows because changing the Estimation Method option
    %will change available options in optimization method and with this arrangement
    %the returned value from pop-up menu always match to the fixed option 
    %pop-up menu values: (SF 8/1/2013 - Swapped 3 and 4 to put fixed point
    %first)
    %   1=Gradient
    %   2=Derivative Free
    %   3=Fixed Point
    %However the function's input values are compeletly different
    %   0=Fixed Point
    %   1=Two Stage Fixed Point
    %   2=Derivative Free
    %   3=Gradient
    OptMethod=get(handles.cboOptimization,'value');
    %slf-8/29 removed item variance and alligned FlexCCT with values
    %in the 
    setappdata(0,'OptMethod',OptMethod);

    %7.Converge
    setappdata(0,'Converge',str2double(get(handles.txtConverge,'string')));

    %8.Maximum Iteration 
    setappdata(0,'MaxIter',1000);

    %9.Missing Value
    setappdata(0,'MissingVal',str2num(get(handles.txtMissingValue,'string')));

    %10.D Max
    setappdata(0,'DMax',str2num(get(handles.txtdMax,'string')));

    %11.IE Max
    setappdata(0,'IEMax',str2num(get(handles.txtIEMax,'string')));

    %end variable assignment
    
    set(gcf,'Pointer','arrow');
    drawnow;
    h=Advanced();

    set(handles.cmdAdvanced,'enable','on');
    
    %Processed the advanced options
    

catch err
  set(gcf,'Pointer','arrow');
  set(handles.cmdAdvanced,'enable','on');
  drawnow;
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h);
end

% --- Executes on button press in chkRowHeaders.
function chkRowHeaders_Callback(hObject, eventdata, handles)
% hObject    handle to chkRowHeaders (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkRowHeaders


% --- Executes on button press in chkColHeaders.
function chkColHeaders_Callback(hObject, eventdata, handles)
% hObject    handle to chkColHeaders (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkColHeaders


% --- Executes on button press in cmdScree.
function cmdScree_Callback(hObject, eventdata, handles)
% hObject    handle to cmdScree (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try  
    set(gcf,'Pointer','watch');
    set(handles.cmdScree,'enable','off');
    drawnow;
    %do some stuff

    %load data into the X variable
    X=importdata(get(handles.txtDataFile,'string'),',');
    [X,zGround,HasColHeader,HasRowHeader,ColHeader,RowHeader,MissingVal] = ProcessFile(X,handles);

   %For the moment default at 20
    MaxDim = 21;
    
    %run the FlexCCT
    [EigOut,NoEig] = MinResEigFA(X,MissingVal,MaxDim);
    
    setappdata(0,'EigOut',EigOut);
    setappdata(0,'NoEig',NoEig);
    set(gcf,'Pointer','arrow');
    drawnow;
    Scree;
    set(handles.cmdScree,'enable','on');
    
    
catch err
  set(gcf,'Pointer','arrow');
  set(handles.cmdScree,'enable','on');
  drawnow;
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h);   
end



% --- Executes on button press in cmdValidation.
function cmdValidation_Callback(hObject, eventdata, handles)
% hObject    handle to cmdAdvanced (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Load the advanced settings with the handles from the current GUI

  try  
    set(gcf,'Pointer','watch');
    set(handles.cmdValidation,'enable','off');
    drawnow;

    
    %4.Estimation Method
    %for matching the returned value from cboEstimation pop-up menu (started
    %from 1) and the value of estimation method parameter (started from 0),
    %we need to reduce 1 from the cboEstimation pop-up value;
    setappdata(0,'EstMethod',get(handles.cboEstimation,'value'));
    %5.Bias Type
    %for matching the returned value from cboBiasType pop-up menu (started
    %from 1) and the value of bias type parameter (started from 0),
    %we need to reduce 1 from the cboBiasType pop-up value;
    setappdata(0,'BiasType',get(handles.cboBiasType,'value'));

    %6.Optimization Method
    %Notice: we arrange as follows because changing the Estimation Method option
    %will change available options in optimization method and with this arrangement
    %the returned value from pop-up menu always match to the fixed option 
    %pop-up menu values: (SF 8/1/2013 - Swapped 3 and 4 to put fixed point
    %first)
    %   1=Gradient
    %   2=Derivative Free
    %   3=Fixed Point
    %However the function's input values are compeletly different
    %   0=Fixed Point
    %   1=Two Stage Fixed Point
    %   2=Derivative Free
    %   3=Gradient
    
    OptMethod=get(handles.cboOptimization,'value');
    %slf-8/29 removed item variance and alligned FlexCCT with values
    %in the 
    setappdata(0,'OptMethod',OptMethod);

    %7.Converge
    setappdata(0,'Converge',str2double(get(handles.txtConverge,'string')));

    %8.Maximum Iteration 
    setappdata(0,'MaxIter',1000);

    %9.Missing Value
    setappdata(0,'MissingVal',str2num(get(handles.txtMissingValue,'string')));

    %10.D Max
    setappdata(0,'DMax',str2num(get(handles.txtdMax,'string')));

    %11.IE Max
    setappdata(0,'IEMax',str2num(get(handles.txtIEMax,'string')));

    %Set the application data for the text file
    FileName=get(handles.txtDataFile,'string');
    if (isempty(FileName)==false)&&(strcmp(FileName,'')==false)
      X=importdata(FileName,',');
      [X,zGround,HasColHeader,HasRowHeader,ColHeader,RowHeader,MissingVal] = ProcessFile(X,handles);
      [n,m]=size(X);
      NoRatings=size(find(X~=MissingVal),1);
      setappdata(0,'HasFile',1);
      setappdata(0,'NoRaters',n);
      setappdata(0,'NoItems',m);
      setappdata(0,'NoRatings',NoRatings);
    else
      setappdata(0,'HasFile',0);
    end
    
    set(gcf,'Pointer','arrow');
    drawnow;
    h=Validation();

    set(handles.cmdValidation,'enable','on');
    
catch err
  set(gcf,'Pointer','arrow');
  set(handles.cmdValidation,'enable','on');
  drawnow;
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h);
end


% --- Executes on button press in chkGroundTruth.
function chkGroundTruth_Callback(hObject, eventdata, handles)
% hObject    handle to chkGroundTruth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkGroundTruth
 
  if (getappdata(0,'RunGroundTruth')==1)&&(get(handles.cboOptimization,'value')==0);
    setappdata(0,'RunGroundTruth',0);
    message='Ground truth validation not allowed when no ground truth is selected. The ground truth validation setting been returned to off. Click the OK button to continue.';
    h=msgbox(message,'FlexCCT Message');
    javaFrame = get(handle(h),'JavaFrame');
    javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
    uiwait(h);
  end


% --- Executes on button press in cmdBatch.
function cmdBatch_Callback(hObject, eventdata, handles)
% hObject    handle to cmdBatch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try  
  set(gcf,'Pointer','watch');
  set(handles.cmdBatch,'enable','off');
  drawnow;
  set(gcf,'Pointer','arrow');
  h=Batch();
  set(handles.cmdBatch,'enable','on');
catch err
  set(gcf,'Pointer','arrow');
  set(handles.cmdBatch,'enable','on');
  drawnow;
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h);
end
