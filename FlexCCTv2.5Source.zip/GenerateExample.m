function [X,D,z,Bias] = GenerateExample(NoItems,NoUsers,MinVal,MaxVal,TrueDist,MissingPC,Scheme,RangeDivisor,HasAddBias,HasMultBias)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

  Range=MaxVal-MinVal;
  Centre=MinVal+Range/2;

  if TrueDist==1
    %Sample from normal distribution with mean at the center
    %point and with 1 standard devation = 1/6 range
    z = norminv(rand(1,NoItems),Centre,Range/6);
  else
    %Sample from uniform distribution
    z=(rand(1,NoItems).*Range)+1;
  end
  
  %Determine latent competencies for users
  Mind=(Range/3)^(-2);
  Midd=(Range/6)^(-2);
  Maxd=(Range/9)^(-2);
  switch Scheme
  case 1
    %Select all users to have the average competancy
    D=ones(NoUsers,1).*Midd;
  case 2
    %Random competencies between min and max
    D=Mind+rand(NoUsers,1).*(Maxd-Mind);
  case 3
    %75% competent and 25% not competent
    IsComp=rand(NoUsers,1)>0.25;
  case 4
    %50% competent and 50% not competent
    IsComp=rand(NoUsers,1)>0.5;
  case 5 
    %25% competent and 75% not competent
    IsComp=rand(NoUsers,1)>0.75;              
  end
  switch Scheme
    case {3,4,5}
    %Users competent if one and not competent if 0
    D=IsComp.*Maxd+(1-IsComp).*Mind;
  end 
  
  if HasAddBias==true
    %Select biases based upon the range divisor
    AddBias= norminv(rand(NoUsers,1),0,Range/(RangeDivisor+2));
  else
    AddBias=zeros(NoUsers,1);
  end
  if HasMultBias==true
    ScaleMatrix=ones(NoUsers,2);
    AssignIndexes=[1:NoUsers]+floor(rand(NoUsers,1)*2)'*NoUsers;
    ScaleMatrix(AssignIndexes)=rand(NoUsers,1)/2+1;
    MultBias=ScaleMatrix(:,1)./ScaleMatrix(:,2);
  else
    %No multiplicative biases
    MultBias=ones(NoUsers,1);
  end
  Bias=[AddBias,MultBias];
  
  %Now sample an answer key given the competency and the true
  %score
  %Sample an error matrix based on competencies
  Error=zeros(NoUsers,NoItems);
  for i=1:NoUsers
    P=rand(1,NoItems);
    Error(i,:) = norminv(P,0,(D(i)^(-0.5)));
  end  
  
  %Add the error to the actual values of the items
  X=MultBias*z+AddBias*ones(1,NoItems)+Error;
  X=min(max(MinVal,X),MaxVal);   %Ensure in bounds
  %Replace any missing data by -1
  IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
  AllAssigned=isempty(find(sum(1-IsMissing,1)==0))&&isempty(find(sum(1-IsMissing,2)==0));
  while (AllAssigned==0)
    IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
    [IsMissing,AllAssigned]=FixMissing(IsMissing,1000);
  end
  X=-IsMissing+(1-IsMissing).*X;
  
  

end

