function [F,Residual] = PrincipalAxesFA(Corr,Epsilon,Factors,Common)
%Performs an iterative principal axes factor analysis.  At each stage,
%the communalities are estimated and placed on the diagonal. 
%Inputs
%Corr    -  The input correlation matrix with 1 on the diagonals
%Epsilon - The convergence criteria (as total change in the communalities)
%Factors -  Optional the starting commonalities, defaults to 0.5.
%Outputs
%F -        The n*Factors matrix of factors
%Residual - Corr-DD'
%Version     Author            Date
%   0.10     Stephen France    04/01/2012

n=size(Corr,1);
%Set initial commonalities 
if ~exist('Common','var')
  Common=ones(n,1).*0.5;
end

AverageChange=Epsilon+1;
Iteration = 0;

while (AverageChange>Epsilon)&&(Iteration<10000)
  Iteration=Iteration+1;
  %Remove initial diagonal
  Corr=Corr-diag(diag(Corr))+diag(Common);  
  %Calculate factor loadings
  [UAll,DAll] = eig(Corr);
  %Matlab doesn't guarantee order of eigenvalues
  DDiag=diag(DAll);
  [B,IX]=sort(DDiag,'descend');
  U=UAll(:,IX(1:Factors));
  D=DAll(IX(1:Factors),IX(1:Factors));
  %Communalities are squares of factor loading
  F=U*(D.^0.5);
  OldCommon=Common;
  Common=sum((F.^2),2);
  AverageChange=sum(abs((OldCommon-Common)))./n;
end
if sum(F)<=0
  F=-F;
end
%Calculate residuals
Residual=Corr-(F*F');

