function varargout = gui(varargin)
% GUI MATLAB code for gui.fig
%      GUI, by itself, creates a new GUI or raises the existing
%      singleton*.
%
%      H = GUI returns the handle to a new GUI or the handle to
%      the existing singleton*.
%
%      GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI.M with the given input arguments.
%
%      GUI('Property','Value',...) creates a new GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui

% Last Modified by GUIDE v2.5 12-Jun-2013 11:10:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui is made visible.
function gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui (see VARARGIN)

% Choose default command line output for gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function txtDataFile_Callback(hObject, eventdata, handles)
% hObject    handle to txtDataFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtDataFile as text
%        str2double(get(hObject,'String')) returns contents of txtDataFile as a double


% --- Executes during object creation, after setting all properties.
function txtDataFile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtDataFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cmdBrowse.
function cmdBrowse_Callback(hObject, eventdata, handles)
%------
[FileName,FilePath]=uigetfile('*.csv');
ExPath = [FilePath FileName];
set(handles.txtDataFile,'String',ExPath);
guidata(hObject, handles);

function cmdTraits_Callback(hObject, eventdata, handles)
numTraits=str2num(get(handles.cmdTraits,'string'));
% if the number of traites equal to 1
% disable the Correspondance Analysis option 
% selet the Add Traits option
if numTraits==1
    set(handles.cmdCorrespond,'enable','off')
    set(handles.cmdCorrespond,'value',0);
    set(handles.cmdAddTraits,'value',1);
% if the number of traites is bigger than 1
% Enable Correspondance Analysis
elseif numTraits>1
    set(handles.cmdCorrespond,'enable','on')
% if the user inputs any digit less than 1 or any characters
% the GUI will back to it's default settings 
else
    set(handles.cmdTraits,'string','1');
    set(handles.cmdCorrespond,'enable','off')
    set(handles.cmdCorrespond,'value',0);
    set(handles.cmdAddTraits,'value',1);
end
    


% --- Executes during object creation, after setting all properties.
function cmdTraits_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cmdTraits (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cmdRun.
function cmdRun_Callback(hObject, eventdata, handles)
%load data into the X variable
X=load(get(handles.txtDataFile,'string'));


%set input variables of the funcation

%1.num traits
NoTraits=str2num(get(handles.cmdTraits,'string'));

%2.data combination
%set data combination value based on selected option
if get(handles.cmdAddTraits,'value')==1
    DATCombine=0;
elseif get(handles.cmdCorrespond,'value')==1
    DATCombine=1;
end

%3.data standardization
%set the value based on selected option
if get(handles.cmdNone,'value')==1
    DATStandard=0;
elseif get(handles.cmdStandardize,'value')==1
    DATStandard=1;
elseif get(handles.cmdRange,'value')==1
    DATStandard=2;
end

%4.Estimation Method
%for matching the returned value from cboEstimation pop-up menu (started
%from 1) and the value of estimation method parameter (started from 0),
%we need to reduce 1 from the cboEstimation pop-up value;
EstMethod=get(handles.cboEstimation,'value')-1;

%5.Bias Type
%for matching the returned value from cboBiasType pop-up menu (started
%from 1) and the value of bias type parameter (started from 0),
%we need to reduce 1 from the cboBiasType pop-up value;
BiasType=get(handles.cboBiasType,'value')-1;

%6.Optimization Method
%Notice: we arrange as follows because changing the Estimation Method option
%will change available options in optimization method and with this arrangement
%the returned value from pop-up menu always match to the fixed option 
%pop-up menu values:
%   1=Gradient
%   2=Derivative Free
%   3=Two Stage Fixed Point
%   4=Fixed Point
%However the function's input values are compeletly different
%   0=Fixed Point
%   1=Two Stage Fixed Point
%   2=Derivative Free
%   3=Gradient
selectedOption=get(handles.cboOptimization,'value');
switch selectedOption
    case 1
        OptMethod=3;
    case 2
        OptMethod=2;
    case 3
        OptMethod=1;
    case 4
        OptMethod=0;
end

%7.Converge
Converge=str2double(get(handles.txtConverge,'string'));

%8.Maximum Iteration 
MaxIter=1000;

%9.Missing Value
MissingVal=str2num(get(handles.txtMissingValue,'string'));

%10.D Max
DMax=str2num(get(handles.txtdMax,'string'));

%11.IE Max
IEMax=str2num(get(handles.txtIEMax,'string'));

%end variable assignment


%run the FlexCCTv1
if EstMethod==0 || EstMethod==1
    [z,D,Bias,QE,MaxCrit,LLPartial] = FlexCCTv1(X,NoTraits,DATCombine,DATStandard,EstMethod,BiasType,OptMethod,Converge,MaxIter,MissingVal)
elseif EstMethod==2 
    [z,D,Bias,QE,MaxCrit,LLPartial] = FlexCCTv1(X,NoTraits,DATCombine,DATStandard,EstMethod,BiasType,OptMethod,Converge,MaxIter,MissingVal,DMax)
else 
    [z,D,Bias,QE,MaxCrit,LLPartial] = FlexCCTv1(X,NoTraits,DATCombine,DATStandard,EstMethod,BiasType,OptMethod,Converge,MaxIter,MissingVal,DMax,IEMax)
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in cmdDefault.
function cmdDefault_Callback(hObject, eventdata, handles)
%Set default values in GUI
set(handles.txtDataFile,'string','');
set(handles.cmdTraits,'string','1');
set(handles.cmdAddTraits,'Value',1);
set(handles.cmdCorrespond,'Value',0);
set(handles.cmdCorrespond,'enable','off');
set(handles.cmdNone,'Value',1);
set(handles.cmdStandardize,'Value',0);
set(handles.cmdRange,'Value',0);
set(handles.cboEstimation,'Value',3);
set(handles.cboBiasType,'Value',1);
set(handles.cboOptimization,'Value',1);
set(handles.txtMissingValue,'string','-1');
set(handles.txtConverge,'string','1e-6');
set(handles.txtdMax,'string','10');
set(handles.txtIEMax,'string','10');


% --- Executes on selection change in cboOptimization.
function cboOptimization_Callback(hObject, eventdata, handles)
% hObject    handle to cboOptimization (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboOptimization contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboOptimization


% --- Executes during object creation, after setting all properties.
function cboOptimization_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboOptimization (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtConverge_Callback(hObject, eventdata, handles)
converge=str2double(get(handles.txtConverge,'string'));
%if the value is less than zero or not a number change it to default one 
if converge>0
    %do nothing
else
    set(handles.txtConverge,'string','1e-6');
end


% --- Executes during object creation, after setting all properties.
function txtConverge_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtConverge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtdMax_Callback(hObject, eventdata, handles)
% hObject    handle to txtdMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtdMax as text
%        str2double(get(hObject,'String')) returns contents of txtdMax as a double


% --- Executes during object creation, after setting all properties.
function txtdMax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtdMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtIEMax_Callback(hObject, eventdata, handles)
% hObject    handle to txtIEMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtIEMax as text
%        str2double(get(hObject,'String')) returns contents of txtIEMax as a double


% --- Executes during object creation, after setting all properties.
function txtIEMax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtIEMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cboEstimation.
function cboEstimation_Callback(hObject, eventdata, handles)
%get the selected option in Estimation pop-up menu
selectedOption=get(handles.cboEstimation,'Value');
% 1:Simple Average
% 2:Factor Analysis
% 3:ML Model
% 4:IE Error Variance
% 5:IE Multiply
% 6:IE Add

switch selectedOption
    case 1
        %reset the GUI
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        set(handles.cboOptimization,'Enable','on');
        set(handles.cboOptimization,'Value',1);
        set(handles.cboOptimization,'String',{'Gradient','Derivative Free','Two Stage Fixed Point','Fixed Point'});
    case 2
        %in cboBiasType, Value 1 is stands for 'No Bias'
        set(handles.cboBiasType,'Value',1);
        %Disable bias pop-up menu when Factor Analysis is selected
        set(handles.cboBiasType,'Enable','off');
        %invisible the optimization options 
        set(handles.cboOptimization,'Visible','off');
        %set the optimization method to the fixed point. Although this option
        %should be invisible, we need to pass 0 for optimization when the 
        %factor analysis is selected.So, we set the optimization to fixed point
        %which will return 0
        set(handles.cboOptimization,'Value',4);
    case 3
        %reset the GUI
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        set(handles.cboOptimization,'Enable','on');
        set(handles.cboOptimization,'Value',1);
        set(handles.cboOptimization,'String',{'Gradient','Derivative Free','Two Stage Fixed Point','Fixed Point'});
        
    case 4
        %reset GUI
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        %in cboOptimization, Value 1 stands for 'Gradient'
        set(handles.cboOptimization,'Value',1);
        %Disable the optimization pop-up menu, so the user cannot change
        %the predefined selected option (Gradient)
        set(handles.cboOptimization,'Enable','off');
    case 5
        %reset GUI
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        set(handles.cboOptimization,'Enable','on');
        set(handles.cboOptimization,'Value',1);
        set(handles.cboOptimization,'String',{'Gradient','Derivative Free','Two Stage Fixed Point','Fixed Point'});
    case 6
        %reset GUI
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        set(handles.cboOptimization,'Enable','on');
        %Change the avaialable options in optimiziation pop-up menu
        set(handles.cboOptimization,'String',{'Gradient','Derivative Free'});
        set(handles.cboOptimization,'Value',1);          
end







% --- Executes during object creation, after setting all properties.
function cboEstimation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboEstimation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cboBiasType.
function cboBiasType_Callback(hObject, eventdata, handles)
% hObject    handle to cboBiasType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboBiasType contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboBiasType


% --- Executes during object creation, after setting all properties.
function cboBiasType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboBiasType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cmdAddTraits.
function cmdAddTraits_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Combination
if get(handles.cmdCorrespond,'Value')==1
    set(handles.cmdAddTraits,'Value',1);
    set(handles.cmdCorrespond,'Value',0);
else
    set(handles.cmdAddTraits,'Value',1);
end

% --- Executes on button press in cmdCorrespond.
function cmdCorrespond_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Combination
if get(handles.cmdAddTraits,'Value')==1
    set(handles.cmdAddTraits,'Value',0);
    set(handles.cmdCorrespond,'Value',1);
else
    set(handles.cmdCorrespond,'Value',1);
end



% --- Executes on button press in cmdNone.
function cmdNone_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Standardization
if get(handles.cmdRange,'Value')==1 || get(handles.cmdStandardize,'Value')==1 
    set(handles.cmdNone,'Value',1);
    set(handles.cmdStandardize,'Value',0);
    set(handles.cmdRange,'Value',0);
else
    set(handles.cmdNone,'Value',1);
end 


% --- Executes on button press in cmdStandardize.
function cmdStandardize_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Standardization
if get(handles.cmdRange,'Value')==1 || get(handles.cmdNone,'Value')==1 
    set(handles.cmdNone,'Value',0);
    set(handles.cmdStandardize,'Value',1);
    set(handles.cmdRange,'Value',0);
else
    set(handles.cmdStandardize,'Value',1);
end



% --- Executes on button press in cmdRange.
function cmdRange_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Standardization
if get(handles.cmdNone,'Value')==1 || get(handles.cmdStandardize,'Value')==1 
    set(handles.cmdNone,'Value',0);
    set(handles.cmdStandardize,'Value',0);
    set(handles.cmdRange,'Value',1);
else
    set(handles.cmdRange,'Value',1);
end




function txtMissingValue_Callback(hObject, eventdata, handles)
% hObject    handle to txtMissingValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtMissingValue as text
%        str2double(get(hObject,'String')) returns contents of txtMissingValue as a double


% --- Executes during object creation, after setting all properties.
function txtMissingValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtMissingValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
