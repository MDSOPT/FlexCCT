
n=size(CI,1);
VName='test';

plot(1:n,CI(:,1),'o','markersize', 1,'MarkerEdgeColor','k','MarkerFaceColor','k')
hold on;
plot(1:n,CI(:,2),'^','markersize', 1,'MarkerEdgeColor','k','MarkerFaceColor','k')              % plot lower CI boundary
hold on;

plot(1:n,CI(:,3),'V','markersize', 1,'MarkerEdgeColor','k','MarkerFaceColor','k')              % plot upper CI boundary
hold on;

for I = 1:length(CI)                                        % connect upper and lower bound with a line
line([I I],[CI(I,2) CI(I,3)])
hold on;
end;

axis([0 length(CI)+1 min(CI(:,2))*0.9 max(CI(:,3))*1.1]);  % scale axis
xlabel('My parameter');
xticklabels({'-3\pi','-2\pi','-\pi','0','\pi','2\pi','3\pi'})
title('95% Confidence');
hold off;
