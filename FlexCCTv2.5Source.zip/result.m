% Outputs the CCT MModel results into a results table.  Gives options for exporting
% results and managing residuals.
%Version     Author            Date
%   0.10     Mahyar Vaghefi    01/30/2014
%   2.00     Stephen France    04/02/2016
function varargout = result(varargin)
% RESULT MATLAB code for result.fig
%      RESULT, by itself, creates a new RESULT or raises the existing
%      singleton*.
%
%      H = RESULT returns the handle to a new RESULT or the handle to
%      the existing singleton*.
%
%      RESULT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RESULT.M with the given input arguments.
%
%      RESULT('Property','Value',...) creates a new RESULT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before result_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to result_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help result

% Last Modified by GUIDE v2.5 04-Feb-2017 06:08:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @result_OpeningFcn, ...
                   'gui_OutputFcn',  @result_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% End initialization code - DO NOT EDIT


% --- Executes just before result is made visible.
function result_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to result (see VARARGIN)

% Choose default command line output for result
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

javaFrame = get(handle(hObject),'JavaFrame');
javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));

%Only enable the confidence interval button if confidence intervals are
%available
if (getappdata(0,'HasRaterBootstrap')==true)||(getappdata(0,'HasItemBootstrap')==true)
  set(handles.cmdPlotCI,'enable','on');
else
  set(handles.cmdPlotCI,'enable','off');
end

%Set the column names and the overall data
colnames=getappdata(0,'colnames');
set(handles.resTable,'ColumnName',colnames);
data=getappdata(0,'data');
set(handles.resTable,'Data',data);


% UIWAIT makes result wait for user response (see UIRESUME)
% uiwait(handles.result);


% --- Outputs from this function are returned to the command line.
function varargout = result_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function resTable_CreateFcn(hObject, eventdata, handles)


% --- Executes on button press in cmdSave.
function cmdSave_Callback(hObject, eventdata, handles)
try
  %get the filepath to save the file
  [FileName,FilePath]=uiputfile({'*.csv'},'Save Results');
  ExPath = [FilePath FileName];
  %load data in variables
  ColNames=getappdata(0,'colnames');
  data=getappdata(0,'data');
  if(FileName~=0)
    %save the file in CSV format
    CreateCSV(ExPath,ColNames,data);
  end
catch err
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h); 
end

% --- Executes on button press in canButton.
function canButton_Callback(hObject, eventdata, handles)
selection = MFquestdlg([0.3,0.5],'Are you sure that you would like to close the results pane?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes',
delete(gcf);
case 'No'
return
end %switch


% --- Executes when user attempts to close result.
function result_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to result (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
selection =MFquestdlg([0.3,0.5],'Are you sure that you would like to close the results pane?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes',
delete(hObject);
case 'No'
return
end %switch



% --- Executes on button press in cmdSaveRes.
function cmdSaveRes_Callback(hObject, eventdata, handles)
% hObject    handle to cmdSaveRes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
  %get the filepath to save the file
  [FileName,FilePath]=uiputfile({'*.csv'},'Save Residuals');
  ExPath = [FilePath FileName];
  %load data in variables
  ColNames=getappdata(0,'ColHeaderAll');
  RowNames=getappdata(0,'RowHeaderAll');
  ResidualsAll=getappdata(0,'ResidualsAll');

  if(FileName~=0)
    %save the file in CSV format
    CreateCSV(ExPath,ColNames,ResidualsAll,RowNames);
  end
catch err
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h); 
end

% --- Executes on button press in cmdPlotRes.
function cmdPlotRes_Callback(hObject, eventdata, handles)
% hObject    handle to cmdPlotRes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
drawnow;
Residual;


% --- Executes on button press in cmdPlotCI.
function cmdPlotCI_Callback(hObject, eventdata, handles)
% hObject    handle to cmdPlotCI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
drawnow;
ConfidenceInterval;



% --- Executes on button press in cmdScatter.
function cmdScatter_Callback(hObject, eventdata, handles)
% hObject    handle to cmdScatter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
drawnow;
ParamScatter;
