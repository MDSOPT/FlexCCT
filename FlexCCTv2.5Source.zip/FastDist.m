function [D] = FastDist(X,Mode)
%A fast distance metric algorithm that uses matrix algebra to 
%create distance matrices more efficiently than the MATLAB pdist algorithm.
%The algorithm does not allow for any missing data
%INPUTS
% X An n*m item*feature distance matrix
% Mode - The distance metric to be used
%   1  - The Hamming Distance
%   2  - The Jaccard Distance
%   3  - The Euclidean Distance
%   4  - The Cosine distance
%   5  - The Correlation Distance
%OUTPUTS
%Version     Author            Date
%   1.00     Stephen France    04/26/2011 (for INDCLUS project)
%   2.00     Stephen France    04/02/2016
  [n,m]=size(X);

  switch Mode
    case {1,2}
      M11=X*X';
      M10=X*(1+X')-2.*(M11);
      M01=(1+X)*(X')-2.*(M11);
      if Mode==1
        D=(M10+M01);
      else
        D=(M10+M01)./(M11+M10+M01);
        D(find(isnan(D)))=0;
      end
    case {3,4,5}
      if Mode==5
        %Mean center the row
        X=X-repmat(mean(X,2),n);
      end 
      if (Mode==4)||(Mode==5)
        X=X./repmat(sum(X.^2,2),1,n);
      end
      %Preprocess and then calculate the squared Euclidean distances
      Sqm=repmat(sum(X.^2,2),1,n);
      D=Sqm+Sqm'-2*(X)*(X');
      if Mode==3
        D=D.^0.5;
      end
  end

  

end

