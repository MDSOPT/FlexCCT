function [gRowIndexes,gColIndexes,MBlock1,MBlock2,Blocks,PseudoF] = BlockCluster(X,R,SplitMode,AllowFixed,SplitDirection,WeightParam,PermuteMode)
%Implements the Hartigan (1972) block clustering algorithm.
%algorithm. Use the loss of sum of squares as the partitioning criteria
%INPUTS
%X - An n*m matrix to be split into blocks
%R - The number of clusters to be found
%SplitMode - 0 Split using SSQ, 1 Split Using MSQ (as per Hartigan, 1972)
%AllowFixed - If true then allow fixed splits
%SplitDirection - 0 Allow both row and column splits
%               - 1 Allow only row splits
%               - 2 Allow only column splits
%WeightParam - The weight parameter for the termination criterion
%Permute - 0 neither rows or columns can be permuted
%        - 1 rows can be permuted, but not columns
%        - 2 Columns can be permuted, but not rows
%        - 3 Both rows and columns can be permuted
%OUTPUTS
%RowIndexes - The permutation of rows resulting from the algorithm
%ColIndexes - The permutation of columns resulting from the algorithm
%MBlock1 - An n*m cluster numbered block matrix with columns ordered so clusters
%   are not split (as per Harshmann in order of sum of squares).
%MBlock2 - An n*m cluster numbered block matrix with columns in the original
%   order and clusters possibly split.
%Blocks - The actual blocks, as defined in this function.
%PseudoF - A pseudo F statistic as per Calinski and Harabaasz (1972) - 
%        - An (R-1)*2 table with 2 to R in col 1 an pseudo F in col 2
%N.B. For indexes g-Global index,m-reordered indexes,l-local within block
%indexes
%Version     Author            Date
%   0.10     Stephen France    04/05/2012

[n,m]=size(X);
ColSums=sum(X,1);
RowSums=sum(X,2);
PseudoF=[];

if (PermuteMode==0)||(PermuteMode==1)
  %Columns cannot be permuted
  gColIndexes=find(ones(1,m));
  ColSums2=ColSums;
else
  [ColSums2,gColIndexes] = sort(ColSums);
end

if (PermuteMode==0)||(PermuteMode==2)
  %Rows cannot be permuted
  gRowIndexes=find(ones(1,n));
  RowSums2=RowSums;
else
  [RowSums2,gRowIndexes] = sort(RowSums);
end
    
%Calculate the current sum of squares
TotalSSQ=ssq(X);
RemainSSQ=TotalSSQ;
ReduceSSQ=0;

%Configure the initial block.  For ease, the reindexed values are used
Blocks.Count=1;
Blocks.ActiveCount=1;
Blocks.Data{1}=X(gRowIndexes,gColIndexes);
Blocks.Parent{1}=0;
Blocks.RowCount{1}=n; 
Blocks.ColCount{1}=m;
Blocks.mRowIndexes{1}=find(ones(1,n));  %Reordered indexes, not original
Blocks.mColIndexes{1}=find(ones(1,m));  %Indexes are at the matrix level
Blocks.ColMeans{1}=ColSums2./Blocks.RowCount{1};
Blocks.RowMeans{1}=RowSums2./Blocks.ColCount{1};
Blocks.RowFixed{1}=[];Blocks.ColFixed{1}=[]; %When storing fixed splits, give first row/col
Blocks.Active{1}=1;    

%FirstActiveBlock=1; %Prevents algorithm from having to sort through parent blocks


while (Blocks.ActiveCount<R)
  %Get a list of potential splits.  Splits are of form 
  %[Block,IsRow (1 if row, 0 if col),Index (row or col),IsFixed (1 if
  %fixed, 0 if free),RSS,MSQ
  AllSplits=[];
  for i=1:Blocks.Count
    if (Blocks.Active{i}==1); 
      if (SplitDirection==0)||(SplitDirection==1)
        Splits=CalculateSplits(SplitMode,Blocks.RowMeans{i},Blocks.RowCount{i},Blocks.ColCount{i},Blocks.RowFixed{i},WeightParam);
        NoSplits=size(Splits,1);
        SplitAdd=[ones(NoSplits,1).*i,ones(NoSplits,1),Splits];
        AllSplits=[AllSplits;SplitAdd];
      end
      if (SplitDirection==0)||(SplitDirection==2)
        Splits=CalculateSplits(SplitMode,Blocks.ColMeans{i},Blocks.ColCount{i},Blocks.RowCount{i},Blocks.ColFixed{i},WeightParam);
        NoSplits=size(Splits,1);
        SplitAdd=[ones(NoSplits,1).*i,zeros(NoSplits,1),Splits];
        AllSplits=[AllSplits;SplitAdd];
      end
    end
  end
  
  %Special termination criterion (complete homogeneity in blocks)
%   if (sum(AllSplits(:,6),1)==0)
%     'Terminate due to complete in-block homogeneity'
%     break; 
%   end
  
  %Find the best split and then create a new block 
  if (SplitMode==0)
    %Use SSQ
    [B,lIndex]=sort(AllSplits(:,5),1,'descend');
  else
    %Use MSQ
    [B,lIndex]=sort(AllSplits(:,6),1,'descend');
  end
  clear B
  %Split the block
  SplitItem=AllSplits(lIndex(1),:);
  i=SplitItem(1);   %Keep i as the block
  lSplitPos=SplitItem(3);
  Blocks.Active{i}=0;
  Blocks.Parent{Blocks.Count+1}=i;    %Ensure the tree structure of the clustering
  Blocks.Parent{Blocks.Count+2}=i;
  Blocks.Active{Blocks.Count+1}=1; 
  Blocks.Active{Blocks.Count+2}=1;

  if (SplitItem(2)==1)
    %Row split
    Blocks.Data{Blocks.Count+1}=Blocks.Data{i}(1:lSplitPos,:);
    Blocks.Data{Blocks.Count+2}=Blocks.Data{i}(lSplitPos+1:Blocks.RowCount{i},:);
    Blocks.RowCount{Blocks.Count+1}=lSplitPos;
    Blocks.RowCount{Blocks.Count+2}=Blocks.RowCount{i}-lSplitPos; 
    Blocks.ColCount{Blocks.Count+1}=Blocks.ColCount{i};
    Blocks.ColCount{Blocks.Count+2}=Blocks.ColCount{i};
    Blocks.mRowIndexes{Blocks.Count+1}=Blocks.mRowIndexes{i}(1:lSplitPos);
    Blocks.mRowIndexes{Blocks.Count+2}=Blocks.mRowIndexes{i}(lSplitPos+1:Blocks.RowCount{i});
    Blocks.mColIndexes{Blocks.Count+1}=Blocks.mColIndexes{i};
    Blocks.mColIndexes{Blocks.Count+2}=Blocks.mColIndexes{i};
    %Capture any remaining fixed splits
    Blocks.RowFixed{Blocks.Count+1}= find(Blocks.RowFixed{i}<lSplitPos);
    Blocks.RowFixed{Blocks.Count+2}= find(Blocks.RowFixed{i}>lSplitPos);
    Blocks.ColFixed{Blocks.Count+1}=Blocks.ColFixed{i};
    Blocks.ColFixed{Blocks.Count+2}=Blocks.ColFixed{i};
    Blocks.RowMeans{Blocks.Count+1}=Blocks.RowMeans{i}(1:lSplitPos);
    Blocks.RowMeans{Blocks.Count+2}=Blocks.RowMeans{i}(lSplitPos+1:Blocks.RowCount{i});
    %Must recalculate the column means
    Blocks.ColMeans{Blocks.Count+1}=sum(Blocks.Data{Blocks.Count+1},1)./Blocks.RowCount{Blocks.Count+1};
    Blocks.ColMeans{Blocks.Count+2}=sum(Blocks.Data{Blocks.Count+2},1)./Blocks.RowCount{Blocks.Count+2};  
    mSplitPos=Blocks.mRowIndexes{Blocks.Count+1}(lSplitPos); %The overall row index
  else
    %Column split    
    Blocks.Data{Blocks.Count+1}=Blocks.Data{i}(:,1:lSplitPos);
    Blocks.Data{Blocks.Count+2}=Blocks.Data{i}(:,lSplitPos+1:Blocks.ColCount{i});
    Blocks.RowCount{Blocks.Count+1}=Blocks.RowCount{i};
    Blocks.RowCount{Blocks.Count+2}=Blocks.RowCount{i};
    Blocks.ColCount{Blocks.Count+1}=lSplitPos;
    Blocks.ColCount{Blocks.Count+2}=Blocks.ColCount{i}-lSplitPos;
    Blocks.mRowIndexes{Blocks.Count+1}=Blocks.mRowIndexes{i};
    Blocks.mRowIndexes{Blocks.Count+2}=Blocks.mRowIndexes{i};
    Blocks.mColIndexes{Blocks.Count+1}=Blocks.mColIndexes{i}(1:lSplitPos);
    Blocks.mColIndexes{Blocks.Count+2}=Blocks.mColIndexes{i}(lSplitPos+1:Blocks.ColCount{i});
    %Capture any remaining fixed splits
    Blocks.RowFixed{Blocks.Count+1}= Blocks.RowFixed{i};
    Blocks.RowFixed{Blocks.Count+2}= Blocks.RowFixed{i};
    Blocks.ColFixed{Blocks.Count+1}=find(Blocks.ColFixed{i}<lSplitPos);
    Blocks.ColFixed{Blocks.Count+2}=find(Blocks.ColFixed{i}>lSplitPos);
    Blocks.ColMeans{Blocks.Count+1}=Blocks.ColMeans{i}(1:lSplitPos);
    Blocks.ColMeans{Blocks.Count+2}=Blocks.ColMeans{i}(lSplitPos+1:Blocks.ColCount{i});
    %Must recalculate the row means
    Blocks.RowMeans{Blocks.Count+1}=sum(Blocks.Data{Blocks.Count+1},2)./Blocks.ColCount{Blocks.Count+1};
    Blocks.RowMeans{Blocks.Count+2}=sum(Blocks.Data{Blocks.Count+2},2)./Blocks.ColCount{Blocks.Count+2};
    mSplitPos=Blocks.mColIndexes{Blocks.Count+1}(lSplitPos); %The overall col index
  end
  
  %Create needed new fixed splits.  Add split row/column if not already available
  %Logic is to create a fixed split that includes the split row (if row
  %split) or column (if column split)
  if (AllowFixed==1)
    for i=1:Blocks.Count
      if (Blocks.Active{i}==1); 
        if SplitItem(2)==1
          %Splitting rows
          MinPos=min(Blocks.mRowIndexes{i});MaxPos=min(Blocks.mRowIndexes{i});
          if (mSplitPos>=MinPos) && (mSplitPos<MaxPos)
            FixedPos=find(Blocks.RowFixed{i}==mSplitPos);
            if isempty(FixedPos)
              Blocks.RowFixed{i}=[Blocks.RowFixed{i},mSplitPos];
            end
          end
        else
          MinPos=min(Blocks.mColIndexes{i});MaxPos=min(Blocks.mColIndexes{i});
          if (mSplitPos>=MinPos) && (mSplitPos<MaxPos)
            FixedPos=find(Blocks.ColFixed{i}==mSplitPos);
            if isempty(FixedPos)
              Blocks.ColFixed{i}=[Blocks.ColFixed{i},mSplitPos];
            end
          end
        end
      end
    end
  end
  
  %Update the counter for the new blocks
  Blocks.Count=Blocks.Count+2;
  Blocks.ActiveCount=Blocks.ActiveCount+1;
  ReduceSSQ=ReduceSSQ+SplitItem(5);
  RemainSSQ=TotalSSQ-ReduceSSQ;
  FValue=(ReduceSSQ./(Blocks.ActiveCount-1))/(RemainSSQ./(n.*m-Blocks.ActiveCount));
  PseudoF=[PseudoF;[Blocks.ActiveCount,FValue]];
end

[MBlock1,MBlock2]=VisualizeBlocks(Blocks,gRowIndexes,gColIndexes);






