Rows=23:50;
DataFile='RatingsMatrix.csv';
ExpSpec='AAExpSpec.csv';

RowLength=length(Rows);
%First load the file
Spec=importdata(strcat(pwd,'\',ExpSpec),',');
if isnumeric(Spec)==0
  %data possibly contains some headers
  Spec=Spec.data;
end

X=importdata(strcat(pwd,'\',DataFile),',');
if isnumeric(X)==0
  %data possibly contains some headers
  X=X.data;
end
%Data has header
[n,m]=size(X);
X=X(2:n,2:m);

%Set standard parameters for each run
zGround=[];
ClusterOptions.NoCultures=1;
ClusterOptions.NoClusteringRuns=1;
ClusterOptions.ClusterBias=0;

CIOptions.CIz=0;
CIOptions.CId=0;
CIOptions.CIbadd=0;
CIOptions.CIbmult=0;
CIOptions.CIIE=0;
CIOptions.CIReplace=0;
CIOptions.HasRaterBootstrap=CIOptions.CId||CIOptions.CIbadd||CIOptions.CIbmult;
CIOptions.HasItemBootstrap=CIOptions.CIz||CIOptions.CIIE;

%We are only running the X Prediction holdout
VldOptions.HOz=0;
VldOptions.HOXPred=1;
VldOptions.HOd=0;
VldOptions.HObadd=0;
VldOptions.HObmult=0;
VldOptions.HOIE=0;

VldOptions.NoHoldout=1059;
VldOptions.MaxRuns=1000;
VldOptions.MSE=1;
VldOptions.MSPE=0;
VldOptions.MAE=1;
VldOptions.MAPE=0;
VldOptions.Correl=1;
VldOptions.RunGroundTruth=0;
VldOptions.HasHoldout=1;
VldOptions.HasHoldoutCriteria=1;
Converge=1e-6;
MaxIter=1000;
MissingVal=-1;
DMax=10;
IEMax=10;

for Counter=1:RowLength
  RowNo=Rows(Counter);
  %Get estimation details from the 
  EstMethod =Spec(RowNo,2);
  BiasType = Spec(RowNo,3);
  FixParams=Spec(RowNo,4:7);
  %Used fix point unless there is at least one -99 (average), which will
  %make sum <0
  if sum(FixParams)>=0
    OptMethod=3;
  else
    OptMethod=1;
  end

  [Results] = FlexCCT(X,zGround,ClusterOptions,CIOptions,VldOptions,EstMethod,BiasType,FixParams,OptMethod,Converge,MaxIter,MissingVal,DMax,IEMax);
  if (EstMethod==5)
    [Basic,CCT] = CCTReliabilityAdd3(Results.SX{1},MissingVal,Results.D{1},Results.Bias{1},Results.QE{1});
   else
     %Efficient routine with no missing data
     [Basic,CCT] = CCTReliability3(Results.SX{1},MissingVal,Results.D{1},Results.Bias{1},Results.QE{1});
   end
   %If running holdout validation with predictions, the sixth value is
   %the log-likelihood over the predicted data
   data=[Results.MaxCrit{1},Results.Holdout{1}.XPredHOMetrics.Values(6),Basic,CCT];
   FilePath=strcat('AAOut',int2str(RowNo),'.csv');
   
   csvwrite(FilePath,data);
  
end

