function varargout = guiV1P10(varargin)
% GUIV1P10 MATLAB code for guiV1P10.fig
%      GUIV1P10, by itself, creates a new GUIV1P10 or raises the existing
%      singleton*.
%
%      H = GUIV1P10 returns the handle to a new GUIV1P10 or the handle to
%      the existing singleton*.
%
%      GUIV1P10('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUIV1P10.M with the given input arguments.
%
%      GUIV1P10('Property','Value',...) creates a new GUIV1P10 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUIV1P10 before guiV1P10_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to guiV1P10_OpeningFcn via varargin.
%
%      *See GUIV1P10 Options on GUIDE's Tools menu.  Choose "GUIV1P10 allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help guiV1P10

% Last Modified by GUIDE v2.5 03-Aug-2015 16:24:29

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'guiV1P10_OpeningFcn', @guiV1P10_OpeningFcn, ...
                   'guiV1P10_OutputFcn',  @guiV1P10_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before guiV1P10 is made visible.
function guiV1P10_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to guiV1P10 (see VARARGIN)

% Choose default command line output for guiV1P10
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes guiV1P10 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = guiV1P10_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function txtDataFile_Callback(hObject, eventdata, handles)
% hObject    handle to txtDataFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtDataFile as text
%        str2double(get(hObject,'String')) returns contents of txtDataFile as a double


% --- Executes during object creation, after setting all properties.
function txtDataFile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtDataFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cmdBrowse.
function cmdBrowse_Callback(hObject, eventdata, handles)
%set the data file text box.
[FileName,FilePath]=uigetfile('*.csv');
ExPath = [FilePath FileName];
if(FileName~=0)
    set(handles.txtDataFile,'String',ExPath);
end

function cmdTraits_Callback(hObject, eventdata, handles)
numTraits=str2num(get(handles.cmdTraits,'string'));
% if the number of traites equal to 1
% disable the Correspondance Analysis option 
% selet the Add Traits option
if numTraits==1
    set(handles.cmdCorrespond,'enable','off')
    set(handles.cmdCorrespond,'value',0);
    set(handles.cmdAddTraits,'value',1);
% if the number of traites is bigger than 1
% Enable Correspondance Analysis
elseif numTraits>1
    set(handles.cmdCorrespond,'enable','on')
% if the user inputs any digit less than 1 or any characters
% the GUIV1P10 will back to it's default settings 
else
    set(handles.cmdTraits,'string','1');
    set(handles.cmdCorrespond,'enable','off')
    set(handles.cmdCorrespond,'value',0);
    set(handles.cmdAddTraits,'value',1);
end
    


% --- Executes during object creation, after setting all properties.
function cmdTraits_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cmdTraits (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cmdRun.
function cmdRun_Callback(hObject, eventdata, handles)

try  
    set(gcf,'Pointer','watch');
    set(handles.cmdRun,'enable','off');
    drawnow;
  %do some stuff

    %load data into the X variable
    X=load(get(handles.txtDataFile,'string'));
    %msgbox(num2str(size(X,2)));

    %set input variables of the funcation

    %1.num traits
    NoTraits=str2num(get(handles.cmdTraits,'string'));

    %2.data combination
    %set data combination value based on selected option
    if get(handles.cmdAddTraits,'value')==1
        DATCombine=0;
    elseif get(handles.cmdCorrespond,'value')==1
        DATCombine=1;
    end

    %3.data standardization
    %set the value based on selected option
    if get(handles.cmdNone,'value')==1
        DATStandard=0;
    elseif get(handles.cmdStandardize,'value')==1
        DATStandard=1;
    elseif get(handles.cmdRange,'value')==1
        DATStandard=2;
    end

    %4.Estimation Method
    %for matching the returned value from cboEstimation pop-up menu (started
    %from 1) and the value of estimation method parameter (started from 0),
    %we need to reduce 1 from the cboEstimation pop-up value;
    EstMethod=get(handles.cboEstimation,'value')-1;

    %5.Bias Type
    %for matching the returned value from cboBiasType pop-up menu (started
    %from 1) and the value of bias type parameter (started from 0),
    %we need to reduce 1 from the cboBiasType pop-up value;
    BiasType=get(handles.cboBiasType,'value')-1;

    %6.Optimization Method
    %Notice: we arrange as follows because changing the Estimation Method option
    %will change available options in optimization method and with this arrangement
    %the returned value from pop-up menu always match to the fixed option 
    %pop-up menu values: (SF 8/1/2013 - Swapped 3 and 4 to put fixed point
    %first)
    %   1=Gradient
    %   2=Derivative Free
    %   3=Fixed Point
    %   4=Two Stage Fixed Point
    %However the function's input values are compeletly different
    %   0=Fixed Point
    %   1=Two Stage Fixed Point
    %   2=Derivative Free
    %   3=Gradient
    selectedOption=get(handles.cboOptimization,'value');
    if (EstMethod==3)
      %Error variance method does not include derivative free
      switch selectedOption
          case 1
              OptMethod=3;
          case 2
              OptMethod=0;
          case 3
              OptMethod=1;
      end
    else
      %Error variance method does not include derivative free
      switch selectedOption
          case 1
              OptMethod=3;
          case 2
              OptMethod=2;
          case 3
              OptMethod=0;
          case 4
              OptMethod=1;
      end      
    end

    %7.Converge
    Converge=str2double(get(handles.txtConverge,'string'));

    %8.Maximum Iteration 
    MaxIter=1000;

    %9.Missing Value
    MissingVal=str2num(get(handles.txtMissingValue,'string'));

    %10.D Max
    DMax=str2num(get(handles.txtdMax,'string'));

    %11.IE Max
    IEMax=str2num(get(handles.txtIEMax,'string'));

    %end variable assignment

    %run the FlexCCTv1
    if EstMethod==0 || EstMethod==1
        [z,D,Bias,QE,MaxCrit,LLPartial,n,m] = FlexCCTv1(X,NoTraits,DATCombine,DATStandard,EstMethod,BiasType,OptMethod,Converge,MaxIter,MissingVal);
    elseif EstMethod==2 
        [z,D,Bias,QE,MaxCrit,LLPartial,n,m] = FlexCCTv1(X,NoTraits,DATCombine,DATStandard,EstMethod,BiasType,OptMethod,Converge,MaxIter,MissingVal,DMax);
    else 
        [z,D,Bias,QE,MaxCrit,LLPartial,n,m] = FlexCCTv1(X,NoTraits,DATCombine,DATStandard,EstMethod,BiasType,OptMethod,Converge,MaxIter,MissingVal,DMax,IEMax);
    end
    
    Maxnm=max(n,m);
    data=[MaxCrit;NaN.*ones(Maxnm-1,1)];
    data=[data,[D;NaN.*ones(Maxnm-n,1)],[Bias;NaN.*ones(Maxnm-n,2)]];
    data=[data,[z';NaN.*ones(Maxnm-m,1)],[QE';NaN.*ones(Maxnm-m,1)],[LLPartial';NaN.*ones(Maxnm-m,3)]];

    setappdata(0,'data',data);
    setappdata(0,'n',n);
    setappdata(0,'m',m);
    setappdata(0,'z',z);
    setappdata(0,'D',D);
    setappdata(0,'Bias',Bias);
    setappdata(0,'QE',QE);
    setappdata(0,'MaxCrit',MaxCrit);
    setappdata(0,'LLPartial',LLPartial);
    set(gcf,'Pointer','arrow');
    drawnow;
    result;
    set(handles.cmdRun,'enable','on');
    
%     %err.identifier
%     title='Error';
%     if (strcmp(err.identifier,'MATLAB:load:couldNotReadFile'))
%         msg='Could Not Read The File';
%         msg=err.message;
%         title='File Error';
%     elseif (strcmp(err.identifier,'MATLAB:load:emptyFileName'))
%         msg='Select The Data Input File';
%         msg=err.message;
%         title='File Error';
%     else
%         msg=err.message;
%         title=err.identifier;
%     end
    
catch err
    set(gcf,'Pointer','arrow');
    set(handles.cmdRun,'enable','off');
    drawnow;
   errordlg(err.message,err.identifier);  
end
    


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in cmdDefault.
function cmdDefault_Callback(hObject, eventdata, handles)
%Set default values in GUIV1P10
set(handles.txtDataFile,'string','');
set(handles.cmdTraits,'string','1');
set(handles.cmdAddTraits,'Value',1);
set(handles.cmdCorrespond,'Value',0);
set(handles.cmdCorrespond,'enable','off');
set(handles.cmdNone,'Value',1);
set(handles.cmdStandardize,'Value',0);
set(handles.cmdRange,'Value',0);
set(handles.cboEstimation,'Value',3);
set(handles.cboBiasType,'Value',1);
set(handles.cboOptimization,'Value',1);
set(handles.txtMissingValue,'string','-1');
set(handles.txtConverge,'string','1e-6');
set(handles.txtdMax,'string','10');
set(handles.txtIEMax,'string','10');


% --- Executes on selection change in cboOptimization.
function cboOptimization_Callback(hObject, eventdata, handles)
% hObject    handle to cboOptimization (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboOptimization contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboOptimization


% --- Executes during object creation, after setting all properties.
function cboOptimization_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboOptimization (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtConverge_Callback(hObject, eventdata, handles)
converge=str2double(get(handles.txtConverge,'string'));
%if the value is less than zero or not a number change it to default one 
if converge>0
    %do nothing
else
    set(handles.txtConverge,'string','1e-6');
end


% --- Executes during object creation, after setting all properties.
function txtConverge_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtConverge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtdMax_Callback(hObject, eventdata, handles)
dMax=str2double(get(handles.txtdMax,'string'));
%if the value is less than zero or not a number change it to default one 
if dMax>0
    %do nothing
else
    set(handles.txtdMax,'string','');
end


% --- Executes during object creation, after setting all properties.
function txtdMax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtdMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtIEMax_Callback(hObject, eventdata, handles)
IEMax=str2double(get(handles.txtIEMax,'string'));
%if the value is less than zero or not a number change it to default one 
if IEMax>0
    %do nothing
else
    set(handles.txtIEMax,'string','');
end

% --- Executes during object creation, after setting all properties.
function txtIEMax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtIEMax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cboEstimation.
function cboEstimation_Callback(hObject, eventdata, handles)
  SetOptimizationOptions(0,handles);

function SetOptimizationOptions(CallType,handles)
%CallType - 0 if called from the estimation callback function
%         - 1 if called from the bias combo callback function

 %get the selected option in Estimation pop-up menu
selectedOption=get(handles.cboEstimation,'Value');
% 1:Simple Average
% 2:Factor Analysis
% 3:ML Model
% 4:IE Error Variance
% 5:IE Multiply
% 6:IE Add

switch selectedOption
    case 1
        %Simple Average
        %reset the GUIV1P10
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        set(handles.cboOptimization,'Enable','on');
        %SF Note that fixed point multiplication is not allowed when both
        %bias types are fit simulataneously
        set(handles.cboOptimization,'String',{'Gradient','Derivative Free','Fixed Point','Two Stage Fixed Point'});
        set(handles.cboOptimization,'Value',1);
    case 2
        %Factor analysis
        %in cboBiasType, Value 1 is stands for 'No Bias'
        set(handles.cboBiasType,'Value',1);
        %Disable bias pop-up menu when Factor Analysis is selected
        set(handles.cboBiasType,'Enable','off');
        %invisible the optimization options 
        set(handles.cboOptimization,'Visible','off');
        %set the optimization method to the fixed point. Although this option
        %should be invisible, we need to pass 0 for optimization when the 
        %factor analysis is selected.So, we set the optimization to fixed point
        %which will return 0
        set(handles.cboOptimization,'Value',3);
    case 3
        %Basic maximum likelihood model
        %reset the GUIV1P10
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        set(handles.cboOptimization,'Enable','on');
        set(handles.cboOptimization,'String',{'Gradient','Derivative Free','Fixed Point','Two Stage Fixed Point'});
        set(handles.cboOptimization,'Value',1);
    case 4
        %IE Error Variance
        %reset GUIV1P10
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        %in cboOptimization, Value 1 stands for 'Gradient'
        set(handles.cboOptimization,'String',{'Gradient','Fixed Point','Two Stage Fixed Point'});
        set(handles.cboOptimization,'Value',1);
    case 5
        %reset GUIV1P10
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        set(handles.cboOptimization,'Enable','on');
        set(handles.cboOptimization,'String',{'Gradient','Derivative Free','Fixed Point','Two Stage Fixed Point'});
        set(handles.cboOptimization,'Value',1);
    case 6
        %reset GUIV1P10
        set(handles.cboBiasType,'Enable','on');
        set(handles.cboOptimization,'Visible','on');
        set(handles.cboOptimization,'Enable','on');
        %Change the avaialable options in optimiziation pop-up menu
        set(handles.cboOptimization,'String',{'Gradient','Derivative Free'});
        set(handles.cboOptimization,'Value',1); 
end



% --- Executes during object creation, after setting all properties.
function cboEstimation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboEstimation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cboBiasType.
function cboBiasType_Callback(hObject, eventdata, handles)
% hObject    handle to cboBiasType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboBiasType contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboBiasType

%Get the current value of the bias type, which is the value - 1
%  SetOptimizationOptions(1,handles);
%SF 8/01/2013 - Remove as fixed point can now cope with all bias types


% --- Executes during object creation, after setting all properties.
function cboBiasType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboBiasType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cmdAddTraits.
function cmdAddTraits_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Combination
if get(handles.cmdCorrespond,'Value')==1
    set(handles.cmdAddTraits,'Value',1);
    set(handles.cmdCorrespond,'Value',0);
else
    set(handles.cmdAddTraits,'Value',1);
end

% --- Executes on button press in cmdCorrespond.
function cmdCorrespond_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Combination
if get(handles.cmdAddTraits,'Value')==1
    set(handles.cmdAddTraits,'Value',0);
    set(handles.cmdCorrespond,'Value',1);
else
    set(handles.cmdCorrespond,'Value',1);
end



% --- Executes on button press in cmdNone.
function cmdNone_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Standardization
if get(handles.cmdRange,'Value')==1 || get(handles.cmdStandardize,'Value')==1 
    set(handles.cmdNone,'Value',1);
    set(handles.cmdStandardize,'Value',0);
    set(handles.cmdRange,'Value',0);
else
    set(handles.cmdNone,'Value',1);
end 


% --- Executes on button press in cmdStandardize.
function cmdStandardize_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Standardization
if get(handles.cmdRange,'Value')==1 || get(handles.cmdNone,'Value')==1 
    set(handles.cmdNone,'Value',0);
    set(handles.cmdStandardize,'Value',1);
    set(handles.cmdRange,'Value',0);
else
    set(handles.cmdStandardize,'Value',1);
end



% --- Executes on button press in cmdRange.
function cmdRange_Callback(hObject, eventdata, handles)
%Manage Radio Buttons on Data Standardization
if get(handles.cmdNone,'Value')==1 || get(handles.cmdStandardize,'Value')==1 
    set(handles.cmdNone,'Value',0);
    set(handles.cmdStandardize,'Value',0);
    set(handles.cmdRange,'Value',1);
else
    set(handles.cmdRange,'Value',1);
end




function txtMissingValue_Callback(hObject, eventdata, handles)
% hObject    handle to txtMissingValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtMissingValue as text
%        str2double(get(hObject,'String')) returns contents of txtMissingValue as a double


% --- Executes during object creation, after setting all properties.
function txtMissingValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtMissingValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over cmdCorrespond.
function cmdCorrespond_ButtonDownFcn(hObject, eventdata, handles)
try
    %do nothing
catch err
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg('Are you sure that you would like to close the GUI?','Close Request','Yes','No','Yes');
switch selection
case 'Yes',
delete(hObject);
case 'No'
return
end %switch


% --- Executes on button press in chkHeaderRow.
function chkHeaderRow_Callback(hObject, eventdata, handles)
% hObject    handle to chkHeaderRow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkHeaderRow


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2
