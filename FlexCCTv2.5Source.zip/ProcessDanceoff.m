NoDatasets=320;
MinCluster=2;
MaxCluster=6;
Results=[];

IAddBias=DLBase(:,10);
IMultBias=DLBase(:,11);

for iData=1:NoDatasets
  zName =strcat('C:\CCOut\DO\BaseR\z',num2str(round(iData)),'.csv');
  DName =strcat('C:\CCOut\DO\BaseR\D',num2str(round(iData)),'.csv');
  AddBiasName =strcat('C:\CCOut\DO\BaseR\AddBias',num2str(round(iData)),'.csv');
  MultBiasName =strcat('C:\CCOut\DO\BaseR\MultBias',num2str(round(iData)),'.csv');

  zEst=csvread(zName);
  DEst=csvread(DName);
  AddBiasEst=csvread(AddBiasName);
  MultBiasEst=csvread(MultBiasName);
  
  Time = zEst(1);
  zEst=zEst(2:size(zEst,1));
  DEst=DEst(2:size(DEst,1));
  AddBiasEst=AddBiasEst(2:size(AddBiasEst,1));
  MultBiasEst=MultBiasEst(2:size(MultBiasEst,1));
  
  z=Allz(iData,:)';
  D=AllD(:,iData);
  AddBias=AllBias(:,1+2*(iData-1));
  MultBias=AllBias(:,2*iData);
  
  zMSE=sum((z-zEst).^2,1)/50;
  zMAE=sum(abs(z-zEst),1)/50;
  DMSE=sum((D-DEst).^2,1)/50;
  DMAE=sum(abs(D-DEst),1)/50;
  if IAddBias(iData)==0
    AddBiasMSE=0;
    AddBiasMAE=0;    
  else
    AddBiasMSE=sum((AddBias-AddBiasEst).^2,1)/50;
    AddBiasMAE=sum(abs(AddBias-AddBiasEst),1)/50;
  end
  if IMultBias(iData)==0
    MultBiasMSE=0;
    MultBiasMAE=0;
  else
    MultBiasMSE=sum((MultBias-MultBiasEst).^2,1)/50;
    MultBiasMAE=sum(abs(MultBias-MultBiasEst),1)/50;   
  end
  
  ResultsInfo=[iData,-1,zMSE,zMAE,DMSE,DMAE,AddBiasMSE,AddBiasMAE,MultBiasMSE,MultBiasMAE,Time];
  Results=[Results;ResultsInfo];
 end


clear iData NoDatasets  MinCluster MaxCluster Time zEst DEst AddBiasEst MultBiasEst z D AddBias MultBias zMSE zMAE DMSE DMAE AddBiasMSE AddBiasMAE MultBiasMSE MultBiasMAE
