function [z,D,Bias,QE,MaxCrit,LLPartial,n,m,X,IBOut] = FlexCCTv2(X,NoTraits,DATCombine,DATStandard,EstMethod,BiasType,OptMethod,Converge,MaxIter,XSpec,DMax,IEMax)
%An implementation of continuous Cultural Consensus Theory as described
%in Batchelder and Romney (1988) and France and Batchelder (2013a,b).  This
%is the overall control procedure, which can be used to call the multiple
%optimization method versions of the procedure.  This procedure is utilized
%Inputs
%X - An n*(m*t) subject*(item*trait) input matrix.  Each row corresponds to
%           a subject.  
%No traits - The number of traits in the matrix.
%DATCombine- 0 Add Traits to calculate continuous score as per classical
%               test theory
%          - 1 Use multiple correspondance analysis to calculate continuous
%               score
%DATStandard-0 None - Use raw data (after DATCombine is applied)
%           -1 Standardize - Subtract column mean and divide by column sd
%           -2 Range scale - Divide by column range
%EstMethod - The estimation method
%          - 0 Average value
%          - 1 Minimum Residual factor analysis
%          - 2 Maximum likelihood estimation
%          - 3 Item difficulty model no 1 Additive Variances
%          - 4 Item difficulty model no 2 dij=alpha(i)*beta(j)
%          - 5 Item difficulty model no 3 dij=alpha(i)+beta(j)   
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          - 3 Fit additive and multiplicative bias
%          Currently bias 1 and 2 are only available for estimation methods
%          0,2,3,4, and 5
%          - 4 Fit a bias that declines linearly in proportion to the
%          remaining length of interval         
%OptMethod - 0 Fixed point: Fixed point estimation.
%          - 1 Two Stage Fixed Point. The values of z and d are estimated first, followed by other parameters.
%          - 2 Derivative Free: Standard MATLAB routine.
%          - 3 Gradient: MATLAB Gradient descent optimization, utilizing first order derivatives
%OptParms  - A row vector containing the optimization parameters.  This
%vector consists of the following fields:
%       Coverge - The converge value (difference between successive f
%       values) (default 1e6)
%       MaxIter - The maximum number of iterations for the procedure
%       (default 1000)
%       InitialType - The scheme used for the initial solution
%           - 0 Use the values from the average solution and no initial
%           bias (e.g., bias of 0 for additive, 1 for multiplicative)
%           - 1 Generate initial values from uniform distribution.
%              If 0 then use starting solution.  If 1 then use 
%           - 2 Calculate sample posterior distribution (NOT YET
%           IMPLEMENTED)
%MissingVal - The indicator for a missing value boundary of max(abs-1)
%DMax      - The maximum value of D
%IEMax     - The maximum value of the item easiness IE
%Outputs
%z   - A continuous m*1 answer key vector
%D   - An n*1 vector of user competencies
%Bias - The model bias
%QE - The overall question easinesses
%MaxCrit  - A maximization criteria for goodness of fit.
%LLPartial - A (3*m) matrix of partial likelihood values.  The first row
%contains the actual likelihood value, the second the value for the integer
%below the value and the third the value for the integer above the value.
%n - The number of users/raters
%m - The number of questions/items

MissingVal=XSpec(1);
%Calculate size of matrix
n=size(X,1);
tm=size(X,2);
%Raise an error as the number of columns needs to be divisible by the
%number of attributes
if NoTraits==0
  Exception = MException('InputError:MinimumTraits',...
              'The number of traits must be at least one.');
  throw(Exception);
end
if mod(tm,NoTraits)>0
  Exception = MException('InputError:DivisibleColumns',...
              'The number of columns must be divisible by the number of attributes.');
  throw(Exception);       
end

if (NoTraits==1)&&(DATCombine==1)
  Exception = MException('InputError:CorrespondanceTraits',...
              'The multiple correspondance analysis method of combining data requires more than one trait.');
  throw(Exception);   
end

%Set minimum values of variables
if Converge<=0
   Exception = MException('InputError:ConvergeRange',...
              'The value of the convergence parameter must be greater than 0.');
  throw(Exception); 
end
if MaxIter<1
   Exception = MException('InputError:MaxIterRange',...
              'The maximum number of iterations must be at least one.');
  throw(Exception); 
end


if exist('DMax','var')&&~isempty(DMax)
  HasDMax=true;
  if DMax<=0
   Exception = MException('InputError:DMaxRange',...
              'The maximum value of competency d must be greater than 0.');
  throw(Exception); 
  end
else
  HasDMax=false;
  DMax=inf;
end
if exist('IEMax','var')&&~isempty(IEMax)
  HasIEMax=true;
  if IEMax<=0
     Exception = MException('InputError:IEMaxRange',...
              'The maximum value of item easiness IE must be greater than 0.');
    throw(Exception); 
  end
else
  HasIEMax=false;
  IEMax=inf;
end

m=tm/NoTraits;

if isempty(MissingVal)
  MissingVal=min(min(X))-1;
end

%Calculate the single X from the multitrait X
if (NoTraits>1)
  %Add traits
  XNew=zeros(n,m);
  XMissing=zeros(n,m);
  %Work through, adding items for traits
  for j=1:m
    XNew(:,j)=sum(X(:,(j-1)*NoTraits+1:j*NoTraits),2);
    %If one trait is missing then all of the traits are considered to be
    %missing
    XMissing(:,j)=sum(X(:,(j-1)*NoTraits+1:j*NoTraits)==MissingVal,2); %#ok<AGROW>
  end
  XAdd=XNew;
  if DATCombine==0
    X=XAdd;
  else
    %Ensure that the data are integer
    if sum(sum(mod(X,1)))>0
      Exception = MException('InputError:NonIntegerData',...
              'Your data contain noninteger variables.  Integer values are required for correspondence analysis');
      throw(Exception);  
    end
    %Get the range of categorical variables
    MinX=X;
    MinX(find(X==MissingVal))=max(max(X));
    MaxX=X;
    MaxX(find(X==MissingVal))=min(min(X));  
    Categories=[min(min(MinX)):max(max(MaxX))];
    NoCategories=size(Categories,2);  
      
    %Firstly stack the data, so that each combination of user and question
    %is an observation.  Matrix is (n*m)*t
    Tempx=reshape(X',NoTraits,n*m)';
    Tempx2=zeros(n*m,NoTraits*NoCategories);
    %Now need to split each of the traits
    for t=1:NoTraits
      %Match the traits. 1st repmat extends the actual trait values across,
      %2nd extends the template down
      Tempx2(:,1+(t-1)*NoCategories:t*NoCategories)=repmat(Tempx(:,t),1,NoCategories)==repmat(Categories,n*m,1);
    end 
    %Now perform correspondance analysis on the remaining data;
    Correspond = Tempx2/sum(sum(Tempx2));
    ColTotal=sum(Correspond,1);
    RowTotal = sum(Correspond,2);
    if isempty(find(ColTotal==0))==0
      Exception = MException('CAError:ColTotals',...
              'Some column totals for the correspondence table are equal to 0.  Cannot perform multiple correspondence analysis.');
      throw(Exception);  
    end
    if isempty(find(RowTotal==0))==0
      Exception = MException('CAError:RowTotals',...
              'Some row totals for the correspondence table are equal to 0.  Cannot perform multiple correspondence analysis.');
      throw(Exception);  
    end
    
    %Calculate the chi-squared distances
    ChiSqDist = sqrt(inv(diag(RowTotal)))*(Correspond-RowTotal*ColTotal)*sqrt(inv(diag(ColTotal)));
    [Z,D,U] = svd(ChiSqDist);
    XNew = inv(diag(RowTotal))*sqrt(diag(RowTotal))*Z*D;
    SingleTrait=XNew(:,1);
    %Put in a similar range to additive data
    X=reshape(SingleTrait',m,n)';
     
    MinXAdd=min(min(XAdd));MaxXAdd=max(max(XAdd));
    MinX=min(min(X));MaxX=max(max(X));
    X=MinXAdd+(X-MinX)*(MaxXAdd-MinXAdd)/(MaxX-MinX);
  end
  %Ensure that missing values are still missing
  X=X.*(+(XMissing==0))+MissingVal.*(+(XMissing>0));
end
  
%Have single trait matrix, so standardize/normalize
switch DATStandard
  case 1
    MeanX=mean(reshape(X,1,m*n));
    StdX=std(reshape(X,1,m*n));
    X=(X-repmat(MeanX,n,m))./(repmat(StdX,n,m));
  case 2
    X=X./(max(max(X))-min(min(X)));
end
%TEMPORARY UNTIL THE FIXED PARAMETERS ARE READ IN FROM THE GUI
FixedParams.IsSpecified=false;

if FixedParams.IsSpecified==false
  %Now set the fixed variables based upon the optimization type
  switch EstMethod
    case {0,1}
      %Don't fix any variables
      FixParams=[0,0,0,0];
    case {2,3,4,5,6} 
      %If bias > 0 then fix z
      if BiasType==0
        FixParams=[0,0,0,0];
      else
        FixParams=[1,1,0,0];
      end
  end
  %If two step fixed point then fully fix z before calculating any bias
  %and fully fix d before.  Otherwise only fix one value in order to prevent 
  %idenifiability problems.
  if OptMethod==1
    FixParams=FixParams*-1;
  end
end

%The GUI doesn't allow the user to specify iterations or
%random starts, so create basic OptParams
OptParams=[Converge,1000,0];

%Now perform the CCT
switch OptMethod
  case {0,1}
    %Fixed point optimization
    [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT5(X,EstMethod,BiasType,FixParams,OptParams,XSpec,DMax,IEMax);
  case {2,3}
    %Derivative free
    [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT3(X,EstMethod,BiasType,FixParams,OptParams,XSpec,OptMethod-2,DMax,IEMax);
end

%Bootstrap parameters  %TEMP SETUP TO USE AND TEST BOOTSTRAP
Bootstrap.CIz=true;
Bootstrap.CIIE=true;
Bootstrap.CId=true;
Bootstrap.CIbadd=true;
Bootstrap.CIbmult=true;
Bootstrap.Alpha=0.05;
Bootstrap.NoResample=1000;
Bootstrap.Technique=3;


%Now setup the estimated parameters.
Bootstrap.z=z;
Bootstrap.d=D;
Bootstrap.badd=Bias(:,1);
Bootstrap.bmult=Bias(:,2);
Bootstrap.IE=QE;

%0 Percentile Bootstrap, 1 Centered Percentile Bootstrap, 2 t-test Bootstrap, 3Jackknife
Bootstrap.OptMethod=OptMethod;
%Now if bootstrap is equal to the 
if exist('Bootstrap','var')&&(EstMethod>1)
  %Firstly do some housekeeping to prevent bootstrap on non-selected
  %parameters
  if EstMethod<3&&(Bootstrap.CIIE==true)
    Bootstrap.CIIE=false;
  end
  if (BiasType==0||BiasType==2)&&(Bootstrap.CIbadd==true)
    Bootstrap.CIbadd=false;
  end
  if (BiasType==0||BiasType==1)&&(Bootstrap.CIbmult==true)
    Bootstrap.CIbmult=false;
  end
  if (Bootstrap.CIz==true)||(Bootstrap.CIIE==true)
    %Run item bootstrap
    [IBOut] = ItemBootstrap(Bootstrap,X,EstMethod,BiasType,OptMethod,FixParams,OptParams,XSpec,DMax,IEMax);
  end
  if (Bootstrap.CId==true)||(Bootstrap.CIbadd==true)||(Bootstrap.CIbmult==true)
    %Run rater bootstrap
    [IBOut] = RaterBootstrap(Bootstrap,X,EstMethod,BiasType,OptMethod,FixParams,OptParams,XSpec,DMax,IEMax,IBOut);
  end  
  
end


  

  
  
  
  