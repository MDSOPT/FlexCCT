function [OptValue,RealHR,RealFPR] = CWCCTFunctionMissing(X,Z,C,P,OptFunction)
%Calculates the maximum likelihood function for cultural consensus theory
%where there is a binary true/false response.  Accounts for missing data.
%   Detailed explanation goes here
%X -          An n*m subject*item matrix
%Z -          A c*m answer key vector
%C -          A n*c cluster matrix.
%P -          An n*m matrix that is 1 if information is present and 0 if
%             missing
%OptFunction-  The function to maximize/minimize
%          - 0 Linear Function (hits - false positives)
%          - 1 Maximum Likelihood function
%          - 2 1/2 a Maximum Likelihood function (only HR and (1-FPR)
%Outputs
%OptValue  - The value of the function
%RealHR    - An n*1 vector of hit rates
%RealFP    - An n*1 vector of false positive rates
%Version     Author            Date
%   0.10     Stephen France    04/20/2012

  BigO=1E6;

  [n,m]=size(X);

  %Firstly calculate the values of D and g
  Hits=X.*(C*Z).*P;
  FPositives=X.*(1-(C*Z)).*P;
  %Proportion of hits and false positives)
  %If Z=1 for all items or Z=0 for all items then the problem is not
  %Fully defined (take as 0 (e.g. no false positives or hits)
  RealHR=sum(Hits,2)./(sum((C*Z).*P));
  HR=sum(Hits,2)./(sum((C*Z).*P)+(sum(C*Z)==0));
  RealFPR=sum(FPositives,2)./(sum(1-C*Z));
  FPR=sum(FPositives,2)./(sum(1-C*Z)+(sum(1-C*Z)==0));  
  
  %Ensure penalties for breaking model assumptions.
  Penalty=sum(max(RealFPR-HR,0))*BigN;
  
  if (OptFunction==0)
    OptValue=Penalty+sum(FPR)-sum(HR);
  else
    %If all values are 0 then ignore likelihood terms.  Can do this
    %As all values of the second term will be 0.  Ensure that 
    
    LogHR=log(HR+(HR==0));
    LogFPR=log(FPR+(FPR==0));
    LogNHR=log((1-HR)+((1-HR)==0));
    LogNFPR=log((1-FPR)+((1-FPR)==0));
    
    %Calculate maximum likelihood
    HitLK=(LogHR*ones(1,m)).*(X.*(C*Z).*P);
    FPLK= (LogFPR*ones(1,m)).*(X.*(1-(C*Z)).*P);
    NotHitLK=(LogNHR*ones(1,m)).*((1-X).*(C*Z).*P);
    NotFPLK=(LogNFPR*ones(1,m)).*((1-X).*(1-(C*Z)).*P);
    if (OptFunction==1)
      OptValue=(sum(sum(HitLK))+sum(sum(FPLK))+sum(sum(NotHitLK))+sum(sum(NotFPLK)));
    else
      %Only take 1/2 the parameters (HR and (1-FPR))
      OptValue=(sum(sum(HitLK))+sum(sum(NotFPLK)));
    end  
    %Matlab sometimes has complex number, probably slight rounding error
    OptValue=Penalty-real(OptValue);
  end
end

