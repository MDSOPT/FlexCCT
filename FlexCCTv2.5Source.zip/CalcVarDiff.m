function [MinVal,IDD,IDDiff] = CalcVarDiff(X,Z,Penalty)
%Calculate the item difficulty given the odds ratio given in Karabatsos and
%Batchelder (2003). Optimization is via a non-gradient line search.
%Inputs
%X            - An n*m subject*item matrix
%Z            - An 1*m  answer key vector
%Penalty      - A function penalty on values of IDD or IDDiff outside the interval [0,1]
%Outputs
%MinVal       - The minimum value of the optimization function
%IDD          - An n*1 vector of competencies/abilities
%IDDiff       - A 1*m vector of item difficulties
%Version     Author            Date
%   0.10     Stephen France    05/18/2012
  
  [n,m]=size(X);
  
  %Get the basic hits and false positives
  Hits=X.*(ones(n,1)*Z);
  FPositives=X.*(ones(n,1)*(1-Z));
  D=Hits-FPositives;
  %order questions in terms of difficulty
  Diff=sum(Hits-FPositives,1);
  [Temp,IX] = sort(Diff,'descend');
  if (mod(m,2)==0)
    %Even number of questions, so take the one that is closest to the mean
    MeanVal=mean(Diff);
    if abs(MeanVal-Diff(IX(m./2)))<abs(MeanVal-Diff(IX((m+2)./2)))
      FixIX=IX(m./2);
    else
      FixIX=IX((m+2)./2);
    end
  else
    FixIX=IX((m+1)./2);  
  end

  %Set the current item difficulty to 0.5 (see notation and discussion in Karabatsos and
  %Batcheldor (2003) on model identification.
  Initialx=rand(n+(m-1),1);  %All competencies and m-1 item difficulties
 
  options = optimset('GradObj','off','Hessian','off','Display','off');
  f = @(x)faMinID0(x,D,FixIX,Penalty);
  [Outx,MinVal] = fminunc(f,Initialx,options);
  
  if (FixIX==m)
    Outx=[Outx(1:n+m-1);0.5];
  else
    Outx=[Outx(1:n+FixIX-1);0.5;Outx(n+FixIX:n+m-1)];
  end

  IDD=Outx(1:n);
  IDDiff=Outx(n+1:n+m)';
  
  
end

