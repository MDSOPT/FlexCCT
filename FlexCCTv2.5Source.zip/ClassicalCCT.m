
function [Z,D,D2,Resid,Resid2,VAF,VAF2] = ClassicalCCT(X,InMethod,OptMethod,IsMissing,MissingVal,CovProb,OptLevel)
%The classical implementation of Cultural Consensus Theory as described
%in Batchelder and Romney (1988)
%Inputs 
%X - An n*m subject*item matrix
%InMethod  - 0 perform factor analysis on covariance matrix
%          - 1 perform factor analysis on matching matrix
%OptMethod - 0 Perform a principal axes factor analaysis
%          - 1 Exact method described in Comrey and Al Ahumada (1964)
%          - 2 Perform a quadratic programming procedure
%IsMissing - 1 if missing values are present, 0 otherwise
%MissingVal   - The identifier for missing data (should be outside range of actual values) 
%CovProb - If the covariance matrix is utilized then estimate the
%          probablity of Z* (defaults to 0.5).  Use 0 if matching.
%OptLevel - If OptMethod = 3 then the level of the optimization procedure used 
%          - 0 Use non-derivative optimization method
%          - 1 Also use the first derivatives (gradient vector)
%          - 2 Also use the second derivatives (Hessian matrix)
%Outputs
%Z - An m*1 answer key vector
%D - An n*1 vector of competencies from initial estimation
%D2 - An n*1 vector of competencies after replacing diagonal with (D^2) and
%performing PCA.
%Resid - A set of residuals after initial estimation
%Resid2 - A set of residuals after performing the PCA
%VAF - Variance accounted for by initial estimation
%VAF - Variance accounted for after calculating PCA
%Version     Author            Date
%   0.10     Stephen France    04/01/2012

 m=size(X,2);

 %Calculate initial matching and covariance from  Batchelder and Romney (1988)
 if (IsMissing==0)
   [CV,MT] = InitialEst(X); 
 else
   [CV,MT] = InitialEstMissing(X,MissingVal); 
 end
 
 if InMethod==0
   if ~exist('CovProb','var')
     CovProb=0.5;
   end
   UserMatrix=CV./(CovProb.^2);  %Assume prob = 0.5, so D(i)D(j)=C(ij)/4
 elseif InMethod==1
   UserMatrix=2*MT-1;   
 end
 
 switch OptMethod
   case 0
    [D,Resid]= PrincipalAxesFA(UserMatrix,1e-5,1);
   case 1
    [D,Resid] = ResidualFA(UserMatrix,1,1e-5);
   case 2
    if ~exist('OptLevel','var')
      OptLevel=0; %Default to non-gradient optimization
    end   
   [D,Resid] = ResidualFA2(UserMatrix,1,OptLevel,1e-5);
 end
 
 %Replace the diagonals in the matrix by the values of D^2;
 UserMatrix=UserMatrix-diag(diag(UserMatrix))+diag(D.^2);
 
 %Run Eigenvector decomposition
 [UAll,EAll] = eig(UserMatrix);
 %Matlab doesn't guarantee order of eigenvalues
 EDiag=diag(EAll);
 [B,IX]=sort(EDiag,'descend');
 U=UAll(:,IX(1));
 E=EAll(IX(1),IX(1));
 if sum(U)<=0
   U=-U;
 end
 D2=U*(E.^0.5);
 %Compute the residuals UserMatrix-E(1)*D(2)D(2)'
 Resid2=UserMatrix-(D2(:,1)*D2(:,1)');
 
 %Calculate VAF
 MeanVal=mean(mean(UserMatrix));
 VAF=1-(ssq(Resid)./ssq(UserMatrix-MeanVal));
 VAF2=1-(ssq(Resid2)./ssq(UserMatrix-MeanVal));
 
 %Now use formula from Batchelder and Romney (1986) to 
 G=(2.*X-1);
 %Multiply across logs
 G=G.*(log((1+D2)./(1-D2))*ones(1,m));
 
 Z=+(sum(G,1)>=0);
 
end

