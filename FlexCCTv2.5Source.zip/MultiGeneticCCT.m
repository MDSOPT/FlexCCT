function [ZMulti,ZPattern,AllResults,RunTime] = MultiGeneticCCT(X,OptFunction,STemp,ETemp,CTemp,TermIt,IsMissing,MissingVal)
%A multiple category version of the maximum likelihood approach for Cultural Consensus Theory.  Missing
%data will be dealt with with setting each element of the likelihood
%function with missing data to 1 (the log likelihood for the element will
%be 0)
%Inputs 
%X - An n*m subject*item matrix
%OptFunction-The function to maximize/minimize
%          - 0 Linear Function (hits - false positives)
%          - 1 Maximum Likelihood function
%STemp     - The start temperature for the annealing process
%ETemp     - The end temperature for the annealing process
%CTemp     - The change in temperature for each stage of the annealing
%            proceess
%TermIt    - The number of iterations with no change before terminating
%IsMissing - 1 if missing data and 0 if no missing data
%MissingVal- The identifier for missing data (should be outside range of actual values) 
%Outputs
%ZMulti    - An 1*m answer key vector of multi-category answers
%ZPattern  - A (c-1)*m pattern matrix of binary 0-1 answers
%AvgD      - An n*1 vector of average competencies across thresholds
%AvgD2     - As AvgD2 but for competencies after PCA.
%AllResults- A structure containing the following:
%-------------------------------------------------------------------------
%Categories- A 1*c vector of categories (c is no. categories)
%ThreshCount - Number of thresholds (c-1)
%AvgD      - An n*1 vector of average competencies across thresholds.
%Avgg      -  An n*1 vector of average biases across thresholds.
%For each threshold i=1 to (c-1), the following information
%Z(i)      - The answer key
%D(i)      - An n*1 vector of average competencies 
%D2(i)     - As D competencies after PCA.
%g(i)      - An n*1 vector of biases
%--------------------------------------------------------------------------
%RunTime   - The algorithm run time
%Version     Author            Date
%   0.10     Stephen France    05/05/2012

RunTime=0;
[n,m]=size(X);

%Get the minimum and maximum categorical values
MinValue=min(min(X));
MaxValue=max(max(X));
Categories=[];

%Include missing values in each binary matrix
if (IsMissing==1)
  %Set all initial values to 1 apart from missing values
  CurBinary=(+(X~=MissingVal))+(+(X==MissingVal)).*MissingVal;
else
  CurBinary=ones(n,m);
end 

ZPattern=[];
SumD=0;SumD2=0;Sumg=0;
ThreshCount=0;   %No. thresholds (No. Categories - 1)
for i=MinValue:MaxValue-1
  %All categories must have at least one value
  if ~isempty(find(X==i))
    Categories=[Categories,i];
    ThreshCount=ThreshCount+1;
    %Set threshold so all categories up to i are 0 and all categories > i
    %are equal to 1
    CurBinary=CurBinary-(+(X==i));
    %Perform cultural consensus analysis with genetic algorithm
    %First seven parameters are required.  The last parameter is optional
    if (nargin==7)
      [CurResults,SubRunTime] = GeneticCCT(CurBinary,OptFunction,STemp,ETemp,CTemp,TermIt,IsMissing);
    else
      [CurResults,SubRunTime] = GeneticCCT(CurBinary,OptFunction,STemp,ETemp,CTemp,TermIt,IsMissing,MissingVal);
    end
    RunTime=RunTime+SubRunTime;
    ZPattern=[ZPattern;CurResults.Z];
    %Save all the stagewise results
    AllResults.Z{i}=CurResults.Z;
    AllResults.D{i}=CurResults.D;
    AllResults.g{i}=CurResults.g;
    AllResults.HR{i}=CurResults.HR;
    AllResults.FPR{i}=CurResults.FPR;
    %Rash difficulties using ratio forumula
    AllResults.IDD1{i}=CurResults.IDD1;
    AllResults.IDDiff1{i}=CurResults.IDDiff1;
    %Rasch competencies and item difficulties, using an edge correct
    %of two items and a prior of 0.5.
    AllResults.IDD2{i}=CurResults.IDD2;
    AllResults.IDDiff2{i}=CurResults.IDDiff2;
    AllResults.IDDiff2{i}=CurResults.SEIDD; 
    AllResults.SEIDDiff2{i}=CurResults.SEIDDiff2; 
    AllResults.Resid{i}=CurResults.Resid;    
    SumD=SumD+CurResults.D;
    Sumg=Sumg+CurResults.g;
  end
end
tic;
AllResults.Categories=[Categories,MaxValue];
AllResults.ThreshCount=ThreshCount;
AllResults.CatCount=ThreshCount+1;
AllResults.AvgD=SumD./ThreshCount;
AllResults.Avgg=Sumg./ThreshCount;

%Find the first occurence of 0.  If not then the category is the 
%last category
ZMulti=zeros(1,m);

for i=1:m
  First0=find(ZPattern(:,i)==0,1);
  if isempty(First0)
    %All categories 0 to (C-1) give Z=0, so last category
    ZMulti(i)=AllResults.Categories(AllResults.CatCount);
  else
    ZMulti(i)=AllResults.Categories(First0);
  end
end
RunTime=RunTime+toc;




