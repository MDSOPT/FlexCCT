function [Basic,CCT] = CCTReliabilityAdd(X,d,Bias,IE)
%Reliability for continuous cultural consensus analysis.  This procedure
%returns the continuous reliability metric iota, as defined by Janson and Olson (2001)
%and also the consensus adjusted reliability metric, as defined by France
%and Batchelder.  Works specifically for the additive item easiness model
%INPUTS
%X - The n user*m item matrix of ratings
%d   - An n*1 vector of user competencies
%Bias - An n*2 vecttor of biases (1st column additive, 2nd column multiplicative)
%IE   - A continuous m*1 answer key vector
%OUTPUTS
%Basic - The Basic reliability coefficient
%CCT - The CCT reliability coefficient, incorporating competency, bias, and item easiness
%Version     Author            Date
%   2.00     Stephen France    04/01/2016

[n,m]=size(X);

%Find the observed values
Sqm=repmat(sum(X.^2,2),1,n);
Dist=Sqm+Sqm'-2*(X)*(X');
Obs=sum(sum(Dist));
Exp=Obs; %Expected incorporates observed
Obs=Obs./(m*n*(n-1)); %Normalize expected values

%Go through for expected, iterating one column at a time
for i=1:m-1
 X2=[X(:,m-i+1:m),X(:,1:m-i)];
 Sqm2=repmat(sum(X2.^2,2),1,n);  
 Dist=Sqm+Sqm2'-2*(X)*(X2');
 Exp=Exp+sum(sum(Dist));
end
Exp=Exp./(m*m*n*(n-1));

Basic=1-Obs./Exp;

%Adjust the values for the competencies
X=X-Bias(:,1)*ones(1,m);
X=X./(Bias(:,2)*ones(1,m));

%Now need to weight for competencies and item difficulties.  Taking 
%outer product of these values gives a competency matrix
Weightdidj=(d*ones(1,n)).*((d*ones(1,n))');
Weightdi=(d*ones(1,n));
Weightdj=(d*ones(1,n))';
WeightIE=ones(n,1)*IE;

%Calculate basic with no additive item easiness weights.
Sqm=repmat(sum((X.^2),2),1,n);
SqmW=repmat(sum((X.^2).*(WeightIE),2),1,n);
SqmW2=repmat(sum((X.^2).*(WeightIE.^2),2),1,n);
%Calculate the distannce components from
%(di+bk)(dk+bl)(xik^2+xjl^2-2xikxjl)
Distdidj=Weightdidj.*(Sqm+Sqm'-2*X*(X'));
DistdiBl=Weightdi.*(SqmW+SqmW'-2*X*((X.*WeightIE)'));
DistdjBk=Weightdj.*(SqmW+SqmW'-2*(X.*WeightIE)*(X'));
DistdjBk2=SqmW2+SqmW2'-2*(X.*WeightIE)*((X.*WeightIE)');
Dist=Distdidj+DistdiBl+DistdjBk+DistdjBk2;
%Weights are sum of (di+bk)(dk+bl)
WeightAll=(d*ones(1,m))+(ones(n,1)*IE);
TotalWeight=WeightAll*WeightAll';
TotalWeight=TotalWeight-diag(diag(TotalWeight));
Obs=sum(sum(Dist));
Exp=Obs; %Expected incorporates observed
SumW=sum(sum(TotalWeight));
ExpW=SumW;
Obs=Obs/SumW;


%Go through for expected, iterating one column at a time
for i=1:m-1
  X2=[X(:,m-i+1:m),X(:,1:m-i)];
  IE2=[IE(m-i+1:m),IE(1:m-i)];
  WeightIE2=ones(n,1)*IE2;
  %didj term sums of X^2
  Sqm=repmat(sum(X.^2,2),1,n);
  Sqm2=repmat(sum(X2.^2,2),1,n);
  %Sums of X^2 Weights for k
  SqmWk=repmat(sum((X.^2).*(WeightIE),2),1,n);
  Sqm2Wk=repmat(sum((X2.^2).*(WeightIE),2),1,n);
  %Sums of X^2 Weights for l
  SqmWl=repmat(sum((X.^2).*(WeightIE2),2),1,n);
  Sqm2Wl=repmat(sum((X2.^2).*(WeightIE2),2),1,n);
  %Sums of X^2 Weights for k and l
  SqmW2=repmat(sum((X.^2).*(WeightIE).*(WeightIE2),2),1,n);
  Sqm2W2=repmat(sum((X2.^2).*(WeightIE).*(WeightIE2),2),1,n);
  %Calculate the distannce components from
 %(di+bk)(dk+bl)(xik^2+xjl^2-2xikxjl)
  Distdidj=Weightdidj.*(Sqm+Sqm2'-2*X*(X2'));
  DistdiBl=Weightdi.*(SqmWl+Sqm2Wl'-2*X*((X2.*WeightIE2)'));
  DistdjBk=Weightdj.*(SqmWk+Sqm2Wk'-2*(X.*WeightIE)*(X2'));
  DistBkBl=SqmW2+Sqm2W2'-2*(X.*WeightIE)*((X2.*WeightIE2)');  
  
  Dist=Distdidj+DistdiBl+DistdjBk+DistBkBl;
  WeightAll=(d*ones(1,m))+(ones(n,1)*IE);
  WeightAll2=(d*ones(1,m))+(ones(n,1)*IE2);
  TotalWeight=WeightAll*WeightAll2';
  TotalWeight=TotalWeight-diag(diag(TotalWeight));
  Exp=Exp+sum(sum(Dist));
  ExpW=ExpW+sum(sum(TotalWeight));
end
Exp=Exp./ExpW;

CCT=1-Obs./Exp;





