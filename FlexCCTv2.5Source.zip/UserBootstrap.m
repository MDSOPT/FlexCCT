function [IBOut] = UserBootstrap(Bootstrap,X,EstMethod,BiasType,FixParams,OptParams,MissingVal,OptOptions,DMax,IEMax)
%Bootstrap/Jackknife for item based parameters d, badd, and bmult.
%INPUTS
%Bootstrap - True/false indicators on whether or not to bootstap variable
%%0 Percentile Bootstrap, 1 Centered Percentile Bootstrap, 2 t-test Bootstrap, 3Jackknife
%Bootstrap.CIz,Bootstrap.CIIE,Bootstrap.CId=true,Bootstrap.CIbadd=true,Bootstrap.CIbmult=true;
%Bootstrap.alpha=true - The value of alpha, the Type I error, for created
%confidence intervals
%Bootstrap.NoResample  - The number of resamples for the
%bootstrap/jackknife
%Bootstrap.technique - The technique
%EstMethod - The estimation method
%          - 0 Average value
%          - 1 Minimum Residual factor analysis
%          - 2 Maximum likelihood estimation
%          - 3 Item difficulty model no 1 Additive Variances
%          - 4 Item difficulty model no 2 dij=alpha(i)*beta(j)
%          - 5 Item difficulty model no 3 dij=alpha(i)+beta(j)   
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          - 3 Fit additive and multiplicative bias
%          Currently bias 1 and 2 are only available for estimation methods
%          0,2,3,4, and 5
%          - 4 Fit a bias that declines linearly in proportion to the
%          remaining length of interval         
%OptMethod - 0 Fixed point: Fixed point estimation.
%          - 1 Two Stage Fixed Point. The values of z and d are estimated first, followed by other parameters.
%          - 2 Derivative Free: Standard MATLAB routine.
%          - 3 Gradient: MATLAB Gradient descent optimization, utilizing first order derivatives
%OptParms  - A row vector containing the optimization parameters.  This
%vector consists of the following fields:
%       Coverge - The converge value (difference between successive f
%       values) (default 1e6)
%       MaxIter - The maximum number of iterations for the procedure
%       (default 1000)
%       InitialType - The scheme used for the initial solution
%           - 0 Use the values from the average solution and no initial
%           bias (e.g., bias of 0 for additive, 1 for multiplicative)
%           - 1 Generate initial values from uniform distribution.
%              If 0 then use starting solution.  If 1 then use 
%           - 2 Calculate sample posterior distribution (NOT YET
%           IMPLEMENTED)
%MissingVal - The indicator for a missing value boundary of max(abs-1)
%DMax      - The maximum value of D
%IEMax     - The maximum value of the item easiness IE

[n,m]=size(X);

%for Jacknife if the number of resamples is not equal to n,
%we need to set random remove
if Bootstrap.Technique==3
  %Can only remove each item once
  if Bootstrap.NoResample>n
    Bootstrap.NoResample=n;
  end
  RemoveNos=randperm(n);
  RemoveNos=RemoveNos(1:Bootstrap.NoResample);
end

%Create resamples, sampling users with replacement from X.
if Bootstrap.CIz==true
  zSample=zeros(Bootstrap.NoResamples,n);
end
if Bootstrap.CIIE==true
  IESample=zeros(Bootstrap.NoResamples,n);
end

for i=1:Bootstrap.NoResamples
  drawnow();
  %Sample rows with replacement from X
  if Bootstrap.Technique==3
    %remove ith row for the jackknife sample
    XRS=[X(1:RemoveNos(i)-1,:);X(RemoveNos(i)+1:n,:)];
  else
    XRS=X(floor(rand(1,n)*n+1),:);
  end
  
  %Sample rows with replacement from X
  XRS=X(floor(rand(1,n)*n+1),:);
  
  %Now ru%Now perform the CCT
  switch OptMethod
  case {0,1}
    %Fixed point optimization
    [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT5(X,EstMethod,BiasType,FixParams,OptParams,XSpec,DMax,IEMax);
  case {2,3}
    %Derivative free
    [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT3(X,EstMethod,BiasType,FixParams,OptParams,XSpec,OptMethod-2,DMax,IEMax);
  end
  
  if Bootstrap.CIz==true
    zSample(i,:)=z;
  end
  if Bootstrap.CIIE==true
    IESample(i,:)=QE;
  end
end

%Order the values into percentiles
if Bootstrap.CIz==true
  zSample=sort(zSample,2);
  [IBOut.zLB,IBOut.zUB,IBOut.zMean,IBOut.zMedian]=CreateBootstrapStats(Bootstrap.Technique,zSample,n,m,Method,Alpha);
end
if Bootstrap.CIIE==true
  IESample=sort(IESample,2);
  [IBOut.IELB,IBOut.IEUB,IBOut.IEMean,IBOut.zMedian]=CreateBootstrapStats(Bootstrap.Technique,IESample,n,m,Method,Alpha);
end