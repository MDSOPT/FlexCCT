function [CV,MT] = InitialEstMissing(X,MissingVal)
%Calculate the initial matching and covariance estimates for cultural
%consensus as per Batchelder and Romney (1988), but allow for missing data.
%Inputs
%X - An n*m subject*item matrix 
%MissingVal - The indicator used for missing data 

%Outputs
%CV - An n*m matrix of covariances between subjects
%MT - An n*m matrix of matching between subjects
%Version     Author            Date
%   0.10     Stephen France    05/02/2012

[n,m]=size(X);

P=(X~=MissingVal);
P=+P;       %Convert from logical to scalar values
M=P*P';   %Count of number of matching items

%First calculate a,b,c,d as per Batchelder and Romney (1988)
%For an 1.i..N*1..j..N matrix A(i=1,j=1) B(i=1,j=0) C(i=0,j=1) D(i=0,j=0)
A=(X.*P)*(X'.*P');
B=(X.*P)*((1-X)'.*P');
C=((1-X).*P)*(X'.*P');
D=((1-X).*P)*((1-X)'.*P');

CV=((A.*D)-(B.*C))./(M*(M-1));

MT=(A+D)./M;

end

