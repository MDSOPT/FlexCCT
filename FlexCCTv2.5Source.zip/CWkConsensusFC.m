function [Clusters,f,Fail] = CWkConsensusFC(X,NoClusters,CWOptParams,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior)
%A C-means like method for optimizing the clusterwise continuous 
%cultural consensus model, adapted for fuzzy clustering.  Starts off with random seed chosen by
%initialization method and a hard clustering with all items members of
%initial cluster
%Inputs
%X -  The n user and m data item matrix X
%NoClusters  - The number of clusters
%CWOptParams - The minimum number of items allowed in a cluster
%
%CWOptParams(1) - The converge value (sum difference between successive U
%values) (default 1e-6)
%CWOptParams(2) - The number of random starts
%CWOptParams(3) - InitMethod 
%               1 Random points within range of data
%               2 Centroid of partiton
%CWOptParams(4) - MaxIter - The maximum number of iterations of the c-means
%algorithm
%CWOptParams(5) -Fuzzyq - The c-means fuzzy clustering parameter
%------------------------------------------------------------------------
%OptMethod  - The inner continuous optimization method
%           - 0 Fixed point: Fixed point estimation.
%           - 1 Two Stage Fixed Point. (N.B. This gives same result as 0,
%           as parameter fixing now controlled by FixParams)
%           - 2 Derivative Free: Standard MATLAB routine.
%           - 3 Gradient: MATLAB Gradient descent optimization, utilizing first order derivatives
%EstMethod - The estimation method
%          - 0 Average value
%          - 1 Min Res factor analysis
%          - 2 Maximum likelihood estimation
%          - 3 Item difficulty model no 1 Additive Variances
%          - 4 Item difficulty model no 2 dij=alpha(i)*beta(j)
%          - 5 Item difficulty model no 3 dij=alpha(i)+beta(j)   
%          - 6 The Weber-Fechner model, where variance = zk^2/(d^p)
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          = 3 Fit both additive and multiplicative bias together
%FixParams - Fix parameters. A one by four array of items that contains
%          the following information.
%Fixz      - 0 Don't fix z at all
%          - -1 Fix z if an initial optimization run using EstMethod=2
%          - 1 Partial fix of z.  Fix for the average value
%FixD      - 0 Don't fix D at all
%          - -1 Fix D if an initial optimization run using EstMethod=2
%          - 1 Partial fix of D. Fix for the average value
%FixAddBias- 0 Don't fix the additive bias at all
%          - -1 Fix the additive bias first before calculating the
%          multiplicative bias
%          - 1 Partial fix of the additive bias.  Fix for the average value
%FixMultBias- 0 Don't fix the multiplicative bias at all
%          - -1 Fix the multiplicative bias first before calculating the
%          multiplicative bias
%          - 1 Partial fix of multiplicative bias.  Fix for the average
%          value
%OptParms  - A row vector containing the optimization parameters.  This
%vector consists of the following fields:
%       Coverge - The converge value (difference between successive f
%       values) (default 1e6)
%       MaxIter - The maximum number of iterations for the procedure
%       (default 1000)
%       InitialType - The scheme used for the initial solution
%           - 0 Use the values from the average solution and no initial
%           bias (e.g., bias of 0 for additive, 1 for multiplicative)
%           - 1 Generate initial values from uniform distribution.
%              If 0 then use starting solution.  If 1 then use 
%           - 2 Calculate sample posterior distribution (NOT YET
%           IMPLEMENTED)
%MissingVal - The indicator for a missing value boundary of max(abs-1)
%DMax      - The maximum value of D
%IEMax     - The maximum value of the item easiness IE
%Fuzzyq    - A fuzzy clustering scale parameter
%DPrior    - Prior guess for value D
%Outputs
%BestClusters - See header for CWClassicalCCT.m for description.
%fBest - The optimial value of the likelihood function
%Fail - Error flag. True if procedure fails, false otherwise
%-------------------------------------------------------------------------
%Version     Author            Date
%   0.10     Stephen France    08/07/2012

P=+~(X==MissingVal);
%First calculate the overall mean of the data
% ZPrior=spmean(X,P,1);
% %If no information available then use mean of other data
% if ~isempty(find(isnan(ZPrior)))
%   AverageAll=sum(ZPrior(~isnan(ZPrior)))./sum(~isnan(ZPrior));
%   ZPrior(isnan(ZPrior))=AverageAll;
% end

%Configure basic cluster information 
ConvergeU=CWOptParams(1);
MaxIter=CWOptParams(4);
Fuzzyq=CWOptParams(5);
[n,m]=size(X);
MinItemCount=0;
InitClusters.X=X;
InitClusters.NoClusters=NoClusters;
InitClusters.NoUsers=n;
InitClusters.NoQ=m;
InitClusters.P=P;
NoAnswers=sum(sum(P));
%Ensure that there is enough 'degrees of freedom' for the products
MinAnswers=max(m,n./NoClusters).*2;
if NoAnswers<MinAnswers
  ErrMessage='A minimum of 2 answers per question or 2*No clusters answers per user is required.';
  NoAnswers
  MinAnswers
  return;
end

%Initialize methods for calculating assignments (seeds are initial z values)
InitMethod=CWOptParams(3);
switch InitMethod
  case 1
    %Find the minimum and maximum values (0 if not available)
    XVals=X(find(P));
    MinVal=min(XVals); 
    MaxVal=max(XVals);
    zAll=MinVal+rand(NoClusters,m).*(MaxVal-MinVal);
  case 2
    %Work through the method in Steinley 2003
    Assign=floor(rand(n,1)*NoClusters)+1;
    zAll=zeros(NoClusters,m);
    for i=1:NoClusters
      Indexes=find(Assign==i);
      zAll(i,:)=spmean(X(Indexes,:),P(Indexes,:),1); %Average only accounting fot present datar4
    end
    %If no items present then have a NaN
    NaNIndex=find(isnan(zAll));  %NaN items to be randomly 
    NoNaN=sum(sum(NaNIndex));
    if NoNaN>0
      %find the minimum and maximum values and sample randomly from the
      %range of possible values
      MinVal=min(min(zAll));
      MaxVal=max(max(zAll));
      zAll(NaNIndex)=MinVal+(rand().*(MaxVal-MinVal));
    end
end

%Now calcculate initial value of the fuzzy mambership matrix U
[Dist,NewU] = CentroidDistancesFC(X,P,zAll,zeros(n,NoClusters),ones(n,NoClusters),2,1,Fuzzyq);  

InitClusters.zAll=zAll;
InitClusters.U=NewU;

%Loop while the cluster assignment changes are greater than 0
Clusters=InitClusters;
clear InitClusters;
Iter=0;
ChangeU=1;
while (ChangeU>ConvergeU)&&(Iter<MaxIter)
  Iter=Iter+1
  ChangeU
  
  Clusters.U=NewU;

  %Calculate the competencies and updated centroids
  [Clusters,TotalMax,Fail] = UpdateMaxCriterion2FC(Clusters,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,Fuzzyq,DPrior);   
  TotalMax
  
  %Calculate the new distances and centroid cluster assignments
  [Dist,NewU,ChangeU] = CentroidDistancesFC(X,P,Clusters.zAll,Clusters.AddBiasAll,Clusters.MultBiasAll,2,1,Fuzzyq,Clusters.U);
  
  
  %Ensure that the clusters have more than the minimum number of clusters
  Clusters.U=NewU;
end

f=TotalMax;






