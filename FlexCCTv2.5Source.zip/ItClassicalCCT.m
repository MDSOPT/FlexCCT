function [D,D2,Resid,Resid2,Z] = ItClassicalCCT(X,OptMethod,OptLevel)
%Iterative cultural consensus theory.  Follows Batchelder and Romney
%(1989), but uses repeated estimation.  In the first iteration, uses
%the matching matrix as an estimator for the covariance matrix.  Then
%uses the estimate of p(Z=1) as probability input to the covariance
%matrix.
%The classical implementation of Cultural Consensus Theory as described
%in Batchelder and Romney (1988)
%Inputs 
%X - An n*m subject*item matrix
%OptMethod - 0 Perform a principal axes factor analaysis
%          - 1 Exact method described in Comrey and Al Ahumada (1964)
%          - 2 Perform a quadratic programming procedure
%CovProb - If the covariance matrix is utilized then estimate the
%          probablity of Z* (defaults to 0.5) 
%OptLevel - If OptMethod = 3 then the level of the optimization procedure used 
%          - 0 Use non-derivative optimization method
%          - 1 Also use the first derivatives (gradient vector)
%          - 2 Also use the second derivatives (Hessian matrix)
%Outputs
%D - An n*1 vector of competencies from initial estimation
%D2 - An n*1 vector of competencies after replacing diagonal with (D^2) and
%performing PCA.
%Resid - A set of residuals after initial estimation
%Resid2 - A set of residuals after performing the PCA
%Z - An m*1 answer key vector
%Version     Author            Date
%   0.10     Stephen France    04/01/2012

[n,m]=size(X);

%Use matching matrix
if exist('OptLevel','var')
  [D,D2,Resid,Resid2,Z] = ClassicalCCT(X,1,OptMethod,0,OptLevel);
else
  [D,D2,Resid,Resid2,Z] = ClassicalCCT(X,1,OptMethod,0);
end
  
ChangeZ=1;
while ChangeZ>0
  PZ=sum(Z)./n;
  OldZ=Z;
  if exist('OptLevel','var')
    [D,D2,Resid,Resid2,Z] = ClassicalCCT(X,0,OptMethod,PZ,OptLevel);
  else
    [D,D2,Resid,Resid2,Z] = ClassicalCCT(X,0,OptMethod,PZ);
  end
  ChangeZ=sum(abs(Z-OldZ));
end



end

