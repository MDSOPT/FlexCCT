  A='';
  save 'c:\kyst\MOut\CMDS2.txt' A -ascii;
  n=500;
  for DS=1:20
    R=TestItems2((n*(DS-1)+1):(n*DS),:);
    Info=['*DS=' mat2str(DS)]
    OneV=ones(n,1);
    RT=R-(OneV*OneV'*R)/n;
    [U,S,V] = svd(RT*RT');
    Soln=U*(S.^0.5);
    for d=3:-1:1
      A=[-1000,DS,-99,d];
      save 'c:\kyst\MOut\CMDS2.txt' A -append -ascii;
      B=Soln(:,1:d);
      save 'c:\kyst\MOut\CMDS2.txt' B -append -ascii;
    end
  end
  clear OutTest D2 R,A,B,Out,FName,DS,k,d;