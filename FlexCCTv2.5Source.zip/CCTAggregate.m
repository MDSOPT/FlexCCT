function [z] = CCTAggregate(X,MissingVal,AMode,Converge)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
  P=+~(X==MissingVal);
  
  switch AMode
    case 1
      %Arithmetic mean
      Num=sum((X.*P),1);
      Denom=sum(P,1);
      z=Num./Denom;
    case 2
      %Geometric mean
      Num=sum((log(X).*P),1);
      Denom=sum(P,1);
      z=Num./Denom;
      z=real(exp(z));
    case 3
      %combined arithmetic and geometric mean
      AMean=CCTAggregate(X,MissingVal,1);
      GMean=CCTAggregate(X,MissingVal,2);
      while sum(abs(AMean-GMean))>Converge
        CombineMean=[AMean;GMean];
        AMean=CCTAggregate(CombineMean,MissingVal,1);
        GMean=CCTAggregate(CombineMean,MissingVal,1);
      end
      z=AMean;
    case 4
      %Harmonic mean
      Num=sum(P,1);
      Denom=sum(((1./X).*P),1);
      z=Num./Denom;
    case 5
      [n,m]=size(X);
      %variance adjusted mean
      InvVar = 1./spvar(X,P,2);
      Num=sum((X.*repmat(InvVar,1,m).*P),1);
      Denom=sum(P.*repmat(InvVar,1,m),1);
      z=Num./Denom;
  end
end

