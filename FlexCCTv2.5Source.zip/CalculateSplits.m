function [Splits]=CalculateSplits(SplitMode,Means,ItemCount1,ItemCount2,FixedSplits,WeightParam)
%Calculate the reduction in sum of squares for possible splits 
%for a set of row or column means.  If there are fixed splits, then 
%calculate for these splits.  If not use free splits.
%Inputs
%SplitMode - 0 Split using SSQ, 1 Split Using MSQ (as per Hartigan, 1972)
%Means - a vector (row or column of means)
%ItemCount - The number of items in the mean vector
%ItemCount2 - The number of items used to calculate mean vector (e.g. if
%row means, the number of columns).
%FixedSplits - a 1*? column vector of fixed splits
%Outputs - A list of splits.  Each split is of the format:
%         "Index (row/col to left),IsFixed (1 if fixed, 0 if free),RSS,RMS"
%Version     Author            Date
%   0.10     Stephen France    04/05/2012

if (SplitMode==0) && (exist('WeightParam','var')==0)
  WeightParam=1;
end

if isempty(FixedSplits)
  if ItemCount1>1
    %if no fixed splits then every split (1 to (n-1) can be split
    SplitCount=ItemCount1-1;
    Splits=ones(SplitCount,1);
    Splits=find(Splits);
    Splits=[Splits,zeros(SplitCount,1),zeros(SplitCount,1),zeros(SplitCount,1)];
    if SplitCount>1
      MSDivider=(WeightParam)./(ItemCount1.*2);
    else
      MSDivider=1;
    end
  else
    SplitCount=0;
    Splits=[];
  end
else 
  Splits=FixedSplits'; 
  SplitCount=size(Splits,1);
  Splits=[Splits,ones(SplitCount,1),zeros(SplitCount,1),zeros(SplitCount,1)];
  MSDivider=1;
end

%Go through each of the splits and calculate RSS 
for i=1:SplitCount
  %From paper RSS=nm'(b'-b)^2+nm''(b''-b)^2
  AllMean=sum(Means)./ItemCount1;
  Size1=ItemCount2*i;
  Mean1=sum(Means(1:i))./i;
  Size2=ItemCount2*(ItemCount1-i);
  Mean2=sum(Means(i+1:ItemCount1))./(ItemCount1-i);
  Splits(i,3)=Size1.*((Mean1-AllMean).^2)+Size2.*((Mean2-AllMean).^2);
  Splits(i,4)=Splits(i,3).*MSDivider;
end

end