function [z,Var,OP3,MaxCrit,LLPartial] = ContinuousFWCCT(X,EstMethod,Converge,MaxIter,MissingVal,DMax,DPrior,ZPrior,AddParams)
%An implementation of the fixed point estimation version of Fechner-Weber
%continuous Cultural Consensus Theory.  Similar to ContinuousCCT and 
%with similar versions, but calculates user variance rather than competency
%Inputs
%X - An n*m subject*item input matrix
%EstMethod - The estimation method
%          - 0 Average value (assume unit variance)
%          - 2 Maximum likelihood estimation
%          - 3 Maximum likelihood estimation with additive bias b
%          - 4 Maximum likelihood estimation with multiplicative bias variable b
%          - 5 Fit an additional easyness parameter (Stephen's model)
%          - 6 Fit an additional easyness parameter (Bill's model)
%   
%Coverge   - The converge value (difference between successive f values)
%MaxIter   - The maximum number of iterations for the procedure
%MissingVal - The indicator for a missing value boundary of max(abs-1)
%VMin      - The maximum value of D
%DPrior    - Prior guess for value D
%ZPrior    - An previous estimate of z, use this value as an additional
%            "fake" question when all other data are missing
%AddParams - Additional parameters
%          - If EstMethod=5 then
%               P1 - The number of items to edge correct for the Rasch
%               method
%               P2 - The prior probability of the edge correctted items
%Outputs
%z   - A continuous m*1 answer key vector
%VAR   - An n*1 vector of user variances
%OP3 - The third output parameter, contigent on the estimation method
%    - if EstMethod=3 then = bz - A continuous n*1 scale varible 
%    - If EstMethod=4 then = Diff - A continuous m*1 vector of Rasch item diffs.
%MaxCrit  - A maximization criteria for goodness of fit.
%LLPartial - A (3*m) matrix of partial likelihood values.  The first row
%contains the actual likelihood value, the second the value for the integer
%below the value and the third the value for the integer above the value.
%IC - A set of information criteria Contains AIC, CorAIC (corrected IC) and BIC
  [n,m]=size(X);
  MaxCrit=0;
 
  P=+~(X==MissingVal);
  
  %If no items for a question or user then add a question based on a
  %pseudo-Bayesian prior
  SumZ=sum(P,1);
  SumZ2=sum(P,2);
  if (~isempty(find(sum(P,1)==0)))||(~isempty(find(sum(P,2)==0)))
    AddLine=true;
    n=n+1;
    X=[X;SumZ];
    P=[P;ones(1,m)];
  else
    AddLine=false;
  end
    
  Num=sum((D*ones(1,m).*X.*P),1);
  Denom=sum((D*ones(1,m).*P),1);
  Denom=max(Denom,1);
  z=Num./Denom;

  if (EstMethod==0)||(EstMethod==1)
    %Do nothing
    OP3=ones(n,1);
  else 
    %Now recalculate Z and d until convergence
    ParamChange=Converge*1000;
    Iter=0;
    while (ParamChange>Converge)&&(Iter<MaxIter)
      %Old parameters used to calculate convergence
      Oldz=z;OldD=D;
      Num=sum(D*ones(1,m).*X.*P,1);
      Denom=sum(D*ones(1,m).*P,1);
      z=Num./Denom;
      Num=sum(P,2);
      Denom=sum(P.*((X-(ones(n,1)*z)).^2),2);
      D=Num./Denom; %Account for the missing data
      if DMax>0
        if sum(D>DMax)>0
          D=min(D,DMax);
        end
      end
      ParamChange=sum(abs(Oldz-z))+sum(abs(OldD-D));
      Iter=Iter+1;
    end
    switch EstMethod
      case {2}
        OP3=ones(n,1);   %the value of b is not estimated for this case
      case 3
        %Have basic estimate (now second stage of estimating with regression
        %function
        OP3=rand(n,1); 
        ParamChange=Converge*1000;
        Iter=0;
        while (ParamChange>Converge)&&(Iter<MaxIter)
          OldD=D;OldOP3=OP3;
          %Estimate the model with additive bias
          Num=sum(P.*X,2);
          Denom=sum(P.*(ones(n,1)*z),2);
          OP3=Num./Denom;
          %Estimate D
          Num=sum(P,2);
          Denom=sum(P.*((X-OP3*z).^2),2);
          D=Num./Denom;
          if DMax>0
            if sum(D>DMax)>0
              D=min(D,DMax);
            end
          end
          ParamChange=sum(abs(OldOP3-OP3))+sum(abs(OldD-D));%sum(abs(Oldz-z))
          Iter=Iter+1;
        end
      case 4 
        ParamChange=Converge*1000;
        Iter=0;
        OP3=rand(n,1);
        while (ParamChange>Converge)&&(Iter<MaxIter)
          OldD=D;OldOP3=OP3;
          %Estimate the model with multiplicative bias
          Num=sum(D*ones(1,m).*(X-ones(n,1)*z).*P,2);
          Denom=sum(D*ones(1,m).*P,2);
          OP3=Num./Denom;
          %Estimate D
          Num=sum(P,2);
          Denom=sum(P.*((X-OP3*ones(1,m)-ones(n,1)*z).^2),2);
          D=Num./Denom;
          if DMax>0
            if sum(D>DMax)>0
              D=min(D,DMax);
            end
          end
          ParamChange=sum(abs(OldOP3-OP3))+sum(abs(OldD-D));%sum(abs(Oldz-z))
          Iter=Iter+1;
        end
      case 5
        %Estimate the values of Alpha(i) and Beta(j)
        Iter=0;
        ParamChange=Converge*1000;
        D=ones(n,1);
        OP3=rand(1,m); 
        ParamChange=Converge*1000;
        Iter=0;
        while (ParamChange>Converge)&&(Iter<MaxIter)
          OldD=D;OldOP3=OP3;
          %Estimate the easiness parameter
          BR=(D*ones(1,m))./((D*ones(1,m))+(ones(n,1)*OP3));   %beta/(alpha+beta)
          Num=sum(P.*(BR.^2).*((X-(ones(n,1)*z)).^2),1);
          Denom=sum(P.*BR,1);
          OP3=Num./Denom;
          if DMax>0
            if sum(OP3>DMax)>0
              OP3=min(OP3,DMax);
            end
          end
          %Estimate the competancy D
          BR=(ones(n,1)*OP3)./((D*ones(1,m))+(ones(n,1)*OP3));   %beta/(alpha+beta)
          Num=sum(P.*(BR.^2).*((X-(ones(n,1)*z)).^2),2);
          Denom=sum(P.*BR,2);
          D=Num./Denom;
          if DMax>0
            if sum(D>DMax)>0
              D=min(D,DMax);
            end
          end
          ParamChange=sum(abs(OldOP3-OP3))+sum(abs(OldD-D));%sum(abs(Oldz-z))
          Iter=Iter+1;
        end
      case 6
        ParamChange=Converge*1000;
        Iter=0;
        OP3=rand(1,m);
        while (ParamChange>Converge)&&(Iter<MaxIter)
          OldD=D;OldOP3=OP3;
          %Estimate the bias parameter
          Num=sum(P,1);
          Denom=sum((D*ones(1,m)).*((X-ones(n,1)*z).^2).*P,1);
          OP3=Num./Denom;
          %Estimate D
          Num=sum(P,2);
          Denom=sum((ones(n,1)*OP3).*((X-ones(n,1)*z).^2).*P,2);
          D=Num./Denom;
          if DMax>0
            if sum(D>DMax)>0
              D=min(D,DMax);
            end
            if sum(OP3>DMax)>0
              OP3=min(OP3,DMax);
            end
          end
          ParamChange=sum(abs(OldOP3-OP3))+sum(abs(OldD-D));%sum(abs(Oldz-z))
          Iter=Iter+1;
        end
      case 7
        %Calculate Rasch model with pseudo Bayesian 
        X2=(X-(ones(n,1)*min(X)))./(ones(n,1)*range(X,1));
        z2=((z-min(X))./range(X,1));
        if exist('AddParams','var')
          EdgeCorrect=AddParams(1);
          Prior=AddParams(2);
        else
          EdgeCorrect=2;
          Prior=0.5;
        end
        [D,OP3] = CalcVarDiffRasch(X2,z2,EdgeCorrect,Prior);
    end
  end 
  
  %No remove the additional value of X
  if AddLine==true
    n=n-1;
    X=X(1:n,:);
    P=P(1:n,:);
    D=D(1:n);
    OP3=OP3(1:n);
  end
  
  %Calculate the criterion value
  switch EstMethod
    case 0
      %Calculate the average deviation in the group!
      MaxCrit=-sum(sum((X.*P-(ones(n,1)*z).*P).^2));
    case 1
      %Calculate the residual from the VAF
      MeanVal=mean(mean(CorrMatrix));
      MaxCrit=1-(ssq(Resid)./ssq(CorrMatrix-MeanVal));
      %Weight using the number of items (need this to make it consistant
      %for the clusterwise estimation procedure
      MaxCrit=MaxCrit.*sum(sum(P));
    case {2,3}
      %Calculate the maximum log likelihood value
      Part1=P.*(log(((D*ones(1,m))./(2*pi)).^0.5));
      Part2=P.*((-D*ones(1,m)).*((X-(OP3*z)).^2)./2);
      MaxCrit=sum(sum(Part1))+sum(sum(Part2));
      %Calculate the partial log likelihoods
      LLPartial=zeros(3,m);
      for j=1:m
        zval=z(j);
        %Store z, the lower bound and the upper bound
        zAll=[zval,fix(zval),fix(zval+1)];
        Part1=(P(:,j)*ones(1,3)).*(log(((D*ones(1,3))./(2*pi)).^0.5));
        Part2=(P(:,j)*ones(1,3)).*(-D*ones(1,3)).*(((X(:,j)*ones(1,3)-OP3*zAll).^2)./2);
        LLPartial(:,j)=(sum(Part1,1)+sum(Part2,1))';
      end
    case 4
      Part1=P.*(log(((D*ones(1,m))./(2*pi)).^0.5));
      Part2=P.*((-D*ones(1,m)).*((X-OP3*ones(1,m)-ones(n,1)*z).^2)./2);
      MaxCrit=sum(sum(Part1))+sum(sum(Part2));
      %Calculate the partial log likelihoods
      LLPartial=zeros(3,m);
      for j=1:m
        zval=z(j);
        %Store z, the lower bound and the upper bound
        zAll=[zval,fix(zval),fix(zval+1)];
        Part1=(P(:,j)*ones(1,3)).*(log(((D*ones(1,3))./(2*pi)).^0.5));
        Part2=(P(:,j)*ones(1,3)).*(-D*ones(1,3)).*(((X(:,j)*ones(1,3)-OP3*ones(1,3)-ones(n,1)*zAll).^2)./2);
        LLPartial(:,j)=(sum(Part1,1)+sum(Part2,1))';
      end
    case {5}
      Ratio=(D*OP3)./((D*ones(1,m))+(ones(n,1)*OP3));
      Part1=log((Ratio./(2*pi)).^0.5);
      Part2=P.*-Ratio.*((X-ones(n,1)*z).^2)./2;
      MaxCrit=sum(sum(Part1))+sum(sum(Part2));
      LLPartial=zeros(3,m);
      for j=1:m
        zval=z(j);
        %Store z, the lower bound and the upper bound
        zAll=[zval,fix(zval),fix(zval+1)];
        OP3All=OP3(j)*ones(1,3);
        Part1=(P(:,j)*ones(1,3)).*(log((((D*ones(1,3)).*(ones(n,1)*OP3All))./(((D*ones(1,3))+(ones(n,1)*OP3All))*2*pi)).^0.5));
        Part2=(P(:,j)*ones(1,3)).*((-((D*ones(1,3)).*(ones(n,1)*OP3All))).*((X(:,j)*ones(1,3)-ones(n,1)*zAll).^2)./(2*((D*ones(1,3))+(ones(n,1)*OP3All))));
        LLPartial(:,j)=(sum(Part1,1)+sum(Part2,1))';
      end
    case {6}
      Part1=P.*(log(((D*OP3)./(2*pi)).^0.5));
      Part2=P.*(-(D*OP3).*((X-ones(n,1)*z).^2)./2);
      MaxCrit=sum(sum(Part1))+sum(sum(Part2));
      LLPartial=zeros(3,m);
      for j=1:m
        zval=z(j);
        %Store z, the lower bound and the upper bound
        zAll=[zval,fix(zval),fix(zval+1)];
        OP3All=OP3(j)*ones(1,3);
        Part1=(P(:,j)*ones(1,3)).*(log(((D*OP3All)./(2*pi)).^0.5));
        Part2=(P(:,j)*ones(1,3)).*(-(D*OP3All).*((X(:,j)*ones(1,3)-ones(n,1)*zAll).^2)./2);
        LLPartial(:,j)=(sum(Part1,1)+sum(Part2,1))';
      end      
  end
  
  
  
  