function [Results] = FlexCCT(X,zGround,ClusterOptions,CIOptions,VldOptions,EstMethod,BiasType,FixParams,OptMethod,Converge,MaxIter,MissingVal,DMax,IEMax)
%An implementation of continuous Cultural Consensus Theory as described
%in Batchelder and Romney (1988) and France and Batchelder (2013a,b).  This
%is the overall control procedure, which can be used to call the multiple
%optimization method versions of the procedure.  This procedure is utilized
%by the FlexCCT gui
%Inputs
%X - An n*(m*t) subject*(item*trait) input matrix.  Each row corresponds to
%           a subject.  
%zGround - An 1*(m*t) vector of ground truth values
%ClusterOptions - An options for cluster analysis that contains the following
%			No traits - The number of traits in the matrix.
%			DATCombine- 0 Add Traits to calculate continuous score as per classical
%               test theory
%          			  - 1 Use multiple correspondance analysis to calculate continuous
%               score
%			DATStandard-0 None - Use raw data (after DATCombine is applied)
%           		   -1 Standardize - Subtract column mean and divide by column sd
%           		   -2 Range scale - Divide by column range
%CIOptions - Options for the confidence intervals
%          - HasItemBootstrap 1 if CIs for raters, 0 otherwise
%          - HasRaterBootstrap 1 if CIs for raters, 0 otherwise
%          - Technique - The bootstrap technique
%          - Alpha - The value of alpha, the Type I error, for created confidence intervals
%          - NoResample - The number of resamples for the bootstrap/jackknife
%          - Technique - %  0 Percentile Bootstrap, 1 Centered Percentile Bootstrap, 2 t-test Bootstrap, 3Jackknife
%          - CIz,CIIE, CId, CIbadd, CIbmult - 1 if CI for variable, 0 otherwisw
%VLdOptions
%EstMethod - The estimation method
%          - 0 Average value
%          - 1 Minimum Residual factor analysis
%          - 2 Maximum likelihood estimation
%          - 3 Item difficulty model no 1 Additive Variances
%          - 4 Item difficulty model no 2 dij=alpha(i)*beta(j)
%          - 5 Item difficulty model no 3 dij=alpha(i)+beta(j)   
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          - 3 Fit additive and multiplicative bias
%          Currently bias 1 and 2 are only available for estimation methods
%          0,2,3,4, and 5
%FixParams - Fix parameters.  See ContinuousCCT3 header for full details.
%OptMethod - 3 Fixed point: Fixed point estimation.
%          - 2 Derivative Free: Standard MATLAB routine.
%          - 1 Gradient: MATLAB Gradient descent optimization, utilizing first order derivatives
%OptParms  - A row vector containing the optimization parameters.  This
%vector consists of the following fields:
%       Coverge - The converge value (difference between successive f
%       values) (default 1e6)
%       MaxIter - The maximum number of iterations for the procedure
%       (default 1000)
%       InitialType - The scheme used for the initial solution
%           - 0 Use the values from the average solution and no initial
%           bias (e.g., bias of 0 for additive, 1 for multiplicative)
%           - 1 Generate initial values from uniform distribution.
%              If 0 then use starting solution.  If 1 then use 
%           - 2 Calculate sample posterior distribution (NOT YET
%           IMPLEMENTED)
%MissingVal - The indicator for a missing value boundary of max(abs-1)
%DMax      - The maximum value of D
%IEMax     - The maximum value of the item easiness IE
%OUTPUTS
%Results - A results structure containing the following
%		z   - A continuous m*1 answer key vector
%		D   - An n*1 vector of user competencies
%		Bias - An n*2 vector of biases (1st column additive, 2nd column multiplicative)
%		QE - A 1*m vector of item easiness parameters
%		MaxCrit  - A maximization criteria for goodness of fit.
%		LLPartial - A (3*m) matrix of partial likelihood values.  The first row
%		contains the actual likelihood value, the second the value for the integer
%		below the value and the third the value for the integer above the value.
%		n - The number of users/raters
%		m - The number of questions/items
%Version     Author            Date
%   1.00     Stephen France    01/20/2014
%   2.00     Stephen France    04/01/2016
%   2.50     Stephen France    01/01/2017

%Calculate size of matrix
n=size(X,1);
m=size(X,2);

%Set minimum values of variables
if Converge<=0
   Exception = MException('InputError:ConvergeRange',...
              'The value of the convergence parameter must be greater than 0.');
  throw(Exception); 
end
if MaxIter<1
   Exception = MException('InputError:MaxIterRange',...
              'The maximum number of iterations must be at least one.');
  throw(Exception); 
end


if exist('DMax','var')&&~isempty(DMax)
  HasDMax=true;
  if DMax<=0
   Exception = MException('InputError:DMaxRange',...
              'The maximum value of competency d must be greater than 0.');
  throw(Exception); 
  end
else
  HasDMax=false;
  DMax=inf;
end
if exist('IEMax','var')&&~isempty(IEMax)
  HasIEMax=true;
  if IEMax<=0
     Exception = MException('InputError:IEMaxRange',...
              'The maximum value of item easiness IE must be greater than 0.');
    throw(Exception); 
  end
else
  HasIEMax=false;
  IEMax=inf;
end


if isempty(MissingVal)
  MissingVal=min(min(X))-1;
end

%The GUI doesn't allow the user to specify iterations or
%random starts, so create basic OptParams
OptParams=[Converge,1000,0];

if ClusterOptions.NoCultures==1
  Results.SX{1}=X;
else
  if ClusterOptions.ClusterBias==1
    %Find the overall bias from 1 culture
    FakeClusterOptions.NoCultures=1;
    FakeCIOptions.HasRaterBootstrap=false;
    FakeCIOptions.HasItemBootstrap=false;
    [Results] = FlexCCT(X,FakeClusterOptions,FakeCIOptions,EstMethod,BiasType,FixParams,OptMethod,Converge,MaxIter,MissingVal,DMax,IEMax);
    %Now X=z*bM+BA, so to get best approximation of Z z=(X-bA)/bM
    FakeX=(X-Results.Bias{1}(:,1)*ones(1,m))./(Results.Bias{1}(:,2)*ones(1,m));
  else
    FakeX=X;
  end
  %Now get ready to perform a basic k-means optimization 
  %Note we are going to use cut down version of our own code (full
  %version to come in v3 of the software once we have scalability issues sorted).
  %version to come in v3 of the software once we have scalability issues sorted).
  [BestClusters,BestMax,C,ZAll,DAll,AddBiasAll,MultBiasAll,QEAll] = CWContinuousCCT(FakeX,ClusterOptions.NoCultures,1,4,...
  [2,ClusterOptions.NoClusteringRuns,1,1000],0,0,0,[0,0,0,0],[1e-6,1000,0],-1,DMax,IEMax);
  %Need to return to the original X for the final estimation
  if ClusterOptions.ClusterBias==1    
    for i=1:ClusterOptions.NoCultures
      BestClusters.SX{i}=X(BestClusters.Indexes{i}',:);
    end
  end

end

%Initialize results
Results.n=n;
Results.m=m;

for i=1:ClusterOptions.NoCultures
  if ClusterOptions.NoCultures>1
    Results.SX{i}=BestClusters.SX{i};
    Results.Indexes{i}=BestClusters.Indexes{i};
  end
  %Now perform the CCT
  switch OptMethod
    case 3
      %Basic fixed point optimization
      [Results.z{i},Results.D{i},Results.Bias{i},Results.QE{i},Results.MaxCrit{i},Results.LLPartial{i}] = ContinuousCCT5(Results.SX{i},EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax);
    case 2
      %Derivative free
      [Results.z{i},Results.D{i},Results.Bias{i},Results.QE{i},Results.MaxCrit{i},Results.LLPartial{i}] = ContinuousCCT3(Results.SX{i},EstMethod,BiasType,FixParams,OptParams,MissingVal,0,DMax,IEMax);
    case 1
      %Gradient
      [Results.z{i},Results.D{i},Results.Bias{i},Results.QE{i},Results.MaxCrit{i},Results.LLPartial{i}] = ContinuousCCT3(Results.SX{i},EstMethod,BiasType,FixParams,OptParams,MissingVal,1,DMax,IEMax);
  end
  Results.Count{i}=size(Results.D{i},1);
  %Now run the bootstrap procedures
  if CIOptions.HasRaterBootstrap==true
    CIOptions.d=Results.D{i};
    CIOptions.badd=Results.Bias{i}(:,1);
    CIOptions.bmult=Results.Bias{i}(:,2);
    [Results.RaterCI{i}] = RaterBootstrap(CIOptions,Results.SX{i},EstMethod,BiasType,OptMethod,FixParams,OptParams,MissingVal,DMax,IEMax);
    if(CIOptions.CIReplace==true)
      if CIOptions.CId==true
        Results.D{i}=Results.RaterCI{i}.dMean;
      end
      if CIOptions.CIbadd==true
        Results.Bias{i}(:,1)=Results.RaterCI{i}.baddMean;
      end
      if CIOptions.CIbmult==true
        Results.Bias{i}(:,2)=Results.RaterCI{i}.bmultMean;
      end
    end
  end
  if CIOptions.HasItemBootstrap==true
    CIOptions.z=Results.z{i};
    CIOptions.IE=Results.QE{i};
    [Results.ItemCI{i}] = ItemBootstrap(CIOptions,Results.SX{i},EstMethod,BiasType,OptMethod,FixParams,OptParams,MissingVal,DMax,IEMax);
    if(CIOptions.CIReplace==true)
      if CIOptions.CIz==true
        Results.z{i}=Results.ItemCI{i}.zMean';
      end
      if CIOptions.CIIE==true
        Results.QE{i}=Results.ItemCI{i}.IEMean';
      end
    end
 end
  %Running holdout validation
  if ((VldOptions.HasHoldout==true)&&(VldOptions.HasHoldoutCriteria==true))||(VldOptions.HOXPred==true)
    VldOptions.d=Results.D{i};
    VldOptions.badd=Results.Bias{i}(:,1);
    VldOptions.bmult=Results.Bias{i}(:,2);
    VldOptions.z=Results.z{i};
    VldOptions.IE=Results.QE{i};
    [Results.Holdout{i}]=HoldoutValidation(VldOptions,Results.SX{i},EstMethod,BiasType,OptMethod,FixParams,OptParams,MissingVal,DMax,IEMax);
  end
  %Comparing the solution with the ground truth
  if (VldOptions.RunGroundTruth==true)
    [Results.GTMetrics{i}]=HOMetrics(Results.z{i}',zGround',1,m,VldOptions);
  end
end
  

  
  
  
  