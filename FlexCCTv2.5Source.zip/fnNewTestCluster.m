function fnNewTestCluster(ThreadNo)

NoThreads=100;
TotalRuns = 3*3*2*2*3*2*3*5*2*2*3*2;

StartRun=(ThreadNo-1)*TotalRuns/NoThreads;
EndRun=ThreadNo*TotalRuns/NoThreads;

AllResults=[];
MinScale=0.5;
OverallRun=0;
IsRunning=false;

FileName=strcat('ClusterOut',num2str(round(StartRun)),'.txt');

for NoItems=200:400:1000
  for NoUsers=200:400:1000
    for Scale=5:5:10
      Range=Scale-1;
      Centre=1+(Range/2);
      for TrueDist=1:2
        for MissingPC=0:80
          for PropRange=5:4:9
            for DMax=5:5
              for NoClusters=3:1:3
                for Lambda=0:0.25:1    %Set the value of lambda 
                  %First randomly select true review scores
                  z = zeros(NoClusters,NoItems);
                  if TrueDist==1
                    %Sample from normal distribution with mean at the center
                    %point and with 1 standard devation = 1/6 range
                    zBase = norminv(rand(1,NoItems),Centre,Range/5);
                    zCluster = zeros(NoClusters,NoItems);
                    for k=1:NoClusters
                      zCluster(k,:)=norminv(rand(1,NoItems),Centre,Range/5);
                      z(k,:)=Lambda*zCluster(k,:)+(1-Lambda)*zBase;
                    end
                  else
                    %Sample from uniform distribution
                    zBase=(rand(1,NoItems).*Range)+1;
                    zCluster = zeros(NoClusters,NoItems);
                    for k=1:NoClusters
                      zCluster(k,:)=(rand(1,NoItems).*Range)+1;
                      z(k,:)=Lambda*zCluster(k,:)+(1-Lambda)*zBase;
                    end
                  end
                  %Randomly assign users to clusters, to create cluster
                  %membership matrix.  N.B. Keep clusters of equal size
                  Perm=randperm(NoUsers);
                  Assignments=ones(NoUsers,1);
                  for i=2:NoClusters
                    SubPerm=Perm(floor(NoUsers*(i-1)/NoClusters)+1:floor(NoUsers*i/NoClusters));
                    Assignments(SubPerm)=i;
                  end  
                    
                  Mind=(Range/5)^(-2);
                  Maxd=(Range/9)^(-2);
                  
                  %Select all users to have higher competancy within their
                  %cluster, from s standard deviation 1/5 range to standard
                  %deviation 1/9 of a range
                  D=Mind+rand(NoUsers,1).*(Maxd-Mind);

                  %Now sample an answer key given the competency and the true
                  %score
                  %Sample an error matrix based on competencies
                  Error=zeros(NoUsers,NoItems);
                  for i=1:NoUsers
                    P=rand(1,NoItems);
                    Error(i,:) = norminv(P,0,(D(i)^(-0.5)));
                  end

                  %Add the error to the actual values of the items
                  X=z(Assignments',:)+Error;
                  X=round(X);
                  X=min(max(1,X),Scale);   %Ensure in bounds
                  %Replace any missing data by -1
                  IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                  AllAssigned=isempty(find(sum(1-IsMissing,1)==0))&&isempty(find(sum(1-IsMissing,2)==0));
                  while (AllAssigned==0)
                    IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                    [IsMissing,AllAssigned]=FixMissing(IsMissing,1000);
                  end
                  X=-IsMissing+(1-IsMissing).*X;

                  %Now run clusterwise continuous cultural consensus theory
                  CWOptParams=[5,5]; %Parameters are minimum items in cluster and the number of optimization runs
                  
                  for Run=1:1
                    for AddBias=0:1
                      for MultBias=0:1
                        for Identify=1:1
                          %Go through different sets of runs
                          for Initialize=1:2
                            OverallRun=OverallRun+1;
                            if IsRunning==false&&OverallRun>=StartRun
                              IsRunning=true;
                            end
                            if IsRunning==true&&OverallRun>EndRun
                              IsRunning=false;
                              %Try raising hard error.  Kaboom!
                              error('Finished calculations, so aborting')
                            end                    
                            if (IsRunning==true)
                              OverallRun
                              tic;
                              Results=[NoItems,NoUsers,Scale,TrueDist,MissingPC,PropRange,DMax,NoClusters,Lambda,Initialize,Run,AddBias,MultBias,Identify];
                              Results2=zeros(1,7);
                              %Run with mode 0 (average) with no bias, which is equivalent to k-means clustering 
                              [Clusters,MaxCrit0,C,ZAll,D,Bias,QE,Init] = CWContinuousCCT(X,NoClusters,1,4,...
                                  [5,10,Initialize,1000],0,0,0,[0,0,0,0],[1e-6,1000,0],-1,DMax,DMax);
                              [Rand0,AdjRand0] = RandIndex3(Assignments,Clusters.Assign);
                              if AddBias==0&&MultBias==0  
                                [Clusters2,MaxCrit2,C,ZAll,D,Bias,QE,Init] = CWContinuousCCT(X,NoClusters,1,4,...
                                  [5,10,Initialize,1000],0,2,0,[Identify,Identify,0,0],[1e-6,1000,0],-1,DMax,DMax);
                              elseif AddBias==1&&MultBias==0
                                [Clusters2,MaxCrit2,C,ZAll,D,Bias,QE,Init] = CWContinuousCCT(X,NoClusters,1,4,...
                                  [5,10,Initialize,1000],0,2,1,[Identify,Identify,0,0],[1e-6,1000,0],-1,DMax,DMax);
                              elseif AddBias==0&&MultBias==1
                                [Clusters2,MaxCrit2,C,ZAll,D,Bias,QE,Init] = CWContinuousCCT(X,NoClusters,1,4,...
                                  [5,10,Initialize,1000],0,2,2,[Identify,Identify,0,0],[1e-6,1000,0],-1,DMax,DMax);
                              else
                                [Clusters2,MaxCrit2,C,ZAll,D,Bias,QE,Init] = CWContinuousCCT(X,NoClusters,1,4,...
                                  [5,10,Initialize,1000],0,2,3,[Identify,Identify,Identify,0],[1e-6,1000,0],-1,DMax,DMax);
                              end
                              [Rand2,AdjRand2] = RandIndex4(Assignments,Clusters2.Assign);
                                
                              %Calculate the MAE and MSE between Ds for all models
                              Results2(1)=MaxCrit0;
                              Results2(2)=MaxCrit2;
                              Results2(3)=Rand0;
                              Results2(4)=Rand2;
                              Results2(5)=AdjRand0;
                              Results2(6)=AdjRand2;
                              Results2(7)=toc;
                              NewResults=[Results,Results2];
                              AllResults=[AllResults;NewResults];
                              save(FileName, '-ascii','-append', 'NewResults');
                            end
                          end
                        end
                      end
                    end
                  end
                end
              end
            end
          end
        end
      end
    end
  end
end