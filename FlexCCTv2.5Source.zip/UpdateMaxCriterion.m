function [NewClusters,TotalMax,NewBestf,Failed] = UpdateMaxCriterion(Clusters,Bestf,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior)
%UNTITLED3 Summary of this function goes here
%Detailed explanation goes here
  Failed=false;
  NewClusters=Clusters;
  %Update the clusters
  TotalMax=0;
  for i=1:Clusters.NoClusters
    [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCTWRP(Clusters.SX{i},OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior);
    NewClusters.D{i}=D; 
    NewClusters.z{i}=z; 
    NewClusters.Bias{i}=Bias;
    NewClusters.QE{i}=QE;
    NewClusters.MaxCrit{i}=MaxCrit;
    %Total max criterion (calculate the total maximum criterion)
    %N.B. The maximum likelihood values 
    TotalMax=TotalMax+NewClusters.MaxCrit{i};
  end
  
  %Huge penalty for a nan solution.  This means that in a clusterwise
  %solution there are items without any user reviews (N.B. Create future
  %routine to remove items that will give this!
  if isnan(TotalMax)
    TotalMax=-1e19;
    Failed=true;
  end  
    
  if TotalMax>Bestf
    NewBestf=TotalMax;
    %Store the current configuration in the NoClusters+1 to 2*NoClusters
    for i=1:NewClusters.NoClusters
      NewClusters.Indexes{Clusters.NoClusters+i}=NewClusters.Indexes{i};
      NewClusters.Count{Clusters.NoClusters+i}=NewClusters.Count{i};
      NewClusters.SX{Clusters.NoClusters+i}=NewClusters.SX{i};
      NewClusters.D{Clusters.NoClusters+i}=NewClusters.D{i}; 
      NewClusters.z{Clusters.NoClusters+i}=NewClusters.z{i};
      NewClusters.Bias{Clusters.NoClusters+i}=NewClusters.Bias{i};
      NewClusters.QE{Clusters.NoClusters+i}=NewClusters.QE{i};
      NewClusters.MaxCrit{Clusters.NoClusters+i}=NewClusters.MaxCrit{i};
    end
  else
    NewBestf=Bestf;
  end 
  
end

