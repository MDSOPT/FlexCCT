function [f,g] = faMin1(x,R)
%fa2Min - Provides the function value and gradient value for the residual 
%factor analysis procedure
%Inputs
%x - The (n*1) current value of the function parameters (F, but gone with Matlab
%notation)
%R - The (n*n) source matrix
%Outputs
%f - The (n*1) function vector for x
%g - The (n*1 )gradient vector for x
%Version     Author            Date
%   0.10     Stephen France    04/01/2012

n=size(x,1);

%Calculating nonzero function differences
DiffSq=(R-x*x').^2;
DiffSq=DiffSq-diag(diag(DiffSq));
f=sum(sum(DiffSq))./2;

G1=4*(R.*(ones(n,1)*x'));
G2=4*(x*ones(1,n)).*((ones(n,1)*(x'.^2)));
G2=G2-diag(diag(G2)); %Subtract i=j elements

g=sum((G2-G1),2);

end

