function varargout = ConfidenceInterval(varargin)
% CONFIDENCEINTERVAL MATLAB code for ConfidenceInterval.fig
%      CONFIDENCEINTERVAL, by itself, creates a new CONFIDENCEINTERVAL or raises the existing
%      singleton*.
%
%      H = CONFIDENCEINTERVAL returns the handle to a new CONFIDENCEINTERVAL or the handle to
%      the existing singleton*.
%
%      CONFIDENCEINTERVAL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CONFIDENCEINTERVAL.M with the given input arguments.
%
%      CONFIDENCEINTERVAL('Property','Value',...) creates a new CONFIDENCEINTERVAL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ConfidenceInterval_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ConfidenceInterval_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ConfidenceInterval

% Last Modified by GUIDE v2.5 02-Feb-2017 00:12:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ConfidenceInterval_OpeningFcn, ...
                   'gui_OutputFcn',  @ConfidenceInterval_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ConfidenceInterval is made visible.
function ConfidenceInterval_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ConfidenceInterval (see VARARGIN)

try
  % Choose default command line output for Residual
  handles.output = hObject;

  % Update handles structure
  guidata(hObject, handles);

  %Set the icon to be the standard icon
  javaFrame = get(handle(hObject),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));

  %Fill up the number of clusters and available confidence intervals
  %Setup the number of clusters
  NoCultures=str2num(getappdata(0,'NoCultures'));
  for i=1:NoCultures
    ComboText{i} = num2str(i);
  end
  set(handles.cboCultureNo,'String',ComboText);
  set(handles.cboCultureNo,'Value',1);
  clear ComboText

  NoCI=1;
  ComboText{1}='z';

  if (getappdata(0,'CId')==true)
    NoCI=NoCI+1;
    ComboText{NoCI}='d';
  end
  if (getappdata(0,'CIbA')==true)
    NoCI=NoCI+1;
    ComboText{NoCI}='b(add)';
  end
  if (getappdata(0,'CIbM')==true)
    NoCI=NoCI+1;
    ComboText{NoCI}='b(mult)';
  end
  if (getappdata(0,'CIIE')==true)
    NoCI=NoCI+1;
    ComboText{NoCI}='IE';
  end
  
  set(handles.cboParameterSet,'String',ComboText);
  set(handles.cboParameterSet,'Value',1);

  % UIWAIT makes ConfidenceInterval wait for user response (see UIRESUME)
  % uiwait(handles.ConfidenceInterval);
  if strcmp(get(hObject,'Visible'),'off')
    PlotGraph(handles,true);
  end

catch err
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h); 
end

% --- Outputs from this function are returned to the command line.
function varargout = ConfidenceInterval_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in cmdExit.
function cmdExit_Callback(hObject, eventdata, handles)
% hObject    handle to cmdExit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% hObject    handle to cmdExit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = MFquestdlg([0.3,0.5],'Are you sure that you would like to close the confidence intervals pane?','FlexCCT Question','Yes','No','Yes');
switch selection
  case 'Yes',
  delete(gcf);
case 'No'
  return
end %switch

% --- Executes on button press in cmdSave.
function cmdSave_Callback(hObject, eventdata, handles)
% hObject    handle to cmdSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
  %get the filepath to save the file
  [FileName,FilePath]=uiputfile({'*.bmp;*.gif;*.jpg;*.png;*.tif;','All Image Files';...
          '*.*','All Files' },'Save Image',...
          'newfile.png');
  ExPath = [FilePath FileName];

  if(FileName~=0)
    %save the file in correct graphics format
    export_fig(handles.axes1, ExPath);
  end
catch err
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h); 
end

% --- Executes on button press in cmdUpdate.
function cmdUpdate_Callback(hObject, eventdata, handles)
% hObject    handle to cmdUpdate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes1);
cla;

popup_sel_index = get(handles.cboGraph, 'Value');
switch popup_sel_index
    case 1
        PlotGraph(handles,true);
    case 2
        PlotGraph(handles,false);
end

function PlotGraph(handles,IsBar)  
  %Get residual information and culture information from the 
  Results=getappdata(0,'Results');
  CultureIndex = get(handles.cboCultureNo, 'Value');
  Params = get(handles.cboParameterSet,'String'); 
  ParamName = Params{get(handles.cboParameterSet,'Value')};
  switch ParamName
    case 'z'
      LowerBound=Results.ItemCI{CultureIndex}.zLB;
      Mean=Results.ItemCI{CultureIndex}.zMean;
      UpperBound=Results.ItemCI{CultureIndex}.zUB;
      XNames=getappdata(0,'ColHeaderAll');
      TypeName='Item Answer Key';
      XType='Item';
    case 'd'
      LowerBound=Results.RaterCI{CultureIndex}.dLB;
      Mean=Results.RaterCI{CultureIndex}.dMean;
      UpperBound=Results.RaterCI{CultureIndex}.dUB;
      XNames=getappdata(0,'RowHeaderAll');
      TypeName='Rater Competency';
      XType='Rater';
    case 'b(add)'
      LowerBound=Results.RaterCI{CultureIndex}.baddLB;
      Mean=Results.RaterCI{CultureIndex}.baddMean;
      UpperBound=Results.RaterCI{CultureIndex}.baddUB;
      XNames=getappdata(0,'RowHeaderAll');
      TypeName='Rater Additive Bias';
      XType='Rater';
    case 'b(mult)'
      LowerBound=Results.RaterCI{CultureIndex}.bmultLB;
      Mean=Results.RaterCI{CultureIndex}.bmultMean;
      UpperBound=Results.RaterCI{CultureIndex}.bmultUB;
      XNames=getappdata(0,'RowHeaderAll');
      TypeName='Rater Multiplicative Bias';
      XType='Rater';
    case 'IE'
      LowerBound=Results.ItemCI{CultureIndex}.IELB;
      Mean=Results.ItemCI{CultureIndex}.IEMean;
      UpperBound=Results.ItemCI{CultureIndex}.IEUB;
      XNames=getappdata(0,'ColHeaderAll');
      TypeName='Item Easiness';
      XType='Item';
  end
  NoValues=size(Mean,1);
  MarkerSize=ceil(100/NoValues);
  
  if (IsBar==true)
    %Now plot to the axes
    plot(handles.axes1,1:NoValues,LowerBound,'o','markersize', MarkerSize,'MarkerEdgeColor','k','MarkerFaceColor','k')
    hold on;
    plot(handles.axes1,1:NoValues,Mean,'^','markersize', MarkerSize,'MarkerEdgeColor','k','MarkerFaceColor','k')              % plot lower CI boundary
    hold on;
    plot(handles.axes1,1:NoValues,UpperBound,'V','markersize', MarkerSize,'MarkerEdgeColor','k','MarkerFaceColor','k')              % plot upper CI boundary
    hold on;

    for i = 1:NoValues                                
      line([i i],[LowerBound(i) UpperBound(i)]);
      hold on;
    end
    
  else
    %Give the line graph (for continuous values)
    XValues=[1:NoValues,fliplr(1:NoValues)];
    YValues=[LowerBound', fliplr(UpperBound')];
    patch(XValues,YValues,1,'FaceColor','b','EdgeColor','b');
    hold on;
    plot(1:NoValues,Mean','r');
    alpha(.2); 
  end
  xlabel(['',XType]);
  ylabel(['',ParamName]);
  MinGr=min(LowerBound);MaxGr=max(UpperBound);
  Range = MaxGr-MinGr;
  MinGr=MinGr-Range*0.02;
  MaxGr=MaxGr+Range*0.02;
  axis([0 NoValues+1 MinGr MaxGr]); 
  %Add the x labels if specified
  if (get(handles.chkAxisHeader, 'Value')==true);
    set(gca,'xtick',1:1:length(XNames), 'xticklabel',XNames) 
  end
 
  Interval=num2str(100*(1-str2num(getappdata(0,'CIAlpha'))));
  title([Interval,'% Confidence intervals for ',TypeName]);
  hold off;
  
% --- Executes on selection change in cboParameterSet.
function cboParameterSet_Callback(hObject, eventdata, handles)
% hObject    handle to cboParameterSet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboParameterSet contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboParameterSet


% --- Executes during object creation, after setting all properties.
function cboParameterSet_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboParameterSet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cboGraph.
function cboGraph_Callback(hObject, eventdata, handles)
% hObject    handle to cboGraph (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboGraph contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboGraph


% --- Executes during object creation, after setting all properties.
function cboGraph_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboGraph (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cboCultureNo.
function cboCultureNo_Callback(hObject, eventdata, handles)
% hObject    handle to cboCultureNo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboCultureNo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboCultureNo


% --- Executes during object creation, after setting all properties.
function cboCultureNo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboCultureNo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when user attempts to close ConfidenceInterval.
function ConfidenceInterval_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to ConfidenceInterval (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
selection =MFquestdlg([0.3,0.5],'Are you sure that you would like to close the confidence intervals pane?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes',
delete(hObject);
case 'No'
return
end %switch


% --- Executes on button press in chkAxisHeader.
function chkAxisHeader_Callback(hObject, eventdata, handles)
% hObject    handle to chkAxisHeader (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkAxisHeader
