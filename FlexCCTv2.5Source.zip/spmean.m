function [MeanVals] = spmean(X,P,dim)
%Return mean values accounting for missing data
%Items with missing data are ignored
%INPUTS
%X - The input data (user * item)
%P - An indicator matrix of missing values 1 Present 0 Missing (user *
%item)
%dim - The dimension to aggregate on (1 or 2)
%OUTPUTS
%MeanVals - A vector of mean values
%Version 0.10 - Stephen France 09/18/2011
%Version 0.20 - Stephen France 05/31/2012 (use in CCT project)
%Version 2.00 - Stephen France 04/31/2016
  X2=X.*P;

  SSum=full(sum(X2,dim));
  
  %Get row and columns where x>0
  SCount=full(sum(P,dim));
  
  OverallMean=sum(SSum)./sum(SCount);
  
  MeanVals=SSum./SCount;
  
  NaNIndex=find(isnan(MeanVals));
  MeanVals(NaNIndex)=OverallMean;

end

