function [D] = pDistMissing(X,MissingValue,p1,p2)
%Basic distance metric function with three simple parameters
%Implements Minkowski distance metric
%INPUTS
%X  - The transformed X matrix (user * item)
%P  - The binary instances of X (user * item)
%b2 - The inner power p1 for Minkowski metric
%b3 - The outer power p2 for Minkowski metric
%OUTPUTS
%D - The (user * user) distance matrix
%Version 0.10 - Stephen France 09/18/2011
%Version 0.10 - Stephen France 08/01/2012 For cultural consensus
 
  [n,m]=size(X);

  StartEnd=[]; 
  [row,col,v] = find(X.*(X~=MissingValue));
  X2=[row,col,v];
  clear row col v
  CurStart = 1;
  EndRow = size(X2,1);
  CurValue=X2(1,2);
  
  for i=2:EndRow
    if X2(i,2)~=CurValue
      if i-1>CurStart
        StartEnd=[StartEnd;[CurStart,i-1]];
      end
      CurValue=X2(i,2);
      CurStart = i;
    end  
  end
  if EndRow>CurStart
    StartEnd=[StartEnd;[CurStart,EndRow]];  
  end
  
  SECount=size(StartEnd,1);
  D=zeros(n);
  
  
  for i=1:SECount
    StartRow=StartEnd(i,1);
    EndRow=StartEnd(i,2);
    for j=StartRow:EndRow-1
      for k=j+1:EndRow
        D(X2(j,1),X2(k,1))=D(X2(j,1),X2(k,1))+abs(X2(j,3)-X2(k,3))^p1;
      end
    end
  end
  D=D+D';
  
  D=D.^p2;
  
  