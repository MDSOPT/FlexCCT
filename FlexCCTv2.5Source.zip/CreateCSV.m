function CreateCSV(FilePath,ColNames,CSVData,RowNames)
%Creates an output file for the FlexCCT output parameter.  Each set of
%parameters is stored as a column.  Firstly, the function creates a CSV
%file, which is padded with NaN values for parameter sets without the maximal
%number of parameters. The csv matrix is then saved to a text file.
%file.
%INPUTS
%FilePath - The path to save the csv file
%ColNames - The names of the data columns
%CSVData  - The numeric csv data.  The should match ColNames
%OUTPUTS
%Version     Author            Date
%   1.00     Mahyar Vaghefi    02/01/2014
%   2.00     Stephen France    04/01/2016

[OutRows,OutCols]=size(CSVData);

HasRows=exist('RowNames','var');

FileID = fopen(FilePath,'w');
if FileID>0
  if (HasRows==true)
    Header =  strcat(',',sprintf ('%s,',ColNames{1,1:OutCols-1}),sprintf ('%s',ColNames{1,OutCols}));
  else
    Header =  strcat(sprintf ('%s,',ColNames{1,1:OutCols-1}),sprintf ('%s',ColNames{1,OutCols}));
  end
  fprintf(FileID, '%s\n', Header);
  for i=1:OutRows
    if (HasRows==true)
      CSVLine=strcat(RowNames{1,i},',',sprintf('%.8g,',CSVData(i,1:OutCols-1)), sprintf('%.8g',CSVData(i,OutCols)));
    else
      CSVLine=strcat(sprintf('%.8g,',CSVData(i,1:OutCols-1)), sprintf('%.8g',CSVData(i,OutCols)));      
    end
    CSVLine=strrep(CSVLine, 'NaN', '');
    fprintf(FileID, '%s\n', CSVLine);   
  end

  fclose(FileID);
else
  Exception = MException('CAError:CSVWrite',...
              ['FlexCCT is unable to create a csv file at \n',strrep(FilePath,'\','\\')]);
      throw(Exception);  
end

