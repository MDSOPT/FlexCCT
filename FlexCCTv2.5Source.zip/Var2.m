function [MVar]= Var2(X,P)
%An update of the Matlab variance function.  Can calculate for a full
%matrix and will ignore missing data.
%INPUTS
%X - The input data (user * item)
%P - An indicator matrix of missing values 1 Present 0 Missing (user *
%item)
%OUTPUTS
%MVar - The matrix variance
%Version 0.10 - Stephen France 05/27/2012


