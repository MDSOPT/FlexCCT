function [CV,MT] = InitialEst(X)
%Calculate the initial matching and covariance estimates for cultural
%consensus as per Batchelder and Romney (1988)
%Inputs
%X - An n*m subject*item matrix 
%Outputs
%CV - An n*m matrix of covariances between subjects
%MT - An n*m matrix of matching between subjects
%Version     Author            Date
%   0.10     Stephen France    04/01/2012

[n,m]=size(X);

%First calculate a,b,c,d as per Batchelder and Romney (1988)
%For an 1.i..N*1..j..N matrix A(i=1,j=1) B(i=1,j=0) C(i=0,j=1) D(i=0,j=0)
A=X*X';
B=X*(1-X)';
C=(1-X)*X';
D=(1-X)*(1-X)';

CV=((A.*D)-(B.*C))./(m*(m-1));

MT=(A+D)./m;

end

