function [BestClusters,fBest]=CWCCTGenetic (InitialClusters,DPenalty,OptParameters,FactorOptMethod,OptLevel)
%The actual optimization for clusterwise classical cultural consensus
%theory.  Takes a set of clusters and then optimizes these clusters to
%maximize the within cluster VAF (calculated as percentage of variance in
%one factor solution
%Inputs
%InitialClusters - See header for CWClassicalCCT.m for description
%DPenalty - The penalty for any value of D that is outside of [0,1]
%OptParameters - Vector of length 5 of Optimization parameters
%1 Minimum number of items in a cluster, 2 STemp, 3 ETemp, 4 CTemp, 5
%TermIt (for description of 2-5 see GeneticCCT.m).
%Outputs
%BestClusters - See header for CWClassicalCCT.m for description.
%fBest - The optimial value of the optimization function (average cluster
%VAF, weighted by the number of items in each cluster).

%   Detailed explanation goes here
  MinItems=OptParameters(1);
  STemp=OptParameters(2);
  ETemp=OptParameters(3);
  CTemp=OptParameters(4);
  TermIt=OptParameters(5);
  
  %Shorthand for the initial clusters
  k=InitialClusters.NoClusters;

  CurTemp=STemp;

  %Calculate initial f
  fOld=-100;
  [Clusters,f,fBest]=UpdateVAF(InitialClusters,DPenalty,fOld,FactorOptMethod,OptLevel); %Bound to be better than -ve VAF
  
  NoChangeIt=0;
  
  while (NoChangeIt<TermIt) || (CurTemp>ETemp)
    FoundIndex=false;
    while (FoundIndex==false)
      ChangeIndex=floor(rand()*Clusters.QCount)+1;
      for i=1:Clusters.NoClusters
        if find(Clusters.Indexes{i}==ChangeIndex)>0
          %Ensure that the test cluster has more than the minimum
          if Clusters.Count{i}>MinItems
            Ri=i;
            FoundIndex=true;
            break;
          end
        end
      end
    end
    %Create the new test clusters
    TClusters=Clusters;
    %Firstly update the old cluster indexes
    RemoveIndex=find(TClusters.Indexes{Ri}==ChangeIndex);
    switch RemoveIndex
      case 1
        TClusters.Indexes{Ri}=TClusters.Indexes{Ri}(2:TClusters.Count{Ri});
      case TClusters.Count{Ri}
        TClusters.Indexes{Ri}=TClusters.Indexes{Ri}(1:TClusters.Count{Ri}-1);
      otherwise
        TClusters.Indexes{Ri}=[TClusters.Indexes{Ri}(1:RemoveIndex-1),TClusters.Indexes{Ri}(RemoveIndex+1:TClusters.Count{Ri})];
    end
    TClusters.Count{Ri}=TClusters.Count{Ri}-1;
    %Add to one of the other clusters randomly
    AddCluster=1+floor(rand()*(k-1));
    if AddCluster>=Ri
      AddCluster=AddCluster+1;
    end
    TClusters.Indexes{AddCluster}=sort([TClusters.Indexes{AddCluster},ChangeIndex]);
    TClusters.Count{AddCluster}=TClusters.Count{AddCluster}+1;
    [TClusters,fNew,fBest]=UpdateVAF(TClusters,DPenalty,fBest,FactorOptMethod,OptLevel);
    
    %Convert to a minimization problem
    fChange=f-fNew;
    
    if fChange<0
      Accept=true;
    else
      PAccept=exp(-fChange/CurTemp);
      %Implement the simulated annealing
      if rand<PAccept
        Accept=true;
      else
        Accept=false;
      end
    end
  
    if (Accept==true)
      fOld=f;
      f=fNew;
      Clusters=TClusters;
      NoChangeIt=0;
    else
      NoChangeIt=NoChangeIt+1;
    end
    CurTemp=max(ETemp,CurTemp-CTemp)
  end
  
  %Return the best value (stored in NoClusters+1 to 2*NoClusters)
  for i=1:Clusters.NoClusters
    BestClusters.Indexes{i}=Clusters.Indexes{Clusters.NoClusters+i};
    BestClusters.Count{i}=Clusters.Count{Clusters.NoClusters+i};
    BestClusters.UMatrix{i}=Clusters.UMatrix{Clusters.NoClusters+i};
    BestClusters.D{i}=Clusters.D{Clusters.NoClusters+i}; 
    BestClusters.Resid{i}=Clusters.Resid{Clusters.NoClusters+i};
    BestClusters.Mean{i}=Clusters.Mean{Clusters.NoClusters+i};
    BestClusters.VAF{i}=Clusters.VAF{Clusters.NoClusters+i};
  end
end

