function [z,D,Bias,MaxCrit,LLPartial] = DContinuousCCT(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,OptOptions,DTotal)
%An implementation of continuous Cultural Consensus Theory as described
%in Batchelder and Romney (1988) and France and Batchelder (2013). 
%This variant allows for competencies to be set for combinations of raters
%and items.  The model is grounded in the fact that 
%Inputs
%X - An n*m subject*item input matrix
%EstMethod - The estimation method
%          - 0 Average value
%          - 1 Min Res factor analysis
%          - 2 Maximum likelihood estimation
%          - 3 Item difficulty model no 1 Additive Variances
%          - 4 Item difficulty model no 2 dij=alpha(i)*beta(j)
%          - 5 Item difficulty model no 3 dij=alpha(i)+beta(j)   
%          - 6 The Weber-Fechner model, where variance = zk^2/(d^p)
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          - 3 Fit both additive and multiplicative bias together
%FixParams - Fix parameters. A one by four array of items that contains
%          the following information.
%Fixz      - 0 Don't fix z at all
%          - -1 Fix z if an initial optimization run using EstMethod=2
%          - 1 Partial fix of z.  Fix for the average value
%FixD      - 0 Don't fix D at all
%          - -1 Fix D if an initial optimization run using EstMethod=2
%          - 1 Partial fix of D. Fix for the average value
%FixAddBias- 0 Don't fix the additive bias at all
%          - -1 Fix the additive bias first before calculating the
%          multiplicative bias
%          - 1 Partial fix of the additive bias.  Fix for the average value
%          - -99 Set the average additive bias to be 0
%FixMultBias- 0 Don't fix the multiplicative bias at all
%          - -1 Fix the multiplicative bias first before calculating the
%          multiplicative bias
%          - 1 Partial fix of multiplicative bias.  Fix for the average
%          value
%          - -99 Set the average multiplicative bias to be 1
%OptParms  - A row vector containing the optimization parameters.  This
%vector consists of the following fields:
%       Coverge - The converge value (difference between successive f
%       values) (default 1e6)
%       MaxIter - The maximum number of iterations for the procedure
%       (default 1000)
%       InitialType - The scheme used for the initial solution
%           - 0 Use the values from the average solution and no initial
%           bias (e.g., bias of 0 for additive, 1 for multiplicative)
%           - 1 Generate initial values from uniform distribution.
%              If 0 then use starting solution.  If 1 then use 
%           - 2 Calculate sample posterior distribution (NOT YET
%           IMPLEMENTED)
%       p - For the Weber-Fechner estimation, this is the value of p for z
%MissingVal - The indicator for a missing value boundary of max(abs-1)
%OptOption  - 0 if the default to use only function value
%           - 1 if the default to use the first order derivatives
%           - options Alternatively pass an options object
%DMax      - The maximum value of D
%IEMax     - The maximum value of the item easiness IE
%DPrior    - Prior guess for value D
%OUTPUTS 
%(if not included in the model then return default values)
%z   - A continuous m*1 answer key vector
%D   - An n*1 vector of user competencies
%Bias - An n*2 vector of biases (1st column additive, 2nd column multiplicative)
%QE - A 1*m vector of item easiness parameters
%MaxCrit  - A maximization criteria for goodness of fit.
%LLPartial - A (3*m) matrix of partial likelihood values.  The first row
%contains the actual likelihood value, the second the value for the integer
%below the value and the third the value for the integer above the value.
%Version     Author            Date
%   0.10     Stephen France    06/22/2012
%   2.00     Stephen France    03/31/2016

  [n,m]=size(X);
  MaxCrit=0;

  Fixz=FixParams(1);FixD=FixParams(2);
  FixAddBias=FixParams(3);FixMultBias=FixParams(4);

  %Can only fix z and D if estimation type is in {2,3,4,5,6}.
  if (EstMethod==0)&&((Fixz~=0)||(FixD~=0))
    Exception = MException('InputError:BiasFix',...
         'By definition, z and D cannot be fixed for simple average estimation.');
    throw(Exception);  
  end
  
  %Cannot fix both additive bias and multiplicative bias values
  if (FixAddBias~=0)&&(FixMultBias~=0)&&(FixAddBias~=-99)&&(FixMultBias~=-99)
    Exception = MException('InputError:BiasFix',...
         'Only one type of bias can be fixed.  Both additive bias and multiplicative bias cannot be fixed together');
    throw(Exception); 
  end
  
  Converge=OptParams(1);
  MaxIter=OptParams(2);
  InitialType=OptParams(3);
 
  P=+~(X==MissingVal);
  
  %If no items for a question or user then add a question based on a
  %pseudo-Bayesian prior
  SumZ=sum(P,1);
  SumZ2=sum(P,2);
  if (~isempty(find(SumZ==0)))||(~isempty(find(SumZ2==0)))
    AddLine=true;
    n=n+1;
    X=[X;SumZ];
    P=[P;ones(1,m)];
  else
    AddLine=false;
  end
    
  %Find information on the size of the range
  MinX=X;
  MinX(find(X==MissingVal))=max(max(X));
  MaxX=X;
  MaxX(find(X==MissingVal))=min(min(X));  
  MinVal=min(min(MinX));
  MaxVal=max(max(MaxX));
      
  %Sample D and ensure equals DTotal
  if (InitialType==0)
    D=(DTotal*ones(1,m))/m;
  else
    D=rand(n,m);
    D=D.*(DTotal*ones(1,m))./(sum(d,2)*ones(1,m));
  end
  
  %The factor analysis method cannot fit additional parameters, so these
  %parameters are left at their default values.
  if (InitialType==0)
    %Set z to average base values
    Num=sum((D.*X.*P),1);
    Denom=sum((D.*P),1);
    Denom=max(Denom,1);
    z=Num./Denom;
  else
    %Sample z from its range
    z=MinVal+rand(1,m).*(MaxVal-MinVal);
  end

  if ((Fixz==1||Fixz==-1)||(FixD==1||FixD==-1))
    if Fixz==-99
      TempFixz=-99;
    else
      TempFixz=0;
    end
    if FixD==-99
      TempFixD=-99;
    else
      TempFixD=0;
    end
    [zPre,DPre] = DContinuousCCT(X,2,0,[TempFixz,TempFixD,0,0],OptParams,MissingVal,OptOptions,DTotal);
  end

  if (Fixz==1||Fixz==-1)
    %We create the initial z
    HasExistingz=true;
    %Setup z depending on whether partially or fully fixed
    if Fixz==1
      %Find the closed value to the mean and update Fixed z to be this
      %value
      [~,I]=sort(abs(median(zPre)-zPre));
      Fixz=I(1);
      zPre=zPre(Fixz);
    end
  else
    HasExistingz=false;
  end
  if (FixD==-1)||(FixD==1)
    HasExistingD=true;
    if FixD==1
      %Find the closest competency to the average competency
      %Fix entire row of competencies
      TotalDPre=sum(DPre,2);
      [V,I]=sort(abs(median(TotalDPre)-TotalDPre));
      FixD=I(1);
      DPre=DPre(FixD,:);
    end
  else
    HasExistingD=false;
  end
  
  if (InitialType==0)
    %Set inital values of bias and QE
    BiasAdd=zeros(n,1);
    BiasMult=ones(n,1);   %Row of additive biases and row of multiplicative biases
  else
    %Set random biases, but only if they can be fit.  Biases are random
    %withing range.  The additive bias range is from [-RangeX/2 to +RangeX/2) and
    %the multiplicative bias is from [0.5 to 2]
    switch BiasType
      case {0,2}
        %No additive bias
        BiasAdd=zeros(n,1);
      case {1,3}
        BiasAdd=rand(n,1)*(MaxVal-MinVal)-((MaxVal-MinVal)/2);
    end
    switch BiasType
      case {0,1}
        %No multiplicative bias
        BiasMult=ones(n,1);
      case {2,3}
        %Create an n*2 matrix and have one column containing the random
        %multiplication factor.  The scale assignments determine whether
        %this factor is or is not a recipricol.
        ScaleMatrix=ones(n,2);
        AssignIndexes=[1:n]+floor(rand(n,1)*2)'*n;
        ScaleMatrix(AssignIndexes)=rand(n,1)+1;
        BiasMult=ScaleMatrix(:,1)./ScaleMatrix(:,2);
    end      
  end  

  %The initial values of competency and answer key
  if HasExistingz==1
    if Fixz>0
      Initialx=[z(1:Fixz-1),z(Fixz+1:m)]';
    else
      Initialx=[];
    end
  else
    Initialx=(z');
  end 

  if HasExistingD==false;
    Initialx=[Initialx;reshape(D,n*m,1)];
  else
    %Run with partial fix
    if FixD>0  
      Initialx=[Initialx;reshape([D(1:FixD-1,:);D(FixD+1:n,:)],(n-1)*m,1)];
    end
  end
  NonBiasCount=size(Initialx,1);
  AddBiasCount=0;MultBiasCount=0;

  %Add bias variables depending on implemented bias
  RunFixedBias=false;
  BiasRunType=BiasType; %Run initially as either additive or multiplicative bias
  switch BiasType
    case 1
      Initialx=[Initialx;BiasAdd];
      AddBiasCount=n;
    case 2
      Initialx=[Initialx;BiasMult]; 
      MultBiasCount=n;
    case 3
      %For a bias type of 3, if fixed bias then there are two runs, one for
      %the bias to be fixed and the second for the "opposite" bias.
      %Cannot fix both additive and multiplicative bias
      if (FixAddBias==-1||FixAddBias==1)
        Initialx=[Initialx;BiasAdd];
        x2=BiasMult;
        MinValues2=zeros(n,1)*0;
        MaxValues2=ones(n,1)*Inf;         
        RunFixedBias=true;
        BiasRunType=1;
        AddBiasCount=n;
      elseif (FixMultBias==-1||FixMultBias==1)
        %Firstly fix the multiplicative bias
        Initialx=[Initialx;BiasMult];
        x2=BiasAdd;
        MinValues2=[ones(n,1)*-Inf];
        MaxValues2=[ones(n,1)*Inf];

        RunFixedBias=true;
        BiasRunType=2;
        MultBiasCount=n;
      else
        %Run with all of the biases
        Initialx=[Initialx;BiasAdd;BiasMult]; 
        AddBiasCount=n;
        MultBiasCount=n;
      end
  end

  if isnumeric(OptOptions)
    %If user passes a simple numerical argument then use the following,
    %otherwise used the passed options
    OptLevel=OptOptions;
    if (OptOptions==0)
      %Non gradient
      OptOptions = optimset('GradObj','off','Display','off','Algorithm','interior-point');
    else
      %Gradient
      OptOptions = optimset('GradObj','on','Display','off','Algorithm','trust-region-reflective');
    end  
  else  
    OptLevel=strcmp(OptOptions.GradObj,'on');
  end



  %The additional parameter is the optimization level
  switch OptLevel
  case 0
    if HasExistingz==false&&HasExistingD==false
      f = @(x)DCCCTMin0(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0]);
    elseif HasExistingz==false&&HasExistingD==true
      f = @(x)DCCCTMin0(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0],[],DPre);
    elseif HasExistingz==true&&HasExistingD==false
      f = @(x)DCCCTMin0(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0],zPre);
    else
      %HasExistingz==true HasExistingD==true
      f = @(x)DCCCTMin0(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0],zPre,DPre);
    end
  case 1

    if HasExistingz==false&&HasExistingD==false
      f = @(x)DCCCTMin1(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0]);
    elseif HasExistingz==false&&HasExistingD==true
      f = @(x)DCCCTMin1(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0],[],DPre);
    elseif HasExistingz==true&&HasExistingD==false
      f = @(x)DCCCTMin1(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0],zPre);
    else
      %HasExistingz==true HasExistingD==true
      f = @(x)DCCCTMin1(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0],zPre,DPre);
    end
  case 2
    ExceptionNI = MException('ContinuousCCT3:HessianSearch','This feature is not yet implemented');
    throw(ExceptionNI);
    %options = optimset('GradObj','on','Hessian','on','Display','off');
    %f = @(x)CCCTMin2(x,X);
  end

  if isempty(Initialx)==false
    if HasExistingz==true
      if Fixz>0
        %Minimum and maximum values where one item is removed
        MinValues=ones(m-1,1)*-Inf;
        MaxValues=ones(m-1,1)*Inf;
      elseif (Fixz==-1)
        MinValues=[];MaxValues=[];
      else
        %Constrain values for both D and for z
        MinValues=ones(m,1)*-Inf;
        MaxValues=ones(m,1)*Inf;
      end
    else
      MinValues=ones(m,1)*-Inf;
      MaxValues=ones(m,1)*Inf;
    end
    if HasExistingD==false
      MinValues=[MinValues;zeros(n*m,1)];
      MaxValues=[MaxValues;ones(n*m,1).*Inf];
    elseif (HasExistingD==true&&FixD>0)
      MinValues=[MinValues;zeros((n-1)*m,1)];
      MaxValues=[MaxValues;ones((n-1)*m,1).*Inf];
    end
    
    if (BiasRunType==1)||(BiasRunType==3)
      MinValues=[MinValues;ones(n,1)*-Inf];
      MaxValues=[MaxValues;ones(n,1)*Inf];
    end
    if (BiasRunType==2)||(BiasRunType==3)
      MinValues=[MinValues;ones(n,1)*0];
      MaxValues=[MaxValues;ones(n,1)*Inf];           
    end
  else
    %Set in case constrained is needed for bias
    MinValues=[];
    MaxValues=[];
  end
  
    %Set initial constraint values
    Aeq=[];beq=[];AeqAdd=[];beqAdd=[];
    if (Fixz == -99)
      %Set the average z value to be equal to the average current z
      Aeq=[Aeq;[ones(1,m),zeros(1,size(Initialx,1)-m)]];
      beq=[beq;sum(z)];        
    end
    AeqCount=0;
    if HasExistingD==false;
     beqAdd=DTotal;
     AeqAdd=zeros(n,size(Initialx,1));
     AeqCount=n;
     %AeqIndex=1:n;
    else
      %Run with partial fix
      if FixD>0  
        beqAdd=[DTotal(1:FixD-1);DTotal(FixD+1:n)];
        AeqAdd=zeros(n-1,size(Initialx,1));
        AeqCount=n-1;
        %AeqIndex=[1:FixD-1,FixD+1:n];
      end
    end
    %Finish off the matrix
    for i=1:AeqCount
      AeqAdd(i,m+(i-1)*AeqCount+1:m+i*AeqCount)=ones(1,AeqCount);
    end
    Aeq=[Aeq;AeqAdd];
    beq=[beq,beqAdd];
    
    if (FixAddBias == -99) && (AddBiasCount>0)
      %Set the average additive bias to be equal to be 0
      Aeq=[Aeq;[zeros(1,NonBiasCount),ones(1,AddBiasCount),zeros(1,MultBiasCount),zeros(1,size(Initialx,1)-NonBiasCount-AddBiasCount-MultBiasCount)]];
      beq=[beq;0];
    end
    if (FixMultBias == -99)&& (MultBiasCount>0)
      %Set the average multiplicative bias is 1, thus the total overall
      %bias is n
      Aeq=[Aeq;[zeros(1,NonBiasCount),zeros(1,AddBiasCount),ones(1,MultBiasCount),zeros(1,size(Initialx,1)-NonBiasCount-AddBiasCount-MultBiasCount)]];
      beq=[beq;n];      
    end

    
    %The algorithm is constrained by default
    OptOptions.Algorithm='interior-point';
    [x,MinVal] = fmincon(f,Initialx,[],[],Aeq,beq,MinValues,MaxValues,[],OptOptions);

  if HasExistingz==true;
    if Fixz>0
      %One value fixed, so slot in at the correct position
      z=[x(1:Fixz-1);zPre;x(Fixz:m-1)]';
      VarCount=m-1;
    else
      z=zPre;
      VarCount=0;
    end
  else
    z=x(1:m)';
    VarCount=m;
  end

  if HasExistingD==true
    if FixD>0
      %One value fixed, so slot in at the correct position
      D=[reshape(x(VarCount+1:VarCount+(FixD-1)*m),FixD-1,m);DPre;reshape(x(VarCount+(FixD-1)*m+1:VarCount+(n-1)*m),n-FixD,m)];
      VarCount=VarCount+m*(n-1);
    else
      D=DPre;
    end
  else
    D=reshape(x(VarCount+1:VarCount+n*m),n,m);
    VarCount=VarCount+n*m;
  end

  BiasCol=0; %Initially assume no bias col
  switch BiasType
    case 0
      %No bias
      Bias=[zeros(n,1),ones(n,1)];
    case 1
      %Additive bias
      Bias=[x(VarCount+1:VarCount+n),ones(n,1)];
      VarCount=VarCount+n;
    case 2
      %Multiplicative bias
      Bias=[zeros(n,1),x(VarCount+1:VarCount+n)];
      VarCount=VarCount+n;
    case 3
      %If fixed bias then save temporary bias for later optimization.
      %N.B. Only one of FixedAddBias and MultAddBias can be different
      %from 0
      Bias=[];
      if ((FixAddBias==0)||(FixAddBias==-99))&&((FixMultBias==0)||(FixMultBias==-99))
        Bias=[x(VarCount+1:VarCount+n),x(VarCount+n+1:VarCount+2*n)];
        VarCount=VarCount+2*n;
      else
        BiasCol=x(VarCount+1:VarCount+n);
        VarCount=VarCount+n;
        [V,I]=sort(abs(median(BiasCol)-BiasCol));
        if FixAddBias>0 
          FixAddBias=I(1);
          BiasCol=BiasCol(FixAddBias);
        elseif FixMultBias>0
          FixMultBias=I(1);
          BiasCol=BiasCol(FixMultBias);
        end
      end       
  end

  
  %If on part of the bias has been fixed then rerun with the main
  %parameters and the bias not fixed.  Only fixing the initial bias, which
  %does not need to be bounded.
  if RunFixedBias==true
    %if only partial fix then fix on the average value
    Aeq=[];beq=[]; 
    if FixAddBias>0
      %x2 is the multiplicative bias.  Add all additive bias values - fixed
      %value first
      x2=[BiasAdd(1:FixAddBias-1);BiasAdd(FixAddBias+1:n);x2];
      MinValues2=[ones(n-1,1)*-inf;MinValues2]; 
      MaxValues2=[ones(n-1,1)*inf;MaxValues2];  
      if FixMultBias==-99
        Aeq=[Aeq;[zeros(1,n-1),ones(1,n)]];
        beq=[beq;n];
      end
    else
      if FixMultBias==-99
        Aeq=[Aeq;[ones(1,n)]];
        beq=[beq;n];
      end
    end
    if FixMultBias>0
      %x2 is the additive bias.  Add all multiplicative bias values - fixed
      %bias value first
      x2=[x2;BiasMult(1:FixMultBias-1);BiasMult(FixMultBias+1:n)];
      MinValues2=[MinValues2;ones(n-1,1)*0]; 
      MaxValues2=[MaxValues2;ones(n-1,1)*inf]; 
      if FixAddBias==-99
        Aeq=[Aeq;[ones(1,n),zeros(1,n-1)]];
        beq=[beq;0];
      end
    else
      if FixAddBias==-99
        Aeq=[Aeq;[ones(1,n),zeros(1,n-1)]];
        beq=[beq;0];
      end      
    end
    OptOptions.Algorithm='interior-point';
    f = @(x)DCCCTMin1(x,X,P,EstMethod,BiasType,[-1,-1,FixAddBias,FixMultBias],z,D,BiasCol);
    [x,MinVal] = fmincon(f,x2,[],[],[],[],MinValues2,MaxValues2,[],OptOptions);
  
    %Add the bias depending on the bias type
    switch FixAddBias
      case {0,-99}
        %No fixing of  additive bias
      case -1
        %Additive bias is ficed annd multiplicative bias is fixed at the
        %second stage
        Bias=[BiasCol,x];
      otherwise
        Bias=[[x(1:FixAddBias-1);BiasCol;x(FixAddBias:n-1)],[x(n:2*n-1)]];
    end
    switch FixMultBias
      case {0,-99}
        %No fixing of the multiplicative bias
      case -1
        %Multiplicative bias is fixed
        Bias=[x,BiasCol]; 
      otherwise
        Bias=[[x(1:n)],[x(n+1:n+FixMultBias-1);BiasCol;x(n+FixMultBias:2*n-1)]];        
    end
  end
    
  %Remove the additional value of X
  if AddLine==true
    n=n-1;
    X=X(1:n,:);
    P=P(1:n,:);
    D=D(1:n,:);
    Bias=Bias(1:n,:);
  end
  
   %Calculate the criterion value
  switch EstMethod
    case 1
      %Calculate the residual from the VAF
      MeanVal=mean(mean(CorrMatrix));
      MaxCrit=1-(ssq(Resid)./ssq(CorrMatrix-MeanVal));
      %Weight using the number of items (need this to make it consistant
      %for the clusterwise estimation procedure
      MaxCrit=MaxCrit.*100;
      LLPartial=zeros(3,m);
    case {0,2,3,4,5,6}
      %Calculate the inner term for the bias
      InnerTerm=(X-(Bias(:,1)*ones(1,m))-Bias(:,2)*z); 
      Part1=P.*(log(((D)./(2*pi)).^0.5));
      Part2=P.*((-D).*(InnerTerm.^2)./2);      
      MaxCrit=sum(sum(Part1))+sum(sum(Part2));    
      %Calculate the partial log likelihoods
      LLPartial=zeros(3,m);
      for j=1:m
        zval=z(j);
        %Store z, the lower bound and the upper bound
        zAll=[zval,fix(zval),fix(zval+1)];
        DAll=D(:,j)*ones(1,3);
        InnerTerm=(X(:,j)*ones(1,3)-(Bias(:,1)*ones(1,3))-Bias(:,2)*zAll);
        Part1=(P(:,j)*ones(1,3)).*(log(((DAll)./(2*pi)).^0.5));
        Part2=(P(:,j)*ones(1,3)).*(-DAll).*(((InnerTerm).^2)./2);
        LLPartial(:,j)=(sum(Part1,1)+sum(Part2,1))';
      end 
  end
    
  



