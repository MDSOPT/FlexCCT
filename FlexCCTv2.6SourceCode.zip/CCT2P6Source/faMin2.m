function [f,g,H] = faMin2(x,R)
%fa2Min - Provides the function value and gradient value for the residual 
%factor analysis procedure
%Inputs
%x - The current value of the function parameters (F, but gone with Matlab
%notation)
%R - The source matrix
%Outputs
%f - The (n*1) function vector for x
%g - The (n*1 ) 1st order gradient vector for x
%H - The (n*n ) 2nd order Hessian matrix for x
%Version     Author            Date
%   0.10     Stephen France    04/01/2012

n=size(x,1);

%Calculating nonzero function differences
DiffSq=(R-x*x').^2;
DiffSq=DiffSq-diag(diag(DiffSq));
f=sum(sum(DiffSq))./2;

%Gradient 
G1=2*sum(R.*(ones(n,1)*x'),2);
G2=2*sum((x*ones(1,n)).*((ones(n,1)*(x'.^2))),2);
g=G2-G1;

%Hessian -2r(ij)a(j)+4a(i)a(j)
H1=-2.*R+4.*(x*x'); 
H1=H1-diag(diag(H1));
H2=2.*ones(n,1)*(x'.^2);
H2=H2-diag(diag(H2));
H2=sum(H2,2);
H=H1+diag(H2);

end

