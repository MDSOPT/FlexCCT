function [X,zGround,HasColHeader,HasRowHeader,ColHeader,RowHeader,MissingVal] = ProcessFile(X,handles)
%Takes the input file, checks it for headers/text information.  Using the
%data and the specification from the GUI to force headers
%(chkRowHeaders,chkColHeaders) creates the numeric data matrix and the
%actual headers.  Uses row/colummn numbers if text is not available and headers are specified.  Moved
%from GUI
%INPUTS
%X         - The raw input data file.  Can contain a numeric information
%            and text headers
%handles   - The handles for the GUI objects 
%OUTPUTS
%X            - An n rater * m item numeric ratings matrix
%HasColHeader - If 1 if row headers are used, 0 otherwise
%HasRowHeader - If 0 if row headers are used, 1 otherwise
%ColHeader    - A length m cell array containing the column headers
%RowHeader    - A length n cell array containing the column headers
%Version     Author            Date
%   2.50     Stephen France    01/17/2017
  if isnumeric(X)==0
    %data possibly contains some headers
    Text=X.textdata;
    X=X.data;
    FirstRow=Text(1,:);
    FirstCol=Text(:,1);    %Need to diagnoze if row header or col header
    HasColHeader=size(FirstRow,2)>1; 
    HasRowHeader=size(FirstCol,1)>1;
    if (HasRowHeader==true) && (HasColHeader==true)
      RowHeader=FirstCol(2:size(FirstCol,1));
      ColHeader=FirstRow(2:size(FirstRow,2));
    elseif (HasRowHeader==false) && (HasColHeader==true)
      ColHeader=FirstRow(1:size(FirstRow,2));
      RowHeader='';
    elseif (HasRowHeader==true) && (HasColHeader==false)
      RowHeader=FirstCol(1:size(FirstCol,1));
      ColHeader='';
    else
      RowHeader='';ColHeader='';
    end
  else
    HasRowHeader=false;HasColHeader=false;
    RowHeader='';ColHeader='';
  end
  [Tempn,Tempm]=size(X);
  if (HasRowHeader==false)&&get(handles.chkRowHeaders,'Value')
    if (HasColHeader==false)&&get(handles.chkColHeaders,'Value')
      %Has both row and column headers
      RowHeader = X(2:Tempn,1);ColHeader=X(1,2:Tempm);
      X=X(2:Tempn,2:Tempm);   
      HasRowHeader=true;HasColHeader=true;
    else
      %Has row header, but not column header
      RowHeader = X(:,1);
      X=X(:,2:Tempm); 
      HasRowHeader=true;
    end
  else
    if (HasColHeader==false)&&get(handles.chkColHeaders,'Value')
      %Has column header and no row header
      ColHeader=X(1,:);
      X=X(2:Tempn,:); 
      HasColHeader=true;
    end
  end
  %1.num traits
  NoTraits=str2num(get(handles.cmdTraits,'string'));

  %2.data combination
  %set data combination value based on selected option
  if get(handles.cmdAddTraits,'value')==1
      DATCombine=0;
  elseif get(handles.cmdCorrespond,'value')==1
      DATCombine=1;
  end

  %3.data standardization
  %set the value based on selected option
  if get(handles.cmdNone,'value')==1
      DATStandard=0;
  elseif get(handles.cmdStandardize,'value')==1
      DATStandard=1;
  elseif get(handles.cmdRange,'value')==1
      DATStandard=2;
  elseif get(handles.cmdLog,'value')==1
      DATStandard=3;
  end
  
  %9.Missing Value
  MissingVal=str2num(get(handles.txtMissingValue,'string'));
  
  %Get the value of X.
  [X] = CreateSingleX(X,NoTraits,DATCombine,DATStandard,MissingVal);
  
  %Check if the ground truth is included in the rows
  [n,m]=size(X);
  HasGroundTruth = get(handles.chkGroundTruth,'value');
  %Set the application level setting for ground truth
  setappdata(0,'HasGroundTruth',HasGroundTruth);
  %Calculate the ground truth values
  if (HasGroundTruth==true)
    zGround=X(1,:);
    X=X(2:n,:);
    n=n-1;
  else
    zGround=[];
  end

end

