function [OptValue,RealHR,RealFPR] = CCTFunction(X,Z,OptFunction,W)
%Calculates the maximum likelihood function for cultural consensus theory
%where there is a binary true/false response.  Accounts for missing data.
%   Detailed explanation goes here
%X -          An n*m subject*item matrix
%Z -          A 1*m answer key vector
%W -          An n*m matrix of weighting values for the maximum likelihood
%OptFunction-  The function to maximize/minimize
%          - 0 Linear Function (hits - false positives)
%          - 1 Maximum Likelihood function
%          - 2 1/2 a Maximum Likelihood function (only HR and (1-FPR)
%
%Outputs
%OptValue  - The value of the function
%RealHR    - An n*1 vector of hit rates
%RealFP    - An n*1 vector of false positive rates
%Version     Author            Date
%   0.10     Stephen France    04/20/2012

  BigN=1E6;

  [n,m]=size(X);
  
  if ~exist('W','var')
    W=ones(n,m);
  end
  
  %Firstly calculate the values of D and g
  Hits=X.*(ones(n,1)*Z);
  FPositives=X.*(ones(n,1)*(1-Z));
  %Proportion of hits and false positives)
  %If Z=1 for all items or Z=0 for all items then the problem is not
  %Fully defined (take as 0 (e.g. no false positives or hits)
  RealHR=sum(Hits,2)./(sum(Z));
  HR=sum(Hits,2)./(sum(Z)+((sum(Z))==0));
  RealFPR=sum(FPositives,2)./(sum(1-Z));
  FPR=sum(FPositives,2)./(sum(1-Z)+((sum(1-Z))==0));  

  %Ensure penalties for breaking model assumptions.
  Penalty=sum(max(RealFPR-HR,0))*BigN;
  
  if (OptFunction==0)
    %Need to weight by the number of 1s and 0s
    OptValue=Penalty+sum(FPR)-sum(HR);
  else
    %If all values are 0 then ignore likelihood terms.  Can do this
    %As all values of the second term will be 0.  Ensure that 
    
    LogHR=log(HR+(HR==0));
    LogFPR=log(FPR+(FPR==0));
    LogNHR=log((1-HR)+((1-HR)==0));
    LogNFPR=log((1-FPR)+((1-FPR)==0));
    
    %Calculate maximum likelihood
    HitLK=(LogHR*ones(1,m)).*(W.*X.*(ones(n,1)*Z));
    FPLK= (LogFPR*ones(1,m)).*(W.*X.*(ones(n,1)*(1-Z)));
    NotHitLK=(LogNHR*ones(1,m)).*(W.*(1-X).*(ones(n,1)*Z));
    NotFPLK=(LogNFPR*ones(1,m)).*(W.*(1-X).*(ones(n,1)*(1-Z))); 
    if (OptFunction==1)
      OptValue=(sum(sum(HitLK))+sum(sum(FPLK))+sum(sum(NotHitLK))+sum(sum(NotFPLK)));
    else
      %Only take 1/2 the parameters (HR and (1-FPR))
      OptValue=(sum(sum(HitLK))+sum(sum(NotFPLK)));
    end  
    %Matlab sometimes has complex number, probably slight rounding error
    OptValue=Penalty-real(OptValue);
  end
end

