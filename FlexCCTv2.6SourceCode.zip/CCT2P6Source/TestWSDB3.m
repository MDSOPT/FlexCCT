%The first experiment for the web search and data mining conference

AllResults=[];
MinScale=0.5;
OverallRun=0;

for NoItems=25:25:250
  for NoUsers=25:25:250
    for Scale=5:10
      Range=Scale-1;
      Centre=1+(Range/2);
      for TrueDist=1:2
        for MissingPC=0:10:90
          for Scheme=1:5
            for DMax=10:10
              for RangeDivisor=5:2:11
                OverallRun=OverallRun+1;
                if mod(OverallRun,10)==0
                  OverallRun
                end
                Results=[DMax,NoItems,NoUsers,Scale,TrueDist,MissingPC,Scheme,RangeDivisor];
                %First randomly select true review scores
                if TrueDist==1
                  %Sample from normal distribution with mean at the center
                  %point and with 1 standard devation = 1/6 range
                  z = norminv(rand(1,NoItems),Centre,Range/5);
                else
                  %Sample from uniform distribution
                  z=(rand(1,NoItems).*Range)+1;
                end
                %Determine latent competencies for users
                Mind=(Range/3)^(-2);
                Midd=(Range/6)^(-2);
                Maxd=(Range/9)^(-2);
                switch Scheme
                case 1
                  %Select all users to have the average competancy
                  D=ones(NoUsers,1).*Midd;
                case 2
                  %Random competencies between min and max
                  D=Mind+rand(NoUsers,1).*(Maxd-Mind);
                case 3
                  %75% competent and 25% not competent
                  IsComp=rand(NoUsers,1)>0.25;
                case 4
                  %50% competent and 50% not competent
                  IsComp=rand(NoUsers,1)>0.5;
                case 5 
                  %25% competent and 75% not competent
                  IsComp=rand(NoUsers,1)>0.75;              
                end
                switch Scheme
                  case {3,4,5}
                  %Users competent if one and not competent if 0
                  D=IsComp.*Maxd+(1-IsComp).*Mind;
                end
                %Select biases based upon the range divisor
                Biases= norminv(rand(NoUsers,1),0,Range/RangeDivisor);
                %Now sample an answer key given the competency and the true
                %score
                %Sample an error matrix based on competencies
                Error=zeros(NoUsers,NoItems);
                for i=1:NoUsers
                  P=rand(1,NoItems);
                  Error(i,:) = norminv(P,0,(D(i)^(-0.5)));
                end
                %Add the error to the actual values of the items
                X=ones(NoUsers,1)*z+Biases*ones(1,NoItems)+Error;
                X=round(X);
                X=min(max(1,X),Scale);   %Ensure in bounds
                %Replace any missing data by -1
                IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                AllAssigned=isempty(find(sum(1-IsMissing,1)==0))&&isempty(find(sum(1-IsMissing,2)==0));
                while (AllAssigned==0)
                  IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                  [IsMissing,AllAssigned]=FixMissing(IsMissing,1000);
                end
                X=-IsMissing+(1-IsMissing).*X;

                %Now run continuous cultural consensus theory
                [z0,D0,OP3,MaxCrit] = ContinuousCCT(X,0,1e-6,1000,-1,DMax,Midd);
                [z2,D2,OP3,MaxCrit,LLPartial] = ContinuousCCT(X,2,1e-6,1000,-1,DMax,Midd);
                [IC2] = InformationCriteria(MaxCrit,NoItems+NoUsers,sum(sum(1-IsMissing)));
                [z4,D4,Biases4,MaxCrit,LLPartial] = ContinuousCCT(X,4,1e-6,1000,-1,DMax,Midd);
                [IC4] = InformationCriteria(MaxCrit,NoItems+(2*NoUsers),sum(sum(1-IsMissing)));
                Results2=zeros(1,18);
                if IC2.AIC<0
                 temp=0;
                end
                %Calculate the MAE and MSE between Ds for all models
                Results2(1)=sum((D-D2).^2)./NoUsers;
                Results2(2)=sum(abs(D-D2))./NoUsers;
                Results2(3)=sum((D-D4).^2)./NoUsers;
                Results2(4)=sum(abs(D-D4))./NoUsers; 
                %Now calculate the accuracy of z
                Results2(5)=sum((z-z0).^2)./NoItems;
                Results2(6)=sum(abs(z-z0))./NoItems;
                Results2(7)=sum((z-z2).^2)./NoItems;
                Results2(8)=sum(abs(z-z2))./NoItems;
                Results2(9)=sum((z-z4).^2)./NoItems;
                Results2(10)=sum(abs(z-z4))./NoItems;
                %Now calculate the actual biases
                Results2(11)=sum((Biases-Biases4).^2)./NoItems;
                Results2(12)=sum(abs(Biases-Biases4))./NoItems;               
                
                %Return the AIC,AICc, and BIC for the two models
                Results2(13)=IC2.AIC;
                Results2(14)=IC2.CorAIC;
                Results2(15)=IC2.BIC;
                Results2(16)=IC4.AIC;
                Results2(17)=IC4.CorAIC;
                Results2(18)=IC4.BIC;

                NewResults=[Results,Results2];
                AllResults=[AllResults;NewResults];
                save 'C:\CCOut\BiasesAll.txt' NewResults -append -ascii;
              end
            end
          end
        end
      end
    end
  end
end