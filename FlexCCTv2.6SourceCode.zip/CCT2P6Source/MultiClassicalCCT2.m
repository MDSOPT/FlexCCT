function [ZMulti,ZPattern,ZPattern2,AvgD,AvgD2,AllResults] = MultiClassicalCCT2(X,InMethod,OptMethod,IsMissing,MissingVal,CovProb,OptLevel)
%A multiple category version of the classical implementation of Cultural Consensus Theory as described
%in Batchelder and Romney (1988).  This procedure utilizes a threshold
%model and multiple binary classical CCT analyses (with each possible
%threshold for ordered categories)>
%Inputs 
%X - An n*m subject*item matrix
%InMethod  - 0 perform factor analysis on covariance matrix
%          - 1 perform factor analysis on matching matrix
%OptMethod - 0 Perform a principal axes factor analaysis
%          - 1 Exact method described in Comrey and Al Ahumada (1964)
%          - 2 Perform a quadratic programming procedure
%IsMissing - 1 if missing values are present, 0 otherwise
%MissingVal - The identifier for missing data (should be outside range of actual values) 
%CovProb    - If the covariance matrix is utilized then estimate the
%             probablity of Z* (defaults to 0.5).  Use 0 if matching.
%OptLevel  - If OptMethod = 3 then the level of the optimization procedure used 
%          - 0 Use non-derivative optimization method
%          - 1 Also use the first derivatives (gradient vector)
%          - 2 Also use the second derivatives (Hessian matrix)
%Outputs
%ZMulti    - An 1*m answer key vector of multi-category answers
%ZPattern  - A (c-1)*m pattern matrix of binary 0-1 answers
%AvgD      - An n*1 vector of average competencies across thresholds
%AvgD2     - As AvgD2 but for competencies after PCA.
%AllResults- A structure containing the following:
%-------------------------------------------------------------------------
%Categories- A 1*c vector of categories (c is no. categories)
%ThreshCount - Number of thresholds (c-1)
%For each threshold 1 to (c-1), the following information
%Resid - A set of residuals after initial estimation
%Resid2 - A set of residuals after performing the PCA
%VAF - Variance accounted for by initial estimation
%VAF - Variance accounted for after calculating PCA
%--------------------------------------------------------------------------
%Version     Author            Date
%   0.10     Stephen France    05/05/2012

[n,m]=size(X);

%Get the minimum and maximum categorical values
MinValue=min(min(X));
MaxValue=max(max(X));
Categories=[];

%Include missing values in each binary matrix
if (IsMissing==1)
  %Set all initial values to 1 apart from missing values
  CurBinary=(+(X~=MissingVal))+(+(X==MissingVal)).*MissingVal;
  CurBinary2=(+(X==MissingVal)).*MissingVal;
else
  CurBinary=ones(n,m);
  CurBinary2=zeros(n,m);
end 

ZPattern=[];ZPattern2=[];
SumD=0;SumD2=0;SumVAF=0;SumVAF2=0;
ThreshCount=0;   %No. thresholds (No. Categories - 1)
for i=MinValue:MaxValue-1
  %All categories must have at least one value
  if ~isempty(find(X==i))
    Categories=[Categories,i];
    ThreshCount=ThreshCount+1;
    %Set threshold so all categories up to i are 0 and all categories > i
    %are equal to 1
    CurBinary=CurBinary-(+(X==i));
    CurBinary2=CurBinary2+(+(X==i));
    %Perform classical cultural consensus analysis
    switch nargin
    case 4
        [Z,D,D2,Resid,Resid2,VAF,VAF2] = ClassicalCCT(CurBinary,InMethod,OptMethod,IsMissing);
    case 5
        [Z,D,D2,Resid,Resid2,VAF,VAF2] = ClassicalCCT(CurBinary,InMethod,OptMethod,IsMissing,MissingVal);
    case 6
        [Z,D,D2,Resid,Resid2,VAF,VAF2] = ClassicalCCT(CurBinary,InMethod,OptMethod,IsMissing,MissingVal,CovProb);
    case 7    
        [Z,D,D2,Resid,Resid2,VAF,VAF2] = ClassicalCCT(CurBinary,InMethod,OptMethod,IsMissing,MissingVal,CovProb,OptLevel);
    end
    
    ZPattern=[ZPattern;Z];
    %Save all the stagewise results
    AllResults.Z{i}=Z;
    AllResults.D{i}=D;
    AllResults.D2{i}=D2;
    AllResults.Resid{i}=Resid;
    AllResults.Resid2{i}=Resid2;
    AllResults.VAF{i}=VAF;
    AllResults.VAF2{i}=VAF2;
    SumD=SumD+D;
    SumD2=SumD2+D2;
    SumVAF=SumVAF+VAF;
    SumVAF2=SumVAF2+VAF2;
    switch nargin
    case 4
        [Z,D,D2,Resid,Resid2,VAF,VAF2] = ClassicalCCT(CurBinary2,InMethod,OptMethod,IsMissing);
    case 5
        [Z,D,D2,Resid,Resid2,VAF,VAF2] = ClassicalCCT(CurBinary2,InMethod,OptMethod,IsMissing,MissingVal);
    case 6
        [Z,D,D2,Resid,Resid2,VAF,VAF2] = ClassicalCCT(CurBinary2,InMethod,OptMethod,IsMissing,MissingVal,CovProb);
    case 7    
        [Z,D,D2,Resid,Resid2,VAF,VAF2] = ClassicalCCT(CurBinary2,InMethod,OptMethod,IsMissing,MissingVal,CovProb,OptLevel);
    end
    ZPattern2=[ZPattern2;Z];
    
  end
end
AllResults.Categories=[Categories,MaxValue];
AllResults.ThreshCount=ThreshCount;
AvgD=SumD./ThreshCount;
AvgD2=SumD2./ThreshCount;
AllResults.AvgVAF=SumVAF./ThreshCount;
AllResults.AvgVAF2=SumVAF2./ThreshCount;

%Placeholder
ZMulti=1;



