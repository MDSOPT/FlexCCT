%The first experiment for the web search and data mining conference

AllResults=[];
MinScale=0.5;
OverallRun=0;
MaxFail=10;

for Run=3:4
  for NoItems=50:50:50
    for NoUsers=50:50:50
      for Scale=10:10
        Range=Scale-1;
        Centre=1+(Range/2);
        for TrueDist=1:2
          for MissingPC=0:0
            for Scheme=1:5
              for DMax=5:5
                for p=0.2:0.2:2
                  %First randomly select true review scores
                  if TrueDist==1
                    %Sample from normal distribution with mean at the center
                    %point and with 1 standard devation = 1/6 range
                    z = norminv(rand(1,NoItems),Centre,Range/5);
                  else
                    %Sample from uniform distribution
                    z=(rand(1,NoItems).*Range)+1;
                  end
                  %Determine latent competencies for users
                  Mind=mean(z)./((Range/3).^(2));
                  Midd=mean(z)./((Range/6).^(2));
                  Maxd=mean(z)./((Range/9).^(2));
                  switch Scheme
                  case 1
                    %Select all users to have the average competancy
                    D=ones(NoUsers,1).*Midd;
                  case 2
                    %Random competencies between min and max
                    D=Mind+rand(NoUsers,1).*(Maxd-Mind);
                  case 3
                    %75% competent and 25% not competent
                    IsComp=rand(NoUsers,1)>0.25;
                  case 4
                    %50% competent and 50% not competent
                    IsComp=rand(NoUsers,1)>0.5;
                  case 5 
                    %25% competent and 75% not competent
                    IsComp=rand(NoUsers,1)>0.75;              
                  end
                  switch Scheme
                    case {3,4,5}
                    %Users competent if one and not competent if 0
                    D=IsComp.*Maxd+(1-IsComp).*Mind;
                  end
                  %Now sample an answer key given the competency and the true
                  %score
                  %Sample an error matrix based on competencies
                  Error=zeros(NoUsers,NoItems);
                  for i=1:NoUsers
                    P=rand(1,NoItems);
                    Error(i,:) = norminv(P,0,(((z.^p)/D(i)).^(-0.5)));
                  end
                  %Add the error to the actual values of the items
                  X=ones(NoUsers,1)*z+Error;
                  X=round(X);
                  X=min(max(1,X),Scale);   %Ensure in bounds
                  %Replace any missing data by -1
                  IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                  AllAssigned=isempty(find(sum(1-IsMissing,1)==0))&&isempty(find(sum(1-IsMissing,2)==0));
                  while (AllAssigned==0)
                    IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                    [IsMissing,AllAssigned]=FixMissing(IsMissing,1000);
                  end
                  X=-IsMissing+(1-IsMissing).*X;
                  Fail=true;FailNo=0;
                  while (Fail==true&&FailNo<=MaxFail)
                    try
                      [z2,D2,Bias,QE,MaxCrit2,LLPartial] = ContinuousCCT3(X,2,0,[0,0,0,0],[1e-10,1000,1],-1,0);
                      Fail=false;
                    catch
                      FailNo=FailNo+1
                    end
                  end
                  if (Fail==false)
                    for Testp=0.2:0.2:2
                      OverallRun=OverallRun+1;
                      if mod(OverallRun,10)==0
                        OverallRun
                      end
                      Results=[Run,p,Testp,DMax,NoItems,NoUsers,Scale,TrueDist,MissingPC,Scheme];
                      %Now run continuous cultural consensus theory
                      Fail=true;FailNo2=0;
                      while (Fail==true&&FailNo<=MaxFail)
                        try  
                          [z3,D3,Bias,QE,MaxCrit3,LLPartial] = ContinuousCCT3(X,6,0,[0,0,0,0],[1e-10,1000,1,Testp],-1,0);
                          Fail=false;
                        catch
                          FailNo2=FailNo2+1
                        end
                      end
                      if Fail==false
                        Results2=zeros(1,14);
                        %Calculate the MAE and MSE between Ds for all models
                        Results2(1)=MaxCrit2;
                        Results2(2)=sum((D-D2).^2)./NoUsers;
                        Results2(3)=sum(abs(D-D2))./NoUsers;
                        %Calculate the MAE and MSE between Ds for all models
                        Results2(4)=sum((D-D2).^2)./NoUsers;
                        Results2(5)=sum(abs(D-D2))./NoUsers;
                        %Now calculate the accuracy of z
                        Results2(6)=sum((z-z2).^2)./NoItems;
                        Results2(7)=sum(abs(z-z2))./NoItems;
                        %Calculate the MAE and MSE between Ds for all models
                        Results2(8)=MaxCrit3;
                        Results2(9)=sum((D-D3).^2)./NoUsers;
                        Results2(10)=sum(abs(D-D3))./NoUsers;
                        %Calculate the MAE and MSE between Ds for all models
                        Results2(11)=sum((D-D3).^2)./NoUsers;
                        Results2(12)=sum(abs(D-D3))./NoUsers;
                        %Now calculate the accuracy of z
                        Results2(13)=sum((z-z3).^2)./NoItems;
                        Results2(14)=sum(abs(z-z3))./NoItems;
                      else
                        Results2=ones(1,14)*-1;
                      end

                      NewResults=[Results,Results2];
                      AllResults=[AllResults;NewResults];
                      save 'C:\CCOut\CONCLUSV2\WeberFechner.txt' NewResults -append -ascii;
                    end
                  end
                end
              end
            end
          end
        end
      end
    end
  end
end