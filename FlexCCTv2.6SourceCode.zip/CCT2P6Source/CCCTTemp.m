function [f,g] = CCCTMin1(x,X,P,EstMethod,BiasType,FixParams,z,d,BiasCol,QE)
%fa2Min - Provides the function and the first derivatives for continuous cultural consensus
%log likelihood function
%INPUTS
%x - The current value of the function parameters (F, but gone with Matlab
%notation) of size (m+m)*1 for EstMethod=2   or (2n+m)*1 for EstMethod = 3 or 4.
%X - The input matrix of questionnaire answers 
%P - An indicator matrix. 1 if data is present, 0 if data is missing
%EstMethod - See header for ContinuousCCT2
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          Currently bias 1 and 2 are only available for estimation methods
%          3,4, and 6
%FixParams - Fix parameters. A one by three array of items that contains
%          the following information.
%Fixz      - 0 Don't fix z at all
%          - -1 Fix z if an initial optimization run using EstMethod=2
%          - ItemNo (Partial fix).  Fix the value of z for the given item
%          number
%FixD      - 0 Don't fix D at all
%          - -1 Fix D if an initial optimization run using EstMethod=2
%          - UserNo (Partial fix).  Fix the  value of D for the given user
%          number
%FixAddBias- 0 Don't fix the additive bias at all
%          - -1 Fix the additive bias first before calculating the
%          multiplicative bias
%          - UserNo Partial fix of the additive bias.  Fix the value of additive
%          bias for the given rater
%          - -99 Set the average additive bias to be 0
%FixMultBias- 0 Don't fix the multiplicative bias at all
%          - -1 Fix the multiplicative bias first before calculating the
%          multiplicative bias
%          - UserNo Partial fix of the multiplicative bias.  Fix the value of additive
%          bias for the given rater
%          - -99 Set the average multiplicative bias to be 1
%Optional parameters passed if values are fixed
%  d - n*1 vector of competencies
%  z - a m*1 vector of answers
%  Bias - a n*1 vector of biases (if BiasType=0, i.e. no bias then all = 1)
%OUTPUTS
%f - The function value for x
%Version     Author            Date
%   0.10     Stephen France    04/01/2012
%   2.00     Stephen France    03/31/2016

%Start by collapsing x (z is a row vector so transform)
[n,m]=size(X);

Fixz=FixParams(1);Fixd=FixParams(2);
FixAddBias=FixParams(3);FixMultBias=FixParams(4);

Hasz=false;
VarCount=0;
if EstMethod>0
  switch Fixz
    case -1
      %Do nothing
    case {0,-99}
      %z is freeform
      z=x(1:m)';
      VarCount=VarCount+m;
      Hasz=true;
    otherwise
      %z is the value for a single column item, which is to be fixed
      z=[x(1:Fixz-1);z;x(Fixz:m-1)]';
      VarCount=VarCount+m-1;
      Hasz=true;
  end
end
  

%Estimate competency unless simple average
Hasd=false;
if (EstMethod>0)
  %d is estimated if not provided the procedure.
  switch Fixd
    case {0,-99}
      d=x(VarCount+1:VarCount+n*m);
      VarCount=VarCount+n*m;
      Hasd=true;
    case -1
      %D is fixed and is not included in the optimization
    otherwise
      d=[x(VarCount+1:VarCount+Fixd-1);d;x(VarCount+Fixd:VarCount+n*m-1)];
      VarCount=VarCount+n*m-1;
      Hasd=true;
  end
else
  d=ones(n,1);
end

if BiasType>0
  %Fit single set of biases
  if BiasType==1||BiasType==2
    Bias=x(VarCount+1:VarCount+n);
    VarCount=VarCount+n;
  elseif BiasType==3
    %Fit both biases together.  If one bias i
    switch FixAddBias
      case {0,-99}
        %Neither column of the bias is fixed
        AddBias=x(VarCount+1:VarCount+n);
        VarCount=VarCount+n;
      case {-1}
        %The additive bias is fixed and is passed to procedure
        AddBias=BiasCol;
      otherwise
        %A single value is fixed
        AddBias=[x(VarCount+1:VarCount+FixAddBias-1);BiasCol;x(VarCount+FixAddBias:VarCount+n-1)];
        VarCount=VarCount+n-1 ;
    end
    switch FixMultBias
      case {0,-99}
        %Neither column of the bias is fixed
        MultBias=x(VarCount+1:VarCount+n);
        VarCount=VarCount+n;
      case {-1}
        %The additive bias is fixed and is passed to procedure
        MultBias=BiasCol;
      otherwise
        %A single value is fixed
        MultBias=[x(VarCount+1:VarCount+FixMultBias-1);BiasCol;x(VarCount+FixMultBias:VarCount+n-1)];
        VarCount=VarCount+n-1; 
    end
    Bias=[AddBias,MultBias];
  end
end

if ~exist('QE','var')
  switch EstMethod
    case {0,2,6}
      %No question easyness in model
      QE=ones(1,m);
      HasQE=false;
    case {3,4,5}
      %Question easyness model
      QE=x(VarCount+1:VarCount+m)';
      HasQE=true;
  end
else
  HasQE=false;
end

switch BiasType
  case {0}
    InnerTerm=(X-ones(n,1)*z);
  case 1
    InnerTerm=(X-Bias*ones(1,m)-ones(n,1)*z);
  case 2
    InnerTerm=(X-Bias*z); 
  case 3
    InnerTerm=(X-(Bias(:,1)*ones(1,m))-Bias(:,2)*z);
end

%Term 1 uses the standard item competency for all terms
switch EstMethod
  case {0,2}
    %Basic maximum likelihood model
    Term1=((d*ones(1,m))./(2*pi)).^0.5;
    Term2=(d*ones(1,m)).*(InnerTerm.^2)./2;
  case {3}
    %Item difficulty variance model
    Term1=((d*QE)./((d*ones(1,m)+ones(n,1)*QE)*2*pi)).^0.5;
    Term2=(d*QE).*(InnerTerm.^2)./((d*ones(1,m)+ones(n,1)*QE)*2);
  case {4}
    %Scalar item difficulty
    Term1=((d*QE)./(2*pi)).^0.5;
    Term2=(d*QE).*(InnerTerm.^2)./2;
  case {5}
    %Additive item difficulty
    Term1=(((d*ones(1,m))+(ones(n,1)*QE))./(2*pi)).^0.5;
    Term2=((d*ones(1,m))+(ones(n,1)*QE)).*(InnerTerm.^2)./2;
  case {6}
    %Weber Fechner law
    Term1=((d*ones(1,m))./(2*pi)).^0.5;   %(1./(ones(n,1)*z)).*
    Term2=(d*ones(1,m)).*(InnerTerm.^2)./(2.*ones(n,1)*z);
end
Term1=log(Term1);

Total=(Term1-Term2).*P;
f=-sum(sum(Total));

switch EstMethod 
  case {0,2,4,5}
    switch EstMethod
      case {0,2,4}
        CompTerm=d*QE;
      case 5  
        CompTerm=(d*ones(1,m))+(ones(n,1)*QE);
    end
    
    %Gradient for z
    if Hasz==true
      switch EstMethod
        case {2,4,5}
          switch BiasType
            case {0,1}
              g=-sum(P.*(CompTerm.*InnerTerm),1)'; 
            case {2}  
              g=-sum(P.*(CompTerm.*(Bias*ones(1,m)).*InnerTerm),1)';
            case 3
              g=-sum(P.*(CompTerm.*(Bias(:,2)*ones(1,m)).*InnerTerm),1)';
          end
          %If an item is fixed then we are not finding the gradient for it
          if Fixz>0
            g=[g(1:Fixz-1);g(Fixz+1:m)];
          end
      end
    else
      g=[];
    end

    %Competency gradient, if not passed as a parameter
    if Hasd==true;
      switch EstMethod
        case {2,4}
           gAdd=-sum(P.*(0.5./(d*ones(1,m))-0.5.*(ones(n,1)*QE).*(InnerTerm.^2)),2);
        case 5
           gAdd=-sum(P.*(0.5./(CompTerm)-0.5.*(InnerTerm.^2)),2);         
      end
      if (Fixd==0)||(Fixd==-99)
        g=[g;gAdd];
      else
        g=[g;gAdd(1:Fixd-1);gAdd(Fixd+1:n)];
      end
      
    end
    
    %Change in the bias type
    gAdd=[];
    switch BiasType
      case 1
        %Additive bias
        gAdd=-sum(CompTerm.*InnerTerm.*P,2);
      case 2
        %Multiplicative bias
        gAdd=-sum(CompTerm.*(ones(n,1)*z).*InnerTerm.*P,2);
      case 3
        %Check to ensure that additive bias is not fixed
        if FixAddBias~=-1
          gAdd=-sum(CompTerm.*InnerTerm.*P,2);
          if FixAddBias>0
            gAdd=[gAdd(1:FixAddBias-1);gAdd(FixAddBias+1:n)];
          end
        end
        %Check to ensure that multiplicative bias is not fixed
        if FixMultBias~=-1
          gAdd2=-sum(CompTerm.*(ones(n,1)*z).*InnerTerm.*P,2);
          if FixMultBias>0
            gAdd2=[gAdd2(1:FixMultBias-1);gAdd(FixMultBias+1:n)];
          end
          gAdd=[gAdd;gAdd2];
        end
    end
    g=[g;gAdd];
    
    if HasQE==true
      %Question easyness
      switch EstMethod
        case 4
          g=[g;-sum(P.*(0.5./(ones(n,1)*QE)-0.5.*(d*ones(1,m)).*(InnerTerm.^2)),1)'];
        case 5
          g=[g;-sum(P.*(0.5./(CompTerm)-0.5.*(InnerTerm.^2)),1)'];
      end
    end

  case 3
    %For case 5 d is still the competency, but delta b is the change in
    db1=((d*QE)./((d*ones(1,m))+(ones(n,1)*QE)));
    db2=((ones(n,1)*QE).^2)./((d*ones(1,m)+ones(n,1)*QE).^2);
    db3=((d*ones(1,m)).^2)./((d*ones(1,m)+ones(n,1)*QE).^2);
    
    if Hasz==true
      %Change in z
      switch BiasType
        case {0,1}
          g=-sum(db1.*InnerTerm,1)';
        case {2}
          %Multiplicative bias has extra term
          g=-sum(db1.*(Bias*ones(1,m)).*InnerTerm,1)';
        case 3
          g=-sum(db1.*(Bias(:,2)*ones(1,m)).*InnerTerm,1)';
      end
      if Fixz>0
        g=[g(1:Fixz-1);g(Fixz+1:m)];
      end
    else
      g=[];
    end
    
    if Hasd==true
      %Change in D
      gAdd=-sum(P.*(((db2./db1)-(db2.*(InnerTerm.^2)))./2),2); 
      if Fixd==0
        g=[g;gAdd];
      else
        g=[g;gAdd(1:Fixd-1);gAdd(Fixd+1:n)];
      end
    end
    
    gAdd=[];
    switch BiasType
      case 1
        %Additive bias
        gAdd=-sum(db1.*InnerTerm.*P,2);
      case {2}
        %Multiplicative bias
        gAdd=-sum(db1.*(ones(n,1)*z).*InnerTerm.*P,2);
      case 3
        %Additive and multiplicative bias
       if FixAddBias~=-1
          gAdd=-sum(db1.*InnerTerm.*P,2);
          if FixAddBias>0
            gAdd=[gAdd(1:FixAddBias-1);gAdd(FixAddBias+1:m)];
          end
        end
        %Check to ensure that multiplicative bias is not fixed
        if FixMultBias~=-1
          gAdd2=-sum(db1.*(ones(n,1)*z).*InnerTerm.*P,2);
          if FixMultBias>0
            gAdd2=[gAdd2(1:FixMultBias-1);gAdd(FixMultBias+1:m)];
          end
          gAdd=[gAdd;gAdd2];
        end
    end
    g=[g;gAdd];
    if HasQE==true
      %Change in QE
      g=[g;-sum(P.*(((db3./db1)-(db3.*(InnerTerm.^2)))./2),1)']; 
    end
  case 6
    %The Weber-Fechner law
    deltad=-sum(P.*((0.5./(d*ones(1,m)))-(0.5*(InnerTerm.^2)./(ones(n,1)*(z.^2)))),2);
    deltaz=-sum(P.*((d*ones(1,m)).*(((X.^2)-X.*(ones(n,1)*z))./(ones(n,1)*(z.^3)))-(1./(ones(n,1)*z))),1);
end

end

