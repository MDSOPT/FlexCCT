function [f] = CCCTWFMin0(x,X,P,EstMethod)
%fa2Min - Provides the function value for continuous cultural consensus
%Inputs
%x - The current value of the function parameters (F, but gone with Matlab
%notation) of length 2n*m*1
%X - The input matrix of questionnaire answers 
%P - An indicator matrix of
%EstMethod - See header for ContinuousCCT2
%These consist of
%  d - n*1 vector of competencies
%  z - a m*1 vector of answers
%  b - a n*1 vector of additional parameters
%  If Estimation method is 2 then these parameters are ones, if 3 then a 
%  scaling parameter, and if 4 then a bias parameter
%R - The source matrix
%Outputs
%f - The function value for x
%Version     Author            Date
%   0.10     Stephen France    04/01/2012

%Start by collapsing x (z is a row vector so transform)
[n,m]=size(X);
sd=x(1:n);
z=x(n+1:n+m)';

%Set a maximum value of D (and for EstMethod 5 the easiness
if exist('DMax','var')
  BigM=1e6;
else
  DMax=-1;
end

switch EstMethod
  case {3,4}
    b=x(n+m+1:2*n+m);
  case {5}
    %The easiness parameter
    beta=x(n+m+1:2*m+n)';
end

% a=sum(isnan(x),1);
% if a>0
%   test=1
% end

%Set the least squares term for 2
%Term 2 depends on the scaling constant used
switch EstMethod
  case {2,5}
    SquareTerm=(X-ones(n,1)*z).^2;
  case 3
    SquareTerm=(X-b*z).^2;
  case 4
    SquareTerm=(X-(b*ones(1,m))-ones(n,1)*z).^2;
  case 5
    
end

%Term 1 uses the standard item competency for all terms
switch EstMethod
  case {2,3,4}
    Term1=(d*ones(1,m))./(2*pi);
    Term2=(d*ones(1,m)).*SquareTerm./2;
  case {5}
end
Term1=log(Term1.^0.5);

Total=(Term1-Term2).*P;
f=-sum(sum(Total));

end

