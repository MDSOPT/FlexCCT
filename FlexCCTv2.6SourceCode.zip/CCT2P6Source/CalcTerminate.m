function [Terminate] = CalcTerminate(Blocks,AllSplits,TotalSSq,WeightParam)
%Calculates the termination criterion from Hartigan (1972) using same
%notation
%Inputs
%Blocks - A set of block structures, as defined in BlockCluster.m.
%AllSplits - Possible splits across all blocks.  eeach row is
%[Block,IsRow (1 if row, 0 if col),Index (row or col),IsFixed (1 if fixed, 0 if free),RSS
%TotalSSQ - The current within block sum of squares
%WeightParam - The weight parameter for the termination criterion
%Outputs
%Terminate - 1 to terminate the algorithm
%          - 0 to not terminate the algorithm
%Entries minus blocks
%Version     Author            Date
%   0.10     Stephen France    04/05/2012

N3=(Blocks.RowCount{1}.*Blocks.RowCount{1})-Blocks.ActiveCount;
LHS=TotalSSq./N3;

N1=0;N2=0;RSS1=0;RSS2=0;
SplitCount=size(AllSplits,1);
for i=1:SplitCount;
  SplitItem=AllSplits(i,:);
  if (SplitItem(4)==1)
    %Add totals for fixed splits
    N2=N2+1;
    RSS2=RSS2+SplitItem(5);
  else
    %Add totals for free splits
    N1=N1+1;
    RSS1=RSS1+SplitItem(5);
  end
end
RHS=((0.5.*RSS1)+RSS2)./((N1./WeightParam)+N2);

Terminate=(LHS>RHS);

