function [VMatrix,LeanMissPC,FatMissPC,RowClusters,ColClusters] = VisBlockCluster(X,NRowClus,NColClus)
%Creates a CONCUR visualization of binary instance data.  The user supplies
%the number of row clusters and the number of column clusters.  The
%procedure calls the block cluster routine and visualizes the resulting clusters.
%INPUTS
%X - An n*m input matrix
%NRowClus - The number of row clusters
%NColClus - The number of column clusters
%OUTPUTS
%VMatrix - A visualization of the matrix. First row contains column
%indexes, first column contains row indexes.  Inner matrix shows the reordered
%data
%LeanMissPC - The percentage of 1s in clusters where less than 50% of the values
%are 1
%FatMissPC - The number of 0s in clusters where more than 50% of the values
%are 1
%Version 0.10 - Stephen France 05/26/2012

[n,m]=size(X);

LeanMiss=0;FatMiss=0;LeanMax=0;FatMax=0;
%Call block clustering algorithm for both rows and columns (missing value is optional
[gRowIndexes1,gColIndexes1,MBlock1,MBlock2,RowClusters,PseudoF] = BlockCluster(X,NRowClus,0,0,1,1,3);
[gRowIndexes2,gColIndexes2,MBlock1,MBlock2,ColClusters,PseudoF] = BlockCluster(X,NColClus,0,0,2,1,3);
                                                                                                        
%Start by giving cluster numbers
RowHeaders=[];
ActiveNo=0;
for i=1:RowClusters.Count
  if (RowClusters.Active{i}==1)
    ActiveNo=ActiveNo+1;
    %Header has two cols, 1 is cluster no, 2 is row number
    AddHeader=[ones(RowClusters.RowCount{i},1).*ActiveNo,gRowIndexes1(RowClusters.mRowIndexes{i})];
    RowHeaders=[RowHeaders;AddHeader];
  end
end

ColHeaders=[];
ActiveNo=0;   %Only display active (root) clusters
for i=1:ColClusters.Count
  if (ColClusters.Active{i}==1)
    ActiveNo=ActiveNo+1;
    %Header has two rows, 1 is cluster no, 2 is col number
    AddHeader=[ones(1,ColClusters.ColCount{i}).*ActiveNo;gColIndexes2(ColClusters.mColIndexes{i})];
    ColHeaders=[ColHeaders,AddHeader];
  end
end

%Calculate the lean and fat fit statistics
for iRowClus=1:RowClusters.Count
  if (RowClusters.Active{iRowClus}==1)
    for jColClus=1:ColClusters.Count
      if (RowClusters.Active{jColClus}==1)
        Temp=X(gRowIndexes1(RowClusters.mRowIndexes{iRowClus}),gColIndexes2(ColClusters.mColIndexes{jColClus}));
        %Check for deviation from lean or from fat fit
        SumVar=sum(sum(Temp));
        MaxSumVar=RowClusters.RowCount{iRowClus}*ColClusters.ColCount{jColClus};
        if SumVar<=(MaxSumVar/2);
          LeanMiss=LeanMiss+SumVar;
          LeanMax=LeanMax+MaxSumVar;
        else
          FatMiss=FatMiss+(MaxSumVar-SumVar);
          FatMax=FatMax+MaxSumVar;
        end
      end
    end
  end
end

TopLeft=zeros(2,2);
MainMatrix=X(gRowIndexes1,gColIndexes2);
LeanMissPC=LeanMiss./LeanMax;
FatMissPC=FatMiss./FatMax;

VMatrix=[[TopLeft,ColHeaders];[RowHeaders,MainMatrix]];






