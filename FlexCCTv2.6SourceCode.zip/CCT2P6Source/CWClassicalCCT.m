function [Clusters,AvgVAF,C,ZAll,D] = CWClassicalCCT(X,NoClusters,MinItems,InMethod,OptMethod,DPenalty,FactorOptMethod,OptLevel,IsMissing,MissingVal,CovProb,OptParameters)
%Clusterwise cultural consensus theory.  Follows Batchelder and Romney
%(1989), but assumes multiple cultures.  Starts with an initial clustering
%solution, then uses gradient descent to maximize the total fit (as
%measured by one factor fit in the factor analysis.
%The classical implementation of Cultural Consensus Theory as described
%in Batchelder and Romney (1988)
%Inputs 
%X - An n*m subject*item matrix
%NoClusters - The number of consensus clusters
%MinItems - The minimum number of items in a single cluster
%InMethod  - 0 perform factor analysis on covariance matrix
%          - 1 perform factor analysis on matching matrix
%OptMethod - 0 Utilize a steepest descent algorithm
%          - 1 Utilize a genetic algorithm
%          - 2 Utilize a Tabu Search
%IsMissing - 1 if missing values are present, 0 otherwise
%MissingVal   - The identifier for missing data (should be outside range of actual values) 
%CovProb - If the covariance matrix is utilized then estimate the
%          probablity of Z* (defaults to 0.5).  Use 0 if matching.
%OptParameters - A set of optimization parameters.
%Outputs
%Clusters - For each cluster give the following:
%-------------------------------------------------------------------------
%Z - An m*1 answer key vector
%D - An n*1 vector of competencies from initial estimation
%D2 - An n*1 vector of competencies after replacing diagonal with (D^2) and
%performing PCA.
%Resid - A set of residuals after initial estimation
%Resid2 - A set of residuals after performing the PCA
%VAF - Variance accounted for by initial estimation
%VAF2 - Variance accounted for after calculating PCA
%-------------------------------------------------------------------------
%AvgVAF -  Average VAF across all clusters
%AvgVAf2 - Average VAF2 across all clusters
%Version     Author            Date
%   0.10     Stephen France    05/02/2012

 [n,m]=size(X);
 
 if MinItems>round((n./NoClusters)+1);
  'Value of minimum items is too high.  Please reduce' 
   return
 end

 %Calculate initial matching and covariance from  Batchelder and Romney (1988)
 if (IsMissing==0)
   [CV,MT] = InitialEst(X); 
 else
   [CV,MT] = InitialEstMissing(X,MissingVal); 
 end
 
 if InMethod==0
   if ~exist('CovProb','var')
     CovProb=0.5;
   end
   UserMatrix=CV./(CovProb.^2);  %Assume prob = 0.5, so D(i)D(j)=C(ij)/4
 elseif InMethod==1
   UserMatrix=2*MT-1;   
 end
[n,m]=size(X);

%Find an initial k-means clustering solution
IDX = kmeans(X,NoClusters);

Clusters.NoClusters=NoClusters;
Clusters.UserCount=n;
Clusters.QCount=m;
Clusters.UserMatrix=UserMatrix;  %The whole Usermatrix

for i=1:NoClusters
  %Split into clusters
  Clusters.Indexes{i}=find(IDX==i)';
  Clusters.Count{i}=size(Clusters.Indexes{i},2);
  Clusters.UMatrix{i}=UserMatrix(Clusters.Indexes{i},Clusters.Indexes{i});
  switch FactorOptMethod
   case 0
    [D,Resid]= PrincipalAxesFA(Clusters.UMatrix{i},1e-5,1);
   case 1
    [D,Resid] = ResidualFA(Clusters.UMatrix{i},1,1e-5);
   case 2
    if ~exist('OptLevel','var')
      OptLevel=0; %Default to non-gradient optimization
    end   
   [D,Resid] = ResidualFA2(Clusters.UMatrix{i},1,OptLevel,1e-5);
 end
  Clusters.D{i}=D; 
  Clusters.Resid{i}=Resid;
  Clusters.Mean{i}=mean(mean(Clusters.UMatrix{i}));
  Clusters.VAF{i}=1-(ssq(Resid)./ssq(Clusters.UMatrix{i}-Clusters.Mean{i}));
end

%Now optimize the clusters
if (OptMethod==1)
  [Clusters,BestVAF]=CWCCTGenetic (Clusters,DPenalty,OptParameters,FactorOptMethod,OptLevel);
else
  %Currently only implementing genetic algorithm!  Select OptMethod<>1
  %for the k-means solution
end

%Now do the stage 2 optimization on each of the clusters
SumVAF2=0;
%Setup aggregate values
C=zeros(n,NoClusters);
ZAll=zeros(NoClusters,m);
D=zeros(n,1);
g=zeros(n,1);

for i=1:NoClusters
  DiagMatrix=Clusters.UMatrix{i}-diag(diag(Clusters.UMatrix{i}))+diag(Clusters.D{i}.^2);
  %Run Eigenvector decomposition
  [UAll,EAll] = eig(DiagMatrix);
  %Matlab doesn't guarantee order of eigenvalues
  EDiag=diag(EAll);
  [B,IX]=sort(EDiag,'descend');
  U=UAll(:,IX(1));
  if sum(U)<=0
    U=-U;
  end
  E=EAll(IX(1),IX(1));
  Clusters.D2{i}=U*(E.^0.5);
  %Compute the residuals UserMatrix-E(1)*D(2)D(2)'
  Clusters.Resid2{i}=Clusters.UMatrix{i}-(Clusters.D2{i}(:,1)*Clusters.D2{i}(:,1)');
 
  %Calculate VAF
  Clusters.VAF2{i}=1-(ssq(Clusters.Resid2{i})./ssq(Clusters.UMatrix{i}-Clusters.Mean{i}));
  SumVAF2=SumVAF2+Clusters.VAF2{i}.*Clusters.Count{i};
  %Now use formula from Batchelder and Romney (1986) to 
  G=(2.*X(Clusters.Indexes{i},:)-1);
  %Multiply across logs
  G=G.*(log((1+Clusters.D2{i})./(1-Clusters.D2{i}))*ones(1,m));
 
  Clusters.Z{i}=sum(G,1)>=0;
  %Calculate aggregate values for cluster
  ZAll(i,:)=Clusters.Z{i}';
  C(Clusters.Indexes{i},i)=1;
  D(Clusters.Indexes{i})=Clusters.D2{i};
  

end
AvgVAF=BestVAF;

