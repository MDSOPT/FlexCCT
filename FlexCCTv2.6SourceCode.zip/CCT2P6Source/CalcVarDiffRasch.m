function [IDD,IDDiff,SEIDD,SEIDDiff,Resid] = CalcVarDiffRasch(X,Z,EdgeCorrect,Prior)
%An implementation of the basic Rasch model. The notation of Wright (1977)
%has been used tto implement the algorithm described by Cohen (1976).  If items or subjects
%with no heterogeneity are present (e.g. all 1 or o) then i) the 
%items can be ignored as per the original algorithm or ii) edge correction
%with a set prior can be performed.
%Inputs
%X            - An n*m subject*item matrix
%Z            - An 1*m  answer key vector
%EdgeCorrect  - The number of columns to edge correct
%Prior        - The prior (probability of positive answer) used for edge
%               correction.  Recommended to use even number of columns to
%               give integer row/column sums
%Outputs
%IDD          - An n*1 vector of competencies/abilities
%IDDiff       - A 1*m vector of item difficulties
%SEIDD        - An n*1 standard error vector for the competencies
%SEIDDiff     - A 1*m standard error vector for the item difficulties
%Resid        - An n*m matrix of residuals, with -exp((D-Diff)/2) for wrong
%             - answer and exp(-(D-Diff)/2) for a correct answer.
%Version     Author            Date
%   0.10     Stephen France    05/18/2012
  
  [n,m]=size(X);
  
  %Calculate the correct answer
  Correct=(X==(ones(n,1)*Z));

  if (EdgeCorrect>0)
    %Add two extra questions and extra subjects with probability 0.5.
    Z=[Z,Prior,Prior];
    Correct=[Correct,ones(n,EdgeCorrect).*Prior;ones(EdgeCorrect,m+EdgeCorrect).*Prior];
    m=m+EdgeCorrect;
    n=n+EdgeCorrect;
  end
  
  QScore=round(sum(Correct,1));
  SScore=round(sum(Correct,2));
  
  %Calculate the number correct and remove subjects and items with 100%
  %correct.  This is an iterative process (e.g. removing an item can
  %trigger a boundary condition for another subject or vice-versa.
  QIX=find(ones(1,m)==1);NQIX=[];
  SIX=find(ones(n,1)==1);NSIX=[];
  n2=n;m2=m;
  Oldn2=-1;Oldm2=-1;
  QScore2=QScore;SScore2=SScore;
  Terminate=false;
  while ~((Oldn2==n2)&(Oldm2==m2))
    TempQIX=find(QScore2>0&QScore2<n2);
    TempNQIX=find(QScore2==0|QScore2==n2);
    TempSIX=find(SScore2>0&SScore2<m2);
    TempNSIX=find(SScore2==0|SScore2==m2);
    %Update values
    NQIX=sort([NQIX,QIX(TempNQIX)],'ascend');
    QIX=QIX(TempQIX);
    NSIX=sort([NSIX,SIX(TempNSIX)],'ascend');
    SIX=SIX(TempSIX);
    Oldn2=n2;Oldm2=m2;
    n2=size(SIX,1);  m2=size(QIX,2);
    Correct2=Correct(SIX,QIX);
    QScore2=round(sum(Correct2,1));
    SScore2=round(sum(Correct2,2));
  end
  
  %If no questions or subjects remaining then cannot calculate the Rasch
  %model
  if isempty(QIX)||isempty(SIX) 
    Out='No indexes with heterogeneous answers. Cannot calculate Rasch model'
    QIX
    SIX
    return;  
  end
  
  %Calculate binary matrix of the number of correct answers
  %n(r) to give an n*r (where r is m-1) binary matrix
  Temp=ones(n2,1)*find(ones(1,m2-1)==1);
  Indicator=Temp==(SScore2*ones(1,m2-1));
  NR=sum(Indicator,1);
  
  %x is the log ratio of wrong to right answers
  x=log((n2-QScore2)./(QScore2));
  %Mean and variance stats for items
  Meanx=sum(x)./m2;
  Varx=sum((x-Meanx).^2)./(m2-1);
  %log ratio of right to wrong answers
  RItems=find(ones(1,m2-1)==1);
  y=log(RItems./(m2-RItems));
  
  %Calculate mean and variance for y
  Meany=sum(NR.*y)./n2;
  Vary=sum(NR.*((y-Meany).^2))./(n2-1);
  
  %Calculate the expansion factors
  fX=((1+(Varx./2.89))./(1+(Varx.*Vary./8.35)));
  fY=((1+(Vary./2.89))./(1+(Varx.*Vary./8.35)));
  
  %Difficulty estimates for questions
  TempDiff=fY*(x-Meanx);
  TempSEDiff=fY*(((n2./QScore2).*(n2-QScore2)).^0.5);
  %Competence estimates for score values
  b=fX*y;
  SEb=fX*(((m2./RItems).*(m2-RItems)).^2);
  
  %Populate item difficulties.  Give NaN where there is not enough
  %information to estimate the model (e.g. every or no subject gets
  %correct)
  IDDiff=zeros(1,m);SEIDDiff=zeros(1,m);
  IDDiff(QIX)=TempDiff;
  SEIDDiff(QIX)=TempSEDiff;
  IDDiff(NQIX)=NaN;SEIDDiff(NQIX)=NaN;
  
  %Populate the actual questions from the score competancy values (by
  %score)
  IDD=zeros(n,1);SEIDD=zeros(n,1);
  IDD(SIX)=b(SScore2);
  SEIDD(SIX)=SEb(SScore2);
  IDD(NSIX)=NaN;SEIDD(NSIX)=NaN;
  
  %Now calculate the residuals from the Rasch model
  Exponent=((IDD*ones(1,m))-(ones(n,1)*IDDiff))./2;
  %If correct then overall sign +ve and -ve exponent
  %If wrong then overall sign -ve and +ve exponent
  Resid=Correct.*exp(-Exponent)-(1-Correct).*exp(Exponent);
  
  if (EdgeCorrect>0)
    n=n-EdgeCorrect;
    m=m-EdgeCorrect;
    IDDiff=IDDiff(1:m);
    SEIDDiff=SEIDDiff(1:m);
    IDD=IDD(1:n);
    SEIDD=SEIDD(1:n);
    Resid=Resid(1:n,1:m);
  end
  
end

