

%Firstly split into 2
X1=[ones(8,4),zeros(8,4)];

%Split into 4
X2=[ones(4,4),ones(4,4).*2;ones(4,4).*3,ones(4,4).*4];

%Equal column sums on opposite sides
X3=[ones(4,4),ones(4,4).*3;ones(4,4).*4,ones(4,4).*2];

%Rows in order (same column sums, so check reorder
X4=[ones(4,4),ones(4,4).*2;ones(4,4).*3,ones(4,4).*4];

%8 rows 1 to 8
X5=[1;2;3;4;5;6;7;8]*ones(1,8);

%8 columns 1 to 8
X6=ones(8,1)*[1,2,3,4,5,6,7,8];

%Check negative
X7=[ones(2,8).*-0.1;zeros(4,8);ones(2,8).*0.1;];
X8=X7';

%Check diagonal elements
X9=zeros(8);
for i=1:8
 for j=1:8
   X9(i,j)=mod(i+j,2);
 end
end

%Magic!
X10=magic(8);

%Check row and column permutations of all previous variables
X11=X1(randperm(8),randperm(8));
X12=X1(randperm(8),randperm(8));
X13=X1(randperm(8),randperm(8));
X14=X1(randperm(8),randperm(8));
X15=X1(randperm(8),randperm(8));
X16=X1(randperm(8),randperm(8));
X17=X1(randperm(8),randperm(8));
X18=X1(randperm(8),randperm(8));
X19=X1(randperm(8),randperm(8));
X20=X1(randperm(8),randperm(8));



