% Create a scree plot of inter-rater correlations for the current 
%Version     Author            Date
%   2.00     Stephen France    04/01/2016
function varargout = Scree(varargin)
% SCREE MATLAB code for Scree.fig
%      SCREE, by itself, creates a new SCREE or raises the existing
%      singleton*.
%
%      H = SCREE returns the handle to a new SCREE or the handle to
%      the existing singleton*.
%
%      SCREE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SCREE.M with the given input arguments.
%
%      SCREE('Property','Value',...) creates a new SCREE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Scree_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Scree_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Scree

% Last Modified by GUIDE v2.5 28-Sep-2015 16:07:51

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Scree_OpeningFcn, ...
                   'gui_OutputFcn',  @Scree_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Scree is made visible.
function Scree_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Scree (see VARARGIN)

% Choose default command line output for Scree
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

javaFrame = get(handle(hObject),'JavaFrame');
javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));

%Get data Here
EigOut=getappdata(0,'EigOut');
NoEig=getappdata(0,'NoEig');

set(hObject,'CurrentAxes',handles.axeScree)

%Now plot the eigenvectors
plot(EigOut(1:length(EigOut)-1));
xlabel('Eigenvalue Number') % x-axis label
ylabel('Eigenvalue') % y-axis label

%Plot the values of the criterion
NoEig2=NoEig;
for i=2:NoEig-1
  if EigOut(i)<1
    NoEig2=i-1;
    break;
  end
end
set(handles.txtEigenValue,'string',num2str(NoEig2));

NoEig2=NoEig-1;
for i=2:NoEig
  if (EigOut(i-1)-EigOut(i))<1
    NoEig2=i-2;
    break;
  end
end
set(handles.txtConvexHull,'string',num2str(NoEig2));

% --- Outputs from this function are returned to the command line.
function varargout = Scree_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function txtEigenValue_Callback(hObject, eventdata, handles)
% hObject    handle to txtEigenValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtEigenValue as text
%        str2double(get(hObject,'String')) returns contents of txtEigenValue as a double


% --- Executes during object creation, after setting all properties.
function txtEigenValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtEigenValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtConvexHull_Callback(hObject, eventdata, handles)
% hObject    handle to txtConvexHull (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtConvexHull as text
%        str2double(get(hObject,'String')) returns contents of txtConvexHull as a double


% --- Executes during object creation, after setting all properties.
function txtConvexHull_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtConvexHull (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cmdSave.
function cmdSave_Callback(hObject, eventdata, handles)
% hObject    handle to cmdSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%get the filepath to save the file

%Save the actual eigenvalue variables to a csv dile
try
[FileName,FilePath]=uiputfile({'*.csv'},'Save Eigenvalues');
ExPath = [FilePath FileName];

  if(FileName~=0)
    %save the file in CSV format
    %load data in variables
    EigOut=getappdata(0,'EigOut');
    NoEig=getappdata(0,'NoEig');
    EigOut = [[1:NoEig]',EigOut];
    fid = fopen(ExPath, 'w');
    fprintf(fid,'EigNo,EigValue\n');
    fclose(fid);
    dlmwrite(ExPath, EigOut, '-append', 'precision', '%.6f');
  end
catch err
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h);
end

% --- Executes on button press in cmdExit.
function cmdExit_Callback(hObject, eventdata, handles)
% hObject    handle to cmdExit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = MFquestdlg([0.3,0.5],'Are you sure that you would like to close the scree plot pane?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes',
delete(gcf);
case 'No'
return
end %switch

% --- Executes when user attempts to close Scree.
function Scree_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to Scree (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
selection = MFquestdlg([0.3,0.5],'Are you sure that you would like to close the scree plot pane?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes',
delete(hObject);
case 'No'
return
end %switch
