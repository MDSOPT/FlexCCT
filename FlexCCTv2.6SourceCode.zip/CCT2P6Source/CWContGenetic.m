function [BestClusters,fBest,Fail]=CWContGenetic (InitialClusters,OptParameters,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior)
%A genetic algorithm for optimizing the continuous cultural consensus
%model .  Takes a set of clusters and then optimizes 
%these clusters to maximize the total maximum likelihood function.
%Inputs
%InitialClusters - See header for CWCContinuousCCT.m for description
%OptParameters - Vector of length 5 of Optimization parameters
%1 Minimum number of items in a cluster, 2 STemp, 3 ETemp, 4 CTemp, 5
%EstMethod  - The estimation method for continuous clusterwise cultural
%consensus theory. See CWContinuousCCT.m header.
%Coverge   - The converge value (difference between successive f values)
%            for the continuous estimation
%MaxIter   - The maximum number of iterations for the continuous estimation
%MissingVal - The identifier for missing data (should be outside range of
%actual values) 
%DMax        - The maximum value of D
%DPrior      - Prior guess for value D
%AddParams - Additional parameters (see ContinuousCCT header)
%Outputs
%BestClusters - See header for CWClassicalCCT.m for description.
%fBest - The optimial value of the likelihood function
%-------------------------------------------------------------------------
%Version     Author            Date
%   0.10     Stephen France    08/07/2012

  Debug=[];
  Debug=[];
%   Detailed explanation goes here
  MinItems=OptParameters(1);
  STemp=OptParameters(2);
  ETemp=OptParameters(3);
  CTemp=OptParameters(4);
  TermIt=OptParameters(5);
  
  %Shorthand for the initial clusters
  k=InitialClusters.NoClusters;

  CurTemp=STemp;

  %Calculate initial f
  fOld=-1e19;
  [Clusters,f,fBest]=UpdateMaxCriterion(InitialClusters,fOld,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior); 
  
  NoChangeIt=0;
  
  while (NoChangeIt<TermIt) || (CurTemp>ETemp)
    FoundIndex=false;
    while (FoundIndex==false)
      ChangeIndex=floor(rand()*Clusters.QCount)+1;
      for i=1:Clusters.NoClusters
        if find(Clusters.Indexes{i}==ChangeIndex)>0
          %Ensure that the test cluster has more than the minimum
          if Clusters.Count{i}>MinItems
            Ri=i;
            FoundIndex=true;
            break;
          end
        end
      end
    end
    %Create the new test clusters
    TClusters=Clusters;
    %Firstly update the old cluster indexes
    RemoveIndex=find(TClusters.Indexes{Ri}==ChangeIndex);
    switch RemoveIndex
      case 1
        TClusters.Indexes{Ri}=TClusters.Indexes{Ri}(2:TClusters.Count{Ri});
      case TClusters.Count{Ri}
        TClusters.Indexes{Ri}=TClusters.Indexes{Ri}(1:TClusters.Count{Ri}-1);
      otherwise
        TClusters.Indexes{Ri}=[TClusters.Indexes{Ri}(1:RemoveIndex-1),TClusters.Indexes{Ri}(RemoveIndex+1:TClusters.Count{Ri})];
    end
    TClusters.Count{Ri}=TClusters.Count{Ri}-1;
    TClusters.SX{Ri}=TClusters.X(TClusters.Indexes{Ri},:);
    %Add to one of the other clusters randomly
    AddCluster=1+floor(rand()*(k-1));
    if AddCluster>=Ri
      AddCluster=AddCluster+1;
    end
    TClusters.Indexes{AddCluster}=sort([TClusters.Indexes{AddCluster},ChangeIndex]);
    TClusters.Count{AddCluster}=TClusters.Count{AddCluster}+1;
    TClusters.SX{AddCluster}=TClusters.X(TClusters.Indexes{AddCluster},:);
    [TClusters,fNew,fBest]=UpdateMaxCriterion(TClusters,fBest,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior); 

    %Convert to a minimization problem
    fChange=f-fNew;
    
    if fChange<0
      Accept=true;
    else
      PAccept=exp(-fChange/CurTemp);
      %Implement the simulated annealing
      if rand<PAccept
        Accept=true;
      else
        Accept=false;
      end
    end
  
    if (Accept==true)
      fOld=f;
      f=fNew;
      Clusters=TClusters;
      NoChangeIt=0;
    else
      NoChangeIt=NoChangeIt+1;
    end
    CurTemp=max(ETemp,CurTemp-CTemp);
    
    DebugLine=[f,fBest]
    for temp=1:k
      DebugLine=[DebugLine,Clusters.Count{temp}];
    end
    Debug=[Debug;DebugLine];
    
  end
  
  %Return the best value (stored in NoClusters+1 to 2*NoClusters)
  BestClusters.X=Clusters.X;
  BestClusters.NoClusters=Clusters.NoClusters;
  for i=1:Clusters.NoClusters
    BestClusters.Indexes{i}=Clusters.Indexes{Clusters.NoClusters+i};
    BestClusters.Count{i}=Clusters.Count{Clusters.NoClusters+i};
    BestClusters.SX{i}=Clusters.SX{Clusters.NoClusters+i};
    BestClusters.D{i}=Clusters.D{Clusters.NoClusters+i}; 
    BestClusters.z{i}=Clusters.z{Clusters.NoClusters+i};
    BestClusters.Bias{i}=Clusters.Bias{Clusters.NoClusters+i};
    BestClusters.QE{i}=Clusters.QE{Clusters.NoClusters+i};
    BestClusters.MaxCrit{i}=Clusters.MaxCrit{Clusters.NoClusters+i};
  end
  
  [BestClusters,f,fBest,Fail]=UpdateMaxCriterion(BestClusters,fOld,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior); 

end

