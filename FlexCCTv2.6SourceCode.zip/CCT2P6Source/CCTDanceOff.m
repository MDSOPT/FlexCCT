
MinScale=0.5;
IsRun=false;
OverallRun=0;

%The vectors to be output for calculating the result's from the CCT pack
%software.
Allz=[];AllD=[];AllBias=[];

for NoItems=50:50            %200:200:1000
  for NoUsers=50:50          %200:200:1000
    for Scale=5:5:10
      Range=Scale-1;
      Centre=1+(Range/2);
      for TrueDist=1:2
        for MissingPC=0:25:25
          for Scheme=1:5
            for DMax=5:5
              %0 is for my algorithm where bias is added before error
              %1 is for BCCT, where bias is added after error
              for BiasOrder=0:1
                Round = 0; %Temporarliy - do not round the model variables
                %First randomly select true review scores
                if TrueDist==1
                  %Sample from normal distribution with mean at the center
                  %point and with 1 standard devation = 1/6 range
                  z = norminv(rand(1,NoItems),Centre,Range/6);
                else
                  %Sample from uniform distribution
                  z=(rand(1,NoItems).*Range)+1;
                end
                %Determine latent competencies for users
                Mind=(Range/3)^(-2);
                Midd=(Range/6)^(-2);
                Maxd=(Range/9)^(-2);
                switch Scheme
                case 1
                  %Select all users to have the average competancy
                  D=ones(NoUsers,1).*Midd;
                case 2
                  %Random competencies between min and max
                  D=Mind+rand(NoUsers,1).*(Maxd-Mind);
                case 3
                  %75% competent and 25% not competent
                  IsComp=rand(NoUsers,1)>0.25;
                case 4
                  %50% competent and 50% not competent
                  IsComp=rand(NoUsers,1)>0.5;
                case 5 
                  %25% competent and 75% not competent
                  IsComp=rand(NoUsers,1)>0.75;              
                end
                switch Scheme
                  case {3,4,5}
                  %Users competent if one and not competent if 0
                  D=IsComp.*Maxd+(1-IsComp).*Mind;
                end

                for AddBias=0:1
                  for MultBias=0:1
                    if AddBias==0
                      Bias=zeros(NoUsers,1);
                    else
                      Bias=norminv(rand(NoUsers,1),0,Range/10);
                    end 
                    if MultBias==0
                      Bias=[Bias,ones(NoUsers,1)];
                    else
                      Bias=[Bias,norminv(rand(NoUsers,1),1,0.1)];
                    end
                    %Now sample an answer key given the competency and the true
                    %score
                    %Sample an error matrix based on competencies
                    Error=zeros(NoUsers,NoItems);
                    for i=1:NoUsers
                      P=rand(1,NoItems);
                      Error(i,:) = norminv(P,0,(D(i)^(-0.5)));
                    end
                    %Add the error to the actual values of the items
                    if BiasOrder==0
                      X=Bias(:,2)*z+Bias(:,1)*ones(1,NoItems)+Error;
                    else
                      X=Bias(:,2)*ones(1,NoItems).*(ones(NoUsers,1)*z+Error)+Bias(:,1)*ones(1,NoItems);
                    end
                    if Round==1
                      X=round(X);
                      X=min(max(1,X),Scale);   %Ensure in bounds                     
                    end
                    %Replace any missing data by -1
                    IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                    AllAssigned=isempty(find(sum(1-IsMissing,1)==0))&&isempty(find(sum(1-IsMissing,2)==0));
                    while (AllAssigned==0)
                      IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                      [IsMissing,AllAssigned]=FixMissing(IsMissing,1000);
                    end
                    X=-IsMissing+(1-IsMissing).*X;
                    
                    
                    %Save the file to the output directory
                    OverallRun=OverallRun+1;
                    
               
                      FileName =strcat('C:\CCOut\DO\RCSV\X',num2str(round(OverallRun)),'.csv');
                      csvwrite(FileName,X);
                      if mod(OverallRun,10)==0
                        OverallRun
                      end

                      %for each item we want to save the following
                      %The real values of each parameter, followed by the

                      Allz=[Allz;z];
                      AllD=[AllD,D];
                      AllBias=[AllBias,Bias];

                      Results=[OverallRun,NoItems,NoUsers,Scale,TrueDist,MissingPC,Scheme,DMax,Round,AddBias,MultBias];
                      tic;
                      [zI] = CCTAggregate(X,-1,1);   %straight arithmetic mean
                      t=toc;
                      Results2=[Results,1,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,0,0,0,0,0,0,t];

                      tic;
                      [zI] = CCTAggregate(X,-1,2);   %straight geometric mean
                      t=toc;
                      Results2=[Results2;[Results,2,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,0,0,0,0,0,0,t]];

                      tic;
                      [zI] = CCTAggregate(X,-1,3,1e-6); %combined arithmetic/geometric mean
                      t=toc;
                      Results2=[Results2;[Results,3,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,0,0,0,0,0,0,t]];

                      tic;
                      [zI] = CCTAggregate(X,-1,4);   %The harmonic mean 
                      t=toc;
                      Results2=[Results2;[Results,4,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,0,0,0,0,0,0,t]];

                      tic;
                      [zI] = CCTAggregate(X,-1,5);   %Variance adjusted mean
                      t=toc;
                      Results2=[Results2;[Results,5,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,0,0,0,0,0,0,t]];

                      tic;
                      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT4(X,0,0,[0,0,0,0],[1e-6,1000,1],-1,DMax,DMax);
                      t=toc;
                      Results2=[Results2;[Results,6,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,0,0,0,0,0,0,t]];

                      tic;
                      [zI,DI,BiasI,QEI,MaxCritI,I] = ContinuousCCT4(X,2,0,[0,0,0,0],[1e-6,1000,1],-1,DMax,DMax);
                      t=toc;
                      Results2=[Results2;[Results,7,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,sum((D-DI).^2)./NoItems,sum(abs(D-DI))./NoItems,0,0,0,0,t]];

                      %Now set the results for each identify technique  Let
                      %Identity -1 (full fix) = Technique 8
                      %Identity 0 (no fix) = Technique 9
                      %Identity 1 (partial fix) = Technique 10

                      for Identify=-1:1
                        tic;
                        if AddBias==0&&MultBias==0  
                          [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT4(X,2,0,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
                        elseif AddBias==1&&MultBias==0
                          [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT4(X,2,1,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
                        elseif AddBias==0&&MultBias==1
                          [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT4(X,2,2,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
                        else
                          [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT4(X,2,3,[Identify,Identify,Identify,0],[1e-6,1000,1],-1,DMax,DMax);
                        end
                        t=toc;
                        Results2=[Results2;[Results,9+Identify,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,sum((D-DI).^2)./NoItems, ...
                          sum(abs(D-DI))./NoItems,sum((Bias(:,1)-BiasI(:,1)).^2)./NoItems,sum(abs(Bias(:,1)-BiasI(:,1)))./NoItems,...
                          sum((Bias(:,2)-BiasI(:,2)).^2)./NoItems,sum(abs(Bias(:,2)-BiasI(:,2)))./NoItems,t]];
                      end 

                      %Now utilize the gradient descent CCT algorithm
                      tic;
                      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,0,0,[0,0,0,0],[1e-6,1000,1],-1,1,DMax,DMax);
                      t=toc;
                      Results2=[Results2;[Results,11,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,0,0,0,0,0,0,t]];

                      tic;
                      [zI,DI,BiasI,QEI,MaxCritI,I] = ContinuousCCT3(X,2,0,[0,0,0,0],[1e-6,1000,1],-1,1,DMax,DMax);
                      t=toc;
                      Results2=[Results2;[Results,12,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,sum((D-DI).^2)./NoItems,sum(abs(D-DI))./NoItems,0,0,0,0,t]];

                      for Identify=-1:1
                        tic;
                        if AddBias==0&&MultBias==0  
                          [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,0,[Identify,Identify,0,0],[1e-6,1000,1],-1,1,DMax,DMax);
                        elseif AddBias==1&&MultBias==0
                          [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,1,[Identify,Identify,0,0],[1e-6,1000,1],-1,1,DMax,DMax);
                        elseif AddBias==0&&MultBias==1
                          [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,2,[Identify,Identify,0,0],[1e-6,1000,1],-1,1,DMax,DMax);
                        else
                          [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,3,[Identify,Identify,Identify,0],[1e-6,1000,1],-1,1,DMax,DMax);
                        end
                        t=toc;
                        Results2=[Results2;[Results,14+Identify,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,sum((D-DI).^2)./NoItems, ...
                          sum(abs(D-DI))./NoItems,sum((Bias(:,1)-BiasI(:,1)).^2)./NoItems,sum(abs(Bias(:,1)-BiasI(:,1)))./NoItems,...
                          sum((Bias(:,2)-BiasI(:,2)).^2)./NoItems,sum(abs(Bias(:,2)-BiasI(:,2)))./NoItems,t]];               
                      end 
                      save 'C:\CCOut\DO\MLDanceOff.txt' Results2 -append -ascii; 
                  end
                end
              end
            end
          end
        end
      end
    end
  end
end

%Save the base vectors
save 'C:\CCOut\DO\Base\Allz.txt' Allz -ascii;
save 'C:\CCOut\DO\Base\AllD.txt' AllD -ascii;
save 'C:\CCOut\DO\Base\AllBias.txt' AllBias -ascii;
