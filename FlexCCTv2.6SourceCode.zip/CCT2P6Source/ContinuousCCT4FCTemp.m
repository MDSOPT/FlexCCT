function [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT4FC(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,FuzzyU,Fuzzyq,DPrior)
%An implementation of continuous Cultural Consensus Theory as described
%in Batchelder and Romney (1988) and France and Batchelder (2013).  In this
%version, the parameters are fit incrementally using a fixed point
%optimization technique. The 4U extension has a scaling factor from fuzzy
%clustering U and a fuzzy parameter p.
%Inputs
%X - An n*m subject*item input matrix
%EstMethod - The estimation method
%          - 0 Average value
%          - 1 Min Res factor analysis
%          - 2 Maximum likelihood estimation
%          - 3 Item difficulty model no 1 Additive Variances
%          - 4 Item difficulty model no 2 dij=alpha(i)*beta(j)
%          - 5 Item difficulty model no 3 dij=alpha(i)+beta(j)   
%          - 6 The Weber-Fechner model, where variance = zk^2/(d^p)
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          Currently bias 1 and 2 are only available for estimation methods
%          3,4, and 6
%FixParams - Fix parameters. A one by four array of items that contains
%          the following information.
%Fixz      - 0 Don't fix z at all
%          - -1 Fix z if an initial optimization run using EstMethod=2
%          - 1 Partial fix of z.  Fix for the average value
%FixD      - 0 Don't fix D at all
%          - -1 Fix D if an initial optimization run using EstMethod=2
%          - 1 Partial fix of D. Fix for the average value
%FixAddBias- 0 Don't fix the additive bias at all
%          - -1 Fix the additive bias first before calculating the
%          multiplicative bias
%          - 1 Partial fix of the additive bias.  Fix for the average value
%FixMultBias- 0 Don't fix the multiplicative bias at all
%          - -1 Fix the multiplicative bias first before calculating the
%          multiplicative bias
%          - 1 Partial fix of multiplicative bias.  Fix for the average
%          value
%OptParms  - A row vector containing the optimization parameters.  This
%vector consists of the following fields:
%       Coverge - The converge value (difference between successive f
%       values) (default 1e6)
%       MaxIter - The maximum number of iterations for the procedure
%       (default 1000)
%       InitialType - The scheme used for the initial solution
%           - 0 Use the values from the average solution and no initial
%           bias (e.g., bias of 0 for additive, 1 for multiplicative)
%           - 1 Generate initial values from uniform distribution.
%              If 0 then use starting solution.  If 1 then use 
%           - 2 Calculate sample posterior distribution (NOT YET
%           IMPLEMENTED)
%      ReturnPartial - OPTIONAL Default 0: If 1 returns LLPartial, otherwise if 0
%      returns -1
%MissingVal - The indicator for a missing value boundary of max(abs-1)
%OptLevel   - 0 if use only function value
%           - 1 if use first order derivatives
%DMax      - The maximum value of D
%IEMax     - The maximum value of the item easiness IE
%FuzzyU    - An n*l matrix of fuzzy membership parameters 
%Fuzzyq    - A fuzzy clustering scale parameter
%DPrior    - Prior guess for value D
%Outputs (if not included in the model then return all 1s
%z   - A continuous m*1 answer key vector
%D   - An n*1 vector of user competencies
%Bias - The model bias
%    - if EstMethod=3 then = bz - A continuous n*1 scale varible 
%    - If EstMethod=4 then = Diff - A continuous m*1 vector of Rasch item diffs.
%MaxCrit  - A maximization criteria for goodness of fit.
%LLPartial - A (3*m) matrix of partial likelihood values.  The first row
%contains the actual likelihood value, the second the value for the integer
%below the value and the third the value for the integer above the value.

  [n,m]=size(X);
  MaxCrit=0;
  if ~exist('DMax','var')||isempty(DMax)==true
    DMax=inf;
  end
  if ~exist('IEMax','var')||isempty(IEMax)==true
    IEMax=inf;
  end
  
  Fixz=FixParams(1);FixD=FixParams(2);
  FixAddBias=FixParams(3);FixMultBias=FixParams(4);
  
%   %Can only fix z and D if estimation type is in {2,3,4,5,6}.
%   if (EstMethod==0)&&((Fixz~=0)||(FixD~=0))
%     Exception = MException('InputError:BiasFix',...
%          'By definition, z and D cannot be fixed for simple average estimation.');
%     throw(Exception);  
%   end
  
  %Cannot fix both additive bias and multiplicative bias values
  if (FixAddBias~=0)&&(FixMultBias~=0)
    Exception = MException('InputError:BiasFix',...
         'Only one type of bias can be fixed.  Both additive bias and multiplicative bias cannot be fixed together');
    throw(Exception); 
  end
  
  Converge=OptParams(1);
  MaxIter=OptParams(2);
  InitialType=OptParams(3);
  if size(OptParams,2)==4;
    ReturnLLPartial=OptParams(4);
  else
    ReturnLLPartial=0;
  end
 
  P=+~(X==MissingVal);
  
  %If no items for a question or user then add a question based on a
  %pseudo-Bayesian prior
  SumZ=sum(P,1);
  SumZ2=sum(P,2);
  if (~isempty(find(SumZ==0)))||(~isempty(find(SumZ2==0)))
    AddLine=true;
    n=n+1;
    X=[X;SumZ];
    P=[P;ones(1,m)];
  else
    AddLine=false;
  end
 
  if ~exist('OptLevel','var')
    OptLevel=0;
  end
  
  if (EstMethod==1)
    %Minimum residual factor analysis
    [CorrMatrix] = CalcSimilarity(X,P,[1,3]);
    if sum(sum(isnan(CorrMatrix)))>0
      ErrorText='Badly formed correlation matrix'
    else
      %Use correlation to estimate the initial competencies
      [D,Resid] = ResidualFA(CorrMatrix,1,1e-5); 
    end
    QE=ones(1,m);
  else
    if DMax==inf
      DMax=-1;
    end
    if IEMax==inf
      IEMax=-1;
    end
    if InitialType==0
      if exist('DPrior','var')
        D=repmat(DPrior,n,1);
      else
        D=ones(n,1);
      end 
    else
      %Find information on the size of the range
      MinX=X;
      MinX(find(X==MissingVal))=max(max(X));
      MaxX=X;
      MaxX(find(X==MissingVal))=min(min(X));  
      MinVal=min(min(MinX));
      MaxVal=max(max(MaxX));
      %Sample D from 1 to DMax (if not set then assume a maximum of 10)
      switch EstMethod
        case 0
          D=ones(n,1);
        case {2,3,4,5,6}
          if DMax==-1
            RDMax=10;
          else
            RDMax=DMax;
          end
          D=rand(n,1).*RDMax;
      end
    end
  end
  
  %The factor analysis method cannot fit additional parameters, so these
  %parameters are left at their default values.
  if (EstMethod==0)||(EstMethod==1)||(InitialType==0)
    %Set the initial parameters to base values
    QE=ones(1,m);
    Num=sum((((FuzzyU*ones(1,m)).^Fuzzyq).*(D*ones(1,m)).*X.*P),1);
    Denom=sum((((FuzzyU*ones(1,m)).^Fuzzyq).*(D*ones(1,m)).*P),1);
    Denom=max(Denom,1);
    z=Num./Denom;
  else
    %Sample IE from 1 to DMax (if not set then assume a maximum of 10)
    switch EstMethod
      case {2,6}
        QE=ones(1,m);
      case {3,4,5}
        if IEMax==-1
          RIEMax=10;
        else
          RIEMax=IEMax;
        end
      QE=rand(1,m).*RIEMax;
    end
    %Sample z from this range
    z=MinVal+rand(1,m).*(MaxVal-MinVal);
  end
  
  %If estimation method is 0 then the existing z is irrelevant, otherwise
  %if fixing z then create z with the ContinuousCCT 

  if Fixz~=0
    %We create the initial z
    HasExistingz=true;
    if FixD~=0
      if EstMethod==0||EstMethod==1
        zPre=z;DPre=D;
      else
        [zPre,DPre] = ContinuousCCT4(X,2,0,[0,0,0,0],OptParams,MissingVal,DMax,IEMax);
      end
      HasExistingD=true;
      if FixD==1
        %Find the closed value to the median and update Fixed z to be this
        %value
        [V,I]=sort(abs(median(DPre)-DPre));
        FixD=I(1);
        DPre=DPre(FixD);
      end
    else
      if EstMethod==0||EstMethod==1
        zPre=z;
      else
        [zPre] = ContinuousCCT4(X,2,0,[0,0,0,0],OptParams,MissingVal,DMax,IEMax);
      end
      HasExistingD=false;
    end
    %Setup z depending on whether partially or fully fixed
    if Fixz==1
      %Find the closed value to the mean and update Fixed z to be this
      %value
      [V,I]=sort(abs(median(zPre)-zPre));
      Fixz=I(1);
      zPre=zPre(Fixz);
    end
  else
    HasExistingz=false;
    HasExistingD=false;
  end
  
  
  if (EstMethod==1)||(InitialType==0)
     %Set inital values of bias and QE
    BiasAdd=zeros(n,1);
    BiasMult=ones(n,1);   %Row of additive biases and row of multiplicative biases
  else
    %Set random biases, but only if they can be fit.  Biases are random
    %withing range.  The additive bias range is from [-RangeX/2 to +RangeX/2) and
    %the multiplicative bias is from [0.5 to 2]
    switch BiasType
      case {0,2}
        %No additive bias
        BiasAdd=zeros(n,1);
      case {1,3}
        BiasAdd=rand(n,1)*(MaxVal-MinVal)-((MaxVal-MinVal)/2);
    end
    switch BiasType
      case {0,1}
        %No multiplicative bias
        BiasMult=ones(n,1);
      case {2,3}
        %Create an n*2 matrix and have one column containing the random
        %multiplication factor.  The scale assignments determine whether
        %this factor is or is not a recipricol.
        ScaleMatrix=ones(n,2);
        AssignIndexes=[1:n]+floor(rand(n,1)*2)'*n;
        ScaleMatrix(AssignIndexes)=rand(n,1)+1;
        BiasMult=ScaleMatrix(:,1)./ScaleMatrix(:,2);
    end      
  end
  
  %The bias can only be fixed for bias type 3.  Here, only one type of bias
  % (the fixed bias) is estimated in the initial run and the other bias
  % types are estimated on subsequent runs.
  BiasRunType=BiasType;
  if BiasType<3||((FixAddBias==0)&&(FixMultBias==0))
    Bias=[BiasAdd,BiasMult];
    RunFixedBias=false;
  elseif FixAddBias~=0
    Bias=[BiasAdd,ones(n,1)];
    RunFixedBias=true;
    BiasRunType=1;
  else
    %FixMultBias~=0
    Bias=[zeros(n,1),BiasMult];
    RunFixedBias=true;
    BiasRunType=2;    
  end

  if (EstMethod==1)
    %The bias is not implemented for factor analysis, so use default values
    Bias=[BiasAdd,BiasMult];
  else
    %The initial values of competency and answer key
    if HasExistingz==1
      if Fixz>0
        %One item fixed
        z=[z(1:Fixz-1),zPre,z(Fixz+1:m)];
      else
        %All of the items are fixed
        z=zPre;
      end
    else
      %Use the base value of z, so do nothing
    end 
    
    if HasExistingD==false;
      %Do nothing
    else
      %Run with partial fix
      if FixD>0  
        D=[D(1:FixD-1);DPre;D(FixD+1:n)];
      else
        D=DPre;
      end
    end
       
    %Add question easyness parameters
    switch EstMethod
      case {0,1,2,6}
        HasQE=false;
      case {3,4,5}
        HasQE=true;
    end
  end
  
  
  switch EstMethod
   case {1}
      %Do nothing for pricipal axes factor analysis
   case {0,2,4}
      %Have basic estimate (now second stage of estimating with regression
      %function
      ParamChange=Converge*1000;
      Iter=0;
      while (ParamChange>Converge)&&(Iter<MaxIter)
        OldD=D;OldBias=Bias;OldQE=QE;Oldz=z;

        if EstMethod>0
          if HasExistingz==false||((HasExistingz==true)&&(Fixz>0))
             %Calculate the value of z       
%            switch BiasRunType
%             case 0
%               %Do not estimate the bias
%               z=sum((D*QE).*X.*P,1)./sum(D*QE.*P,1);
%             case 1
%               %Additive bias
%               z=sum((D*QE).*(X-Bias(:,1)*ones(1,m)).*P,1)./sum((D*QE).*P,1); 
%             case 2
%               z=sum((D*QE).*(Bias(:,2)*ones(1,m)).*X.*P,1)./sum((D*QE).*((Bias(:,2)*ones(1,m)).^2).*P,1);
%             case 3
%                        
%           end
            Num=sum((repmat(FuzzyU,1,m).^Fuzzyq).*(D*QE).*(repmat(Bias(:,2),1,m)).*(X-repmat(Bias(:,1),1,m)).*P,1);
            Denom=sum((repmat(FuzzyU,1,m).^Fuzzyq).*(D*QE).*(repmat(Bias(:,2),1,m).^2).*P,1);
            z=Num./Denom;
            if (HasExistingz==true)
              z=[z(1:Fixz-1),zPre,z(Fixz+1:m)];
            end
          end
        end

        %Firstly calculate the inner estimation
        InnerTerm=(X-repmat(Bias(:,1),1,m)-Bias(:,2)*z);
        
        if EstMethod>0
          if HasExistingD==false||((HasExistingD==true)&&(FixD>0))
            %Now estimate the competency based on the model used
            Num=sum(P,2);
            Denom=sum(P.*repmat(QE,n,1).*(InnerTerm.^2),2);
            D=Num./Denom;
            if HasExistingD==true
              D=[D(1:FixD-1);DPre;D(FixD+1:n)];
            end
            if DMax>0
              if sum(D>DMax)>0
                D=min(D,DMax);
              end
            end
          end
        end
        
        %If incorporating item difficulty then include an update
        if (EstMethod==4)
          %Estimate the easyness parameter
          Num=sum(P,1);
          Denom=sum(repmat(D,1,m).*(InnerTerm.^2).*P,1);
          QE=Num./Denom;
          if IEMax>0
            if sum(QE>IEMax)>0
              QE=min(QE,IEMax);
            end
          end
        end
        
        %Calculate the additive bias
        if BiasRunType==1||BiasRunType==3 
          %Estimatif BiasRunType==1||BiasRunType==3e the additive bias parameter
          Num=sum((D*QE).*(X-Bias(:,2)*z).*P,2);
          Denom=sum((D*QE).*P,2);
          Bias(:,1)=Num./Denom;
        end
        
        if BiasRunType==2||BiasRunType==3
          %Multiplicative bias
          Num=sum((D*QE).*P.*(X-repmat(Bias(:,1),1,m)).*repmat(z,n,1),2);
          Denom=sum((D*QE).*P.*repmat((z.^2),n,1),2);
          Bias(:,2)=Num./Denom;
        end
        
        ParamChange=sum(sum(abs(OldBias-Bias)))+sum(abs(OldD-D))+sum(abs(OldQE-QE))+sum(abs(Oldz-z));
        Iter=Iter+1;
      end
    case 3
      %Estimate the values of Alpha(i) and Beta(j)
      Iter=0;
      ParamChange=Converge*1000;
      
      while (ParamChange>Converge)&&(Iter<MaxIter)
        OldD=D;OldQE=QE;OldBias=Bias;Oldz=z;
        
        if EstMethod>0
          if HasExistingz==false||((HasExistingz==true)&&(Fixz>0))
            %Re-estimate z
            Num=sum(((D*QE)./(D*ones(1,m)+ones(n,1)*QE)).*((FuzzyU*ones(1,m)).^Fuzzyq).*(Bias(:,2)*ones(1,m)).*(X-Bias(:,1)*ones(1,m)).*P,1);
            Denom=sum(((D*QE)./(D*ones(1,m)+ones(n,1)*QE)).*((FuzzyU*ones(1,m)).^Fuzzyq).*((Bias(:,2)*ones(1,m)).^2).*P,1);
            z=Num./Denom;
            if HasExistingz==true
              z=[z(1:Fixz-1),zPre,z(Fixz+1:m)];
            end
          end
        end
        
        
        InnerTerm=X-Bias(:,1)*ones(1,m)-Bias(:,2)*z;

        if HasExistingD==false||((HasExistingD==true)&&(FixD>0))
          %Estimate the competancy D
          BR=(ones(n,1)*QE)./((D*ones(1,m))+(ones(n,1)*QE));   %beta/(alpha+beta)
          Num=sum(P.*BR,2);
          Denom=sum(P.*(BR.^2).*(InnerTerm.^2),2);
          D=Num./Denom;
          if HasExistingD==true
            D=[D(1:FixD-1);DPre;D(FixD+1:n)];
          end
          if DMax>0
            if sum(D>DMax)>0
              D=min(D,DMax);
            end
          end
        end
        
        %Estimate the easiness parameter
        BR=(D*ones(1,m))./((D*ones(1,m))+(ones(n,1)*QE));   %beta/(alpha+beta)
        Num=sum(P.*BR,1);
        Denom=sum(P.*(BR.^2).*(InnerTerm.^2),1);
        QE=Num./Denom;

        if IEMax>0
          if sum(QE>IEMax)>0
            QE=min(QE,IEMax);
          end
        end        
        
        %Calculate the additive bias
        if BiasRunType==1||BiasRunType==3 
          %Estimatif BiasRunType==1||BiasRunType==3e the additive bias parameter
          BR=(D*QE)./((D*ones(1,m))+(ones(n,1)*QE)); 
          Num=sum(BR.*(X-Bias(:,2)*z).*P,2);
          Denom=sum(BR.*P,2);
          Bias(:,1)=Num./Denom;
        end
        
        if BiasRunType==2||BiasRunType==3
          %Multiplicative bias
          BR=(D*QE)./((D*ones(1,m))+(ones(n,1)*QE)); 
          Num=sum(P.*BR.*(X-Bias(:,1)*ones(1,m)).*(ones(n,1)*z),2);
          Denom=sum(P.*BR.*(ones(n,1)*(z.^2)),2);
          Bias(:,2)=Num./Denom;
        end
        
        ParamChange=sum(abs(OldQE-QE))+sum(abs(OldD-D))+sum(sum(abs(OldBias-Bias)))+sum(abs(Oldz-z));
        Iter=Iter+1;
      end
    case 5
      %Item difficulty with dij=?(i)+?(j)
      ParamChange=Converge*1000;
      Iter=0;
      while (ParamChange>Converge)&&(Iter<MaxIter)
        OldD=D;OldQE=QE;OldBias=Bias;Oldz=z;
        
        if EstMethod>0
          if HasExistingz==false||((HasExistingz==true)&&(Fixz>0))
            %Re-estimate z
            Num=sum((D*ones(1,m)+ones(n,1)*QE).*((FuzzyU*ones(1,m)).^Fuzzyq).*(Bias(:,2)*ones(1,m)).*(X-Bias(:,1)*ones(1,m)).*P,1);
            Denom=sum((D*ones(1,m)+ones(n,1)*QE).*((FuzzyU*ones(1,m)).^Fuzzyq).*((Bias(:,2)*ones(1,m)).^2).*P,1);
            z=Num./Denom;
            if HasExistingz==true
              z=[z(1:Fixz-1),zPre,z(Fixz+1:m)];
            end 
          end
        end 
    
        InnerTerm=(X-(Bias(:,1)*ones(1,m))-Bias(:,2)*z);
        
        if HasExistingD==false||((HasExistingD==true)&&(FixD>0))
          %Estimate competency D
          RHS=sum((InnerTerm.^2).*P,2);
          LHS=sum((1./(D*ones(1,m)+ones(n,1)*QE)).*P,2);
          D=RHS-LHS;
          if HasExistingD==true
            D=[D(1:FixD-1);DPre;D(FixD+1:n)];
          end 
          if DMax>0
            if sum(D>DMax)>0
              D=min(D,DMax);
            end
          end
        end
          
        %Estimate the easyness parameter
        %Estimate competency D
        Num=QE.*sum((InnerTerm.^2).*P,1);
        Denom=sum((1./(D*ones(1,m)+ones(n,1)*QE)).*P,1);
        QE=Num./Denom;
        
        if IEMax>0
          if sum(QE>IEMax)>0
            QE=min(QE,IEMax);
          end
        end
       
        %Calculate the additive bias
        if BiasRunType==1||BiasRunType==3 
          %Estimatif BiasRunType==1||BiasRunType==3e the additive bias parameter
          Num=sum((D*ones(1,m)+ones(n,1)*QE).*(X-Bias(:,2)*z).*P,2);
          Denom=sum((D*ones(1,m)+ones(n,1)*QE).*P,2);
          Bias(:,1)=Num./Denom;
        end
        
        if BiasRunType==2||BiasRunType==3
          %Multiplicative bias
          Num=sum(P.*(D*ones(1,m)+ones(n,1)*QE).*(X-Bias(:,1)*ones(1,m)).*(ones(n,1)*z),2);
          Denom=sum(P.*(D*ones(1,m)+ones(n,1)*QE).*(ones(n,1)*(z.^2)),2);
          Bias(:,2)=Num./Denom;
        end
        
        ParamChange=sum(abs(OldQE-QE))+sum(abs(OldD-D))+sum(sum(abs(OldBias-Bias)))+sum(abs(Oldz-z));
        Iter=Iter+1;
      end
    case 6
      %Now recalculate Z and d until convergence
      ParamChange=Converge*1000;
      Iter=0;
      while (ParamChange>Converge)&&(Iter<MaxIter)
        %Basic estimation for the Weber-Fechner law
        Oldz=z;OldD=D;
%       Num=sum(D*ones(1,m).*((X.^2)-X.*(ones(n,1)*z)).*P,1);
%       Denom=sum(P,1);
%       z=(Num./Denom).^0.5;
        Num=sum(D*ones(1,m).*X.*P,1);
        Denom=sum(D*ones(1,m).*P,1);
        z=Num./Denom;
        Num=sum(P,2);
        Denom=sum(P.*(((X-(ones(n,1)*z)).^2)./(ones(n,1)*(z.^2))),2);
        D=Num./Denom; %Account for the missing data
        if DMax>0
          if sum(D>DMax)>0
            D=min(D,DMax);
          end
        end
        ParamChange=sum(abs(Oldz-z))+sum(abs(OldD-D));
        Iter=Iter+1;
      end
  end
  
  
  %If on part of the bias has been fixed then rerun with the main
  %parameters and the bias not fixed.  Only fixing the initial bias, which
  %does not need to be bounded.
  if RunFixedBias==true
    OldBias=Bias;
    if FixAddBias~=0
      BiasPre=Bias(1,:);
      [V,I]=sort(abs(median(BiasPre)-BiasPre));
      if FixAddBias>0 
        FixAddBias=I(1);
        BiasPre=BiasPre(FixAddBias);
      end
    end
    
    if FixMultBias~=0
      BiasPre=Bias(:,2);
      if FixMultBias>0
        [V,I]=sort(abs(median(BiasPre)-BiasPre));
        FixMultBias=I(1);
        BiasPre=BiasPre(FixMultBias);
      end
    end  
    
    ParamChange=Converge*1000;
    Iter=0;
    %Now estimating the remaining unfixed biased parameters
    while (ParamChange>Converge)&&(Iter<MaxIter)
      OldBias=Bias;
      switch EstMethod
      case {1}
        %Do nothing for pricipal axes factor analysis
      case {0,2,4}
        if FixAddBias>=0
          Num=sum((X-Bias(:,2)*z).*P,2);
          Denom=sum(P,2);
          Bias(:,1)=Num./Denom;
          if FixAddBias>0
            Bias(:,1)=[Bias(1:FixAddBias-1,1);BiasPre;Bias(FixAddBias+1:n,1)];
          end
        end
        if FixMultBias>=0
          %Multiplicative bias
          Num=sum(P.*(X-Bias(:,1)*ones(1,m)).*(ones(n,1)*z),2);
          Denom=sum(P.*(ones(n,1)*(z.^2)),2);
          Bias(:,2)=Num./Denom;
          if FixMultBias>0
            Bias(:,2)=[Bias(1:FixMultBias-1);BiasPre;Bias(FixMultBias+1:n)];
          end
        end
      case 3
        if FixAddBias>=0
          BR=(D*QE)./((D*ones(1,m))+(ones(n,1)*QE)); 
          Num=sum(BR.*(X-Bias(:,2)*z).*P,2);
          Denom=sum(BR.*P,2);
          Bias(:,1)=Num./Denom;
          if FixAddBias>0
            Bias(1,:)=[Bias(1:FixAddBias-1);BiasPre;z(FixAddBias+1:n)];
          end
        end
        if FixMultBias>=0
          %Multiplicative bias
          Num=sum(P.*(X-Bias(:,1)*ones(m,1)).*(ones(n,1)*z),2);
          Denom=sum(P.*(ones(n,1)*(z.^2)),2);
          Bias(:,2)=Num./Denom;
          if FixMultBias>0
            Bias(:,2)=[Bias(1:FixMultBias-1);BiasPre;Bias(FixMultBias+1:n)];
          end
        end
      case 5
        if FixAddBias>=0
          Num=sum((D*ones(m,1)+ones(n,1)*QE).*(X-Bias(:,2)*z).*P,2);
          Denom=sum((D*ones(m,1)+ones(n,1)*QE).*P,2);
          Bias(:,1)=Num./Denom;
          if FixAddBias>0
            Bias(1,:)=[Bias(1:FixAddBias-1);BiasPre;z(FixAddBias+1:n)];
          end
        end
        if FixMultBias>=0
          %Multiplicative bias
          BR=(D*QE)./((D*ones(1,m))+(ones(n,1)*QE)); 
          Num=sum(P.*BR.*(X-Bias(:,1)*ones(m,1)).*(ones(n,1)*z),2);
          Denom=sum(P.*BR.*(ones(n,1)*(z.^2)),2);
          Bias(:,2)=Num./Denom;
          if FixMultBias>0
            Bias(:,2)=[Bias(1:FixMultBias-1);BiasPre;Bias(FixMultBias+1:n)];
          end
        end          
      end
      
      ParamChange=sum(sum(OldBias-Bias));
    end
  end
  
  %Remove the additional value of X
  if AddLine==true
    n=n-1;
    X=X(1:n,:);
    P=P(1:n,:);
    D=D(1:n,:);
    Bias=Bias(1:n,:);
  end
  
   %Calculate the criterion value
  switch EstMethod
    case 1
      %Calculate the residual from the VAF
      MeanVal=mean(mean(CorrMatrix));
      MaxCrit=1-(ssq(Resid)./ssq(CorrMatrix-MeanVal));
      %Weight using the number of items (need this to make it consistant
      %for the clusterwise estimation procedure
      MaxCrit=MaxCrit.*100;
      LLPartial=zeros(3,m);
    case {0,2,3,4,5}
      %Calculate the inner term for the bias
      InnerTerm=(X-(Bias(:,1)*ones(1,m))-Bias(:,2)*z); 
      
      switch EstMethod
        case {0,2,4}
          %Calculate the maximum log likelihood value
          Part1=P.*(log(((D*QE)./(2*pi)).^0.5));
          Part2=P.*((-D*QE).*(InnerTerm.^2)./2);
          MaxCrit=sum(sum((FuzzyU*ones(1,m)).*(Part1+Part2)));
        case 3
          Ratio=(D*QE)./((D*ones(1,m))+(ones(n,1)*QE));
          Part1=log((Ratio./(2*pi)).^0.5);
          Part2=P.*-Ratio.*(InnerTerm.^2)./2;
          MaxCrit=sum(sum((FuzzyU*ones(1,m)).*(Part1+Part2)));       
        case 5
          Part1=P.*(log(((D*ones(1,m)+ones(n,1)*QE)./(2*pi)).^0.5));
          Part2=P.*(-(D*ones(1,m)+ones(n,1)*QE).*(InnerTerm.^2)./2);
          MaxCrit=sum(sum((FuzzyU*ones(1,m)).*(Part1+Part2)));          
      end
      
      if ReturnLLPartial==1
        %Calculate the partial log likelihoods
        LLPartial=zeros(3,m);
        for j=1:m
          zval=z(j);
          %Store z, the lower bound and the upper bound
          zAll=[zval,fix(zval),fix(zval+1)];
          QEAll=QE(j)*ones(1,3);
          InnerTerm=(X(:,j)*ones(1,3)-(Bias(:,1)*ones(1,3))-Bias(:,2)*zAll);

          %Estimate partial log likelihoods
          switch EstMethod
          case {0,2,4}
            Part1=(P(:,j)*ones(1,3)).*(log(((D*QEAll)./(2*pi)).^0.5));
            Part2=(P(:,j)*ones(1,3)).*(-D*QEAll).*(((InnerTerm).^2)./2);
            LLPartial(:,j)=sum((FuzzyU*ones(1,3)).*(Part1+Part2),1)';
          case 3
            Part1=(P(:,j)*ones(1,3)).*(log((((D*ones(1,3)).*(ones(n,1)*QEAll))./(((D*ones(1,3))+(ones(n,1)*QEAll))*2*pi)).^0.5));
            Part2=(P(:,j)*ones(1,3)).*((-((D*ones(1,3)).*(ones(n,1)*QEAll))).*((X(:,j)*ones(1,3)-ones(n,1)*zAll).^2)./(2*((D*ones(1,3))+(ones(n,1)*QEAll))));
            LLPartial(:,j)=sum((FuzzyU*ones(1,3)).*(Part1+Part2),1)';   
          case 5
            Part1=(P(:,j)*ones(1,3)).*(log(((D*ones(1,3)+ones(n,1)*QEAll)./(2*pi)).^0.5));
            Part2=(P(:,j)*ones(1,3)).*(-(D*ones(1,3)+ones(n,1)*QEAll).*((X(:,j)*ones(1,3)-ones(n,1)*zAll).^2)./2);
            LLPartial(:,j)=sum((FuzzyU*ones(1,3)).*(Part1+Part2),1)';
          end

        end 
      else
        %For the sake of speed, LLPartial is not calculated
        LLPartial=-1;
      end
    case 6
      Part1=P.*(log((1./(ones(n,1)*z)).*(((D*ones(1,m))./(2*pi)).^0.5)));
      Part2=P.*((-D*ones(1,m)).*((X-(ones(n,1)*z)).^2)./(2.*ones(n,1)*(z.^2)));
      MaxCrit=sum(sum((FuzzyU*ones(1,m)).*(Part1+Part2)));
      %Calculate the partial log likelihoods
      LLPartial=zeros(3,m);
      for j=1:m
        zval=z(j);
        %Store z, the lower bound and the upper bound
        zAll=[zval,fix(zval),fix(zval+1)];
        Part1=(P(:,j)*ones(1,3)).*(log((1./(ones(n,1)*zAll)).*(((D*ones(1,3))./(2*pi)).^0.5)));
        Part2=(P(:,j)*ones(1,3)).*((-D*ones(1,3)).*((X(:,j)*ones(1,3)-(ones(n,1)*zAll)).^2)./(2.*ones(n,1)*(zAll.^2)));
        LLPartial(:,j)=sum((FuzzyU*ones(1,m)).*(Part1+Part2),1)';
      end
    
  end



