function [f] = faMinID0(x,D,FixIX,Penalty)
%fa2Min - Provides the function value for a least squares approximation of 
%the item difficulty function given on p375 of the Karabatsos and
%Batchelder (2003) paper. 
%factor analysis procedure
%Inputs
%x - The current value of the function parameters (F, but gone with Matlab
%notation).  x is a n+(m-1) vector.  One of the indexes has 
%D - The (n*m) matrix of user*item competencies (hit rate-false positives)
%FixIX - To identify the model one of the difficulty parameters needs to
%be set to 0.5 (leave for moment)
%Penalty - The function penalty value for each variable outside the [0,1]
%range
%Outputs
%f - The function value for x
%Version     Author            Date
%   0.10     Stephen France    04/01/2012

[n,m]=size(D);

%Calculate the formula for DIK
Theta=x(1:n);
switch FixIX
  case 1
    Delta=[0.5,x(n+2:n+m-1)'];
  case m
    Delta=[x(n+1:n+m-1)',0.5];
  otherwise
    %N.B. all index after and including FixIX are incrememented by 1
    Delta=[x(n+1:n+FixIX-1)',0.5,x(n+FixIX:n+m-1)'];
end

%Calculate penalty
AllPenalty=sum((x<0)|(x>0)).*Penalty;

Comp1=(Theta*ones(1,m)).*(ones(n,1)*(1-Delta));
Comp2=((1-Theta)*ones(1,m)).*(ones(n,1)*Delta);

Diff=(D-(Comp1./(Comp1+Comp2))).^2;

f=sum(sum(Diff))+AllPenalty;

end

