function [Block1,Block2] = VisualizeBlocks(Blocks,gRowIndexes,gColIndexes,R)
%Visualize the Blocks in a matrix, with elements a(ij)=k, where k is the
%block number.  
%Inputs
%Blocks - A set of block structures, as defined in BlockCluster.m.
%RowIndexes - The original row indexes
%ColIndexes - The original column indexes
%R - The number of clusters to show (optional).  If R is not provided then
%give all active clusters.
%Outputs
%Block1 - An n*m cluster numbered block matrix with columns ordered so clusters
%   are not split (as per Harshmann in order of sum of squares).
%Block2 - An n*m cluster numbered block matrix with columns in the original
%   order and clusters possibly split.
%Version     Author            Date
%   0.10     Stephen France    04/10/2012
VBlocks=Blocks;
MaxR=Blocks.Count;

%The first block has the number of rows and columns
n=Blocks.RowCount{1};
m=Blocks.ColCount{1};
Block1=zeros(n,m);

if ~exist('WeightParam','var')
  %Go through all clusters
  MaxCount=VBlocks.Count;
else
  %Two clusters are added to the block at each split of the algorithm
  MaxCount=1+(2*(R-1));
  %Must change the active properties
  for i=MaxR:-1:MaxCount+1
    VBlocks.Active{i}=0;
    VBlocks.Active{VBlocks.Parent{i}}=1;
  end
end


CurrentBlock=0;  %Blocks renumbered for active blocks
for i=1:MaxCount
  %Only select current 'leaf' blocks
  if (VBlocks.Active{i}==1)
    CurrentBlock=CurrentBlock+1;
    Block1(VBlocks.mRowIndexes{i},VBlocks.mColIndexes{i})=CurrentBlock;
  end
end
 
%With original indexes
if exist('gRowIndexes','var')&& exist('gRowIndexes','var')
  Block2(gRowIndexes,gColIndexes)=Block1;
end

end

