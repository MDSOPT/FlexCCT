function [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCTWRP(X,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior)
%A wrapper for continuous CCT.  See ContinuousCCT3 and ContinousCCT5 for a
%full description of parameters.  
%Version     Author            Date
%   0.10     Stephen France    08/27/2013
%   2.00     Stephen France    03/31/2016

  switch OptMethod
    case {0,1}
	  %The fixed point algorithm
      if DPrior==-1
        [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT5(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax);
      else
        [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT5(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior);
      end
    case 2
	  %MATLAB derivative free algorithm
      if DPrior==-1
        [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT3(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,0,DMax,IEMax);
      else
        [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT3(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,0,DMax,IEMax,DPrior);
      end
    case 3
	  %MATLAB Gradient descent algorithm
      if DPrior==-1
        [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT3(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,1,DMax,IEMax);
      else
        [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT3(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,1,DMax,IEMax,DPrior);
      end
      
  end


end

