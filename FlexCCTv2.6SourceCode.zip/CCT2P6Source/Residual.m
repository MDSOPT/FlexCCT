%Performs residual analysis for the CCT results.  Plots all/average residuals for
%the current models.  Gives options to output the graphs.
%Version     Author            Date
%   2.00     Stephen France    04/02/2016
function varargout = Residual(varargin)
% RESIDUAL MATLAB code for Residual.fig
%      RESIDUAL, by itself, creates a new RESIDUAL or raises the existing
%      singleton*.
%
%      H = RESIDUAL returns the handle to a new RESIDUAL or the handle to
%      the existing singleton*.
%
%      RESIDUAL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RESIDUAL.M with the given input arguments.
%
%      RESIDUAL('Property','Value',...) creates a new RESIDUAL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Residual_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Residual_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Residual

% Last Modified by GUIDE v2.5 01-Apr-2016 16:00:04

% Begin initialization code - DO NOT EDIT

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Residual_OpeningFcn, ...
                   'gui_OutputFcn',  @Residual_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before Residual is made visible.
function Residual_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Residual (see VARARGIN)
try
  % Choose default command line output for Residual
  handles.output = hObject;

  % Update handles structure
  guidata(hObject, handles);

  %Set the icon to be the standard icon
  javaFrame = get(handle(hObject),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));

  %Setup the number of clusters
  NoCultures=str2num(getappdata(0,'NoCultures'));
  for i=1:NoCultures
    ComboText{i} = num2str(i);
  end
  set(handles.cboCultureNo,'String',ComboText);
catch err
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h); 
end

% This sets up the initial plot - only do when we are invisible
% so window can get raised using Residual.
if strcmp(get(hObject,'Visible'),'off')
  PlotAverageResiduals(handles);
end

% UIWAIT makes Residual wait for user response (see UIRESUME)
% uiwait(handles.Residual);


% --- Outputs from this function are returned to the command line.
function varargout = Residual_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file = uigetfile('*.fig');
if ~isequal(file, 0)
    open(file);
end

% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.Residual)

% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.Residual,'Name') '?'],...
                     ['Close ' get(handles.Residual,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end

delete(handles.Residual)


% --- Executes on selection change in cboGraph.
function cboGraph_Callback(hObject, eventdata, handles)
% hObject    handle to cboGraph (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns cboGraph contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboGraph


% --- Executes during object creation, after setting all properties.
function cboGraph_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboGraph (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
     set(hObject,'BackgroundColor','white');
end

set(hObject, 'String', {'Average Residuals', 'All Residuals'});

% --- Executes on button press in cmdSave.
function cmdSave_Callback(hObject, eventdata, handles)
% hObject    handle to cmdSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
  %get the filepath to save the file
  [FileName,FilePath]=uiputfile({'*.bmp;*.gif;*.jpg;*.png;*.tif;','All Image Files';...
          '*.*','All Files' },'Save Image',...
          'newfile.png');
  ExPath = [FilePath FileName];
  %load data in variables
  ColNames=getappdata(0,'colnames');
  data=getappdata(0,'data');
  if(FileName~=0)
    %save the file in correct graphics format
    export_fig(handles.axes1, ExPath);
  end
catch err
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h); 
end

% --- Executes on button press in cmdUpdate.
function cmdUpdate_Callback(hObject, eventdata, handles)
% hObject    handle to cmdUpdate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

axes(handles.axes1);
cla;

popup_sel_index = get(handles.cboGraph, 'Value');
switch popup_sel_index
    case 1
        PlotAverageResiduals(handles);
    case 2
        PlotAllResiduals(handles);
end

function PlotAverageResiduals(handles)  
  %Get residual information and culture information from the app level data
  Residuals=getappdata(0,'Residuals');
  Results=getappdata(0,'Results');
  m=getappdata(0,'m');
  CultureIndex = get(handles.cboCultureNo, 'Value');
  
  %Get details for the selected culture
  Residuals=Residuals{CultureIndex};
  zOut=Results.z{CultureIndex};
  
  if m<100
    PointSize=20;LineSize=1.5;
  elseif m<500
    PointSize=10;LineSize=1;
  else
    PointSize=5;LineSize=0.5;
  end
  
  %Scatterplot with labels and average residuals
  scatter(handles.axes1,zOut,nanmean(abs(Residuals)),PointSize,'MarkerEdgeColor',[0 .5 .5],...
              'MarkerFaceColor',[0 .7 .7],...
              'LineWidth',LineSize);
  lsline;
  xlabel('z');
  ylabel('average absolute residual');
  title('Average Residuals X');
  
  
function PlotAllResiduals(handles)

  %Get residual information and culture information from the app level data
  Residuals=getappdata(0,'Residuals');
  Results=getappdata(0,'Results');
  CultureIndex = get(handles.cboCultureNo, 'Value');
  
  %Get details for the selected culture
  Residuals=Residuals{CultureIndex};
  zOut=Results.z{CultureIndex};
  [n,m]=size(Residuals);
  x=reshape(ones(n,1)*zOut,n*m,1);
  y=reshape(Residuals,n*m,1);
  %Remove any NaN
  IndexKeep=~isnan(y);
  x=x(IndexKeep);
  y=y(IndexKeep);
  if m<100
    PointSize=20;LineSize=1.5;
  elseif m<500
    PointSize=10;LineSize=1;
  else
    PointSize=5;LineSize=0.5;
  end
  
  
  scatter(x,y,PointSize,'MarkerEdgeColor',[0 .5 .5],...
              'MarkerFaceColor',[0 .7 .7],...
              'LineWidth',LineSize);
  lsline;
  xlabel('z');
  ylabel('residual');
  title('All Residuals X');


% --- Executes on selection change in cboCultureNo.
function cboCultureNo_Callback(hObject, eventdata, handles)
% hObject    handle to cboCultureNo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboCultureNo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboCultureNo


% --- Executes during object creation, after setting all properties.
function cboCultureNo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboCultureNo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% Get the number of cultures
NoCultures=str2num(getappdata(0,'NoCultures'));
for i=1:NoCultures
  CultureText{i}=num2str(i);
end
set(hObject, 'String', CultureText);

% --- Executes when user attempts to close Residual.
function Residual_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to Residual (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
selection =MFquestdlg([0.3,0.5],'Are you sure that you would like to close the residuals pane?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes',
delete(hObject);
case 'No'
return
end %switch


% --- Executes on button press in cmdExit.
function cmdExit_Callback(hObject, eventdata, handles)
% hObject    handle to cmdExit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = MFquestdlg([0.3,0.5],'Are you sure that you would like to close the residuals pane?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes',
delete(gcf);
case 'No'
return
end %switch
