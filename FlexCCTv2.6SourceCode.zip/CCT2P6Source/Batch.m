function varargout = Batch(varargin)
% BATCH MATLAB code for Batch.fig
%      BATCH, by itself, creates a new BATCH or raises the existing
%      singleton*.
%
%      H = BATCH returns the handle to a new BATCH or the handle to
%      the existing singleton*.
%
%      BATCH('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BATCH.M with the given input arguments.
%
%      BATCH('Property','Value',...) creates a new BATCH or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Batch_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Batch_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Batch

% Last Modified by GUIDE v2.5 04-Jul-2017 22:13:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Batch_OpeningFcn, ...
                   'gui_OutputFcn',  @Batch_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Batch is made visible.
function Batch_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Batch (see VARARGIN)

% Choose default command line output for Batch
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Batch wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Batch_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function txtStart_Callback(hObject, eventdata, handles)
% hObject    handle to txtStart (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtStart as text
%        str2double(get(hObject,'String')) returns contents of txtStart as a double


% --- Executes during object creation, after setting all properties.
function txtStart_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtStart (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtEnd_Callback(hObject, eventdata, handles)
% hObject    handle to txtEnd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtEnd as text
%        str2double(get(hObject,'String')) returns contents of txtEnd as a double


% --- Executes during object creation, after setting all properties.
function txtEnd_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtEnd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cmdRun.
function cmdRun_Callback(hObject, eventdata, handles)
% hObject    handle to cmdRun (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Run1(hObject, eventdata, handles);
Run2(hObject, eventdata, handles)


function Run1(hObject, eventdata, handles)
try
  StartVal=str2num(get(handles.txtStart,'string'));
  EndVal=str2num(get(handles.txtEnd,'string'));
  Rows=StartVal:EndVal;
  DataFile='RatingsMatrix.csv';
  ExpSpec='AAExpSpec.csv';

  RowLength=length(Rows);
  %First load the file
  Spec=importdata(strcat(pwd,'\',ExpSpec),',');
  if isnumeric(Spec)==0
    %data possibly contains some headers
    Spec=Spec.data;
  end

  X=importdata(strcat(pwd,'\',DataFile),',');
  if isnumeric(X)==0
    %data possibly contains some headers
    X=X.data;
  end
  %Data has header
  [n,m]=size(X);
  X=X(2:n,2:m);

  %Set standard parameters for each run
  zGround=[];
  ClusterOptions.NoCultures=1;
  ClusterOptions.NoClusteringRuns=1;
  ClusterOptions.ClusterBias=0;

  CIOptions.CIz=0;
  CIOptions.CId=0;
  CIOptions.CIbadd=0;
  CIOptions.CIbmult=0;
  CIOptions.CIIE=0;
  CIOptions.CIReplace=0;
  CIOptions.HasRaterBootstrap=CIOptions.CId||CIOptions.CIbadd||CIOptions.CIbmult;
  CIOptions.HasItemBootstrap=CIOptions.CIz||CIOptions.CIIE;

  %We are only running the X Prediction holdout
  VldOptions.HOz=0;
  VldOptions.HOXPred=1;
  VldOptions.HOd=0;
  VldOptions.HObadd=0;
  VldOptions.HObmult=0;
  VldOptions.HOIE=0;

  VldOptions.NoHoldout=1059;
  VldOptions.MaxRuns=1000;
  VldOptions.MSE=1;
  VldOptions.MSPE=0;
  VldOptions.MAE=1;
  VldOptions.MAPE=0;
  VldOptions.Correl=1;
  VldOptions.RunGroundTruth=0;
  VldOptions.HasHoldout=1;
  VldOptions.HasHoldoutCriteria=1;
  Converge=1e-6;
  MaxIter=1000;
  MissingVal=-1;
  DMax=10;
  IEMax=10;

  for Counter=1:RowLength
    RowNo=Rows(Counter);
    %Get estimation details from the 
    EstMethod =Spec(RowNo,2);
    BiasType = Spec(RowNo,3);
    FixParams=Spec(RowNo,4:7);
    %Used fix point unless there is at least one -99 (average), which will
    %make sum <0
    if sum(FixParams)>=-10
      OptMethod=3;
    else
      OptMethod=1;
    end

    [Results] = FlexCCT(X,zGround,ClusterOptions,CIOptions,VldOptions,EstMethod,BiasType,FixParams,OptMethod,Converge,MaxIter,MissingVal,DMax,IEMax);
    if (EstMethod==5)
      [Basic,CCT] = CCTReliabilityAdd3(Results.SX{1},MissingVal,Results.D{1},Results.Bias{1},Results.QE{1});
     else
       %Efficient routine with no missing data
       [Basic,CCT] = CCTReliability3(Results.SX{1},MissingVal,Results.D{1},Results.Bias{1},Results.QE{1});
     end
     %If running holdout validation with predictions, the sixth value is
     %the log-likelihood over the predicted data
     data=[Results.MaxCrit{1},Results.Holdout{1}.XPredHOMetrics.Values(6),Basic,CCT];
     FilePath=strcat(pwd,'\','AAOut',int2str(RowNo),'.csv');
     csvwrite(FilePath,data);

  end

catch err
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h); 
end

function Run2(hObject, eventdata, handles)
try
  StartVal=str2num(get(handles.txtStart,'string'));
  EndVal=str2num(get(handles.txtEnd,'string'));
  Rows=StartVal:EndVal;
  DataFile='Grading6Traits.csv';
  ExpSpec='AAExpSpec.csv';

  RowLength=length(Rows);
  %First load the file
  Spec=importdata(strcat(pwd,'\',ExpSpec),',');
  if isnumeric(Spec)==0
    %data possibly contains some headers
    Spec=Spec.data;
  end

  X=importdata(strcat(pwd,'\',DataFile),',');
  if isnumeric(X)==0
    %data possibly contains some headers
    X=X.data;
  end
  %Data does not have numeric header
  [X] = CreateSingleX(X,6,0,0,-1);
  [n,m]=size(X);

  %Set standard parameters for each run
  zGround=[];
  ClusterOptions.NoCultures=1;
  ClusterOptions.NoClusteringRuns=1;
  ClusterOptions.ClusterBias=0;

  CIOptions.CIz=0;
  CIOptions.CId=0;
  CIOptions.CIbadd=0;
  CIOptions.CIbmult=0;
  CIOptions.CIIE=0;
  CIOptions.CIReplace=0;
  CIOptions.HasRaterBootstrap=CIOptions.CId||CIOptions.CIbadd||CIOptions.CIbmult;
  CIOptions.HasItemBootstrap=CIOptions.CIz||CIOptions.CIIE;

  %We are only running the X Prediction holdout
  VldOptions.HOz=1;
  VldOptions.HOXPred=1;
  VldOptions.HOd=1;
  VldOptions.HObadd=0;
  VldOptions.HObmult=0;
  VldOptions.HOIE=0;

  VldOptions.NoHoldout=1;
  VldOptions.MaxRuns=1000;
  VldOptions.MSE=1;
  VldOptions.MSPE=0;
  VldOptions.MAE=1;
  VldOptions.MAPE=0;
  VldOptions.Correl=1;
  VldOptions.RunGroundTruth=0;
  VldOptions.HasHoldout=1;
  VldOptions.HasHoldoutCriteria=1;
  Converge=1e-6;
  MaxIter=1000;
  MissingVal=-1;
  DMax=10;
  IEMax=10;

  for Counter=1:RowLength
    RowNo=Rows(Counter);
    %Get estimation details from the 
    EstMethod =Spec(RowNo,2);
    BiasType = Spec(RowNo,3);
    FixParams=Spec(RowNo,4:7);
    %Used fix point unless there is at least one -99 (average), which will
    %make sum <0
    if sum(FixParams)>=-10
      OptMethod=3;
    else
      OptMethod=1;
    end

    [Results] = FlexCCT(X,zGround,ClusterOptions,CIOptions,VldOptions,EstMethod,BiasType,FixParams,OptMethod,Converge,MaxIter,MissingVal,DMax,IEMax);
    if (EstMethod==5)
      [Basic,CCT] = CCTReliabilityAdd3(Results.SX{1},MissingVal,Results.D{1},Results.Bias{1},Results.QE{1});
     else
       %Efficient routine with no missing data
       [Basic,CCT] = CCTReliability3(Results.SX{1},MissingVal,Results.D{1},Results.Bias{1},Results.QE{1});
     end
     %If running holdout validation with predictions, the sixth value is
     %the log-likelihood over the predicted data
     data=[Results.MaxCrit{1},Results.Holdout{1}.XPredHOMetrics.Values(6),...
       Results.Holdout{1}.dHOMetrics.Values(1),Results.Holdout{1}.dHOMetrics.Values(3),Results.Holdout{1}.dHOMetrics.Values(5),...
       Results.Holdout{1}.zHOMetrics.Values(1),Results.Holdout{1}.zHOMetrics.Values(3),Results.Holdout{1}.zHOMetrics.Values(5),Basic,CCT];
     FilePath=strcat(pwd,'\','AASmallOut',int2str(RowNo),'.csv');
     csvwrite(FilePath,data);

  end

catch err
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h); 
end
