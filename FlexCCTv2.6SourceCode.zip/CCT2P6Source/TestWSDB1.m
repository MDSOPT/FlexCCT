%The first experiment for the web search and data mining conference

AllResults=[];
MinScale=0.5;
OverallRun=0;

for NoItems=50:50
  for NoUsers=50:50
    for Scale=5:10
      Range=Scale-1;
      Centre=1+(Range/2);
      for TrueDist=1:2
        for MissingPC=0:25:50
          for Scheme=1:5
            for DMax=5:5
              for Run=1:1
                OverallRun=OverallRun+1;
                if mod(OverallRun,10)==0
                  OverallRun
                end
                Results=[Run,DMax,NoItems,NoUsers,Scale,TrueDist,MissingPC,Scheme];
                %First randomly select true review scores
                if TrueDist==1
                  %Sample from normal distribution with mean at the center
                  %point and with 1 standard devation = 1/6 range
                  z = norminv(rand(1,NoItems),Centre,Range/5);
                else
                  %Sample from uniform distribution
                  z=(rand(1,NoItems).*Range)+1;
                end
                %Determine latent competencies for users
                Mind=(Range/3)^(-2);
                Midd=(Range/6)^(-2);
                Maxd=(Range/9)^(-2);
                switch Scheme
                case 1
                  %Select all users to have the average competancy
                  D=ones(NoUsers,1).*Midd;
                case 2
                  %Random competencies between min and max
                  D=Mind+rand(NoUsers,1).*(Maxd-Mind);
                case 3
                  %75% competent and 25% not competent
                  IsComp=rand(NoUsers,1)>0.25;
                case 4
                  %50% competent and 50% not competent
                  IsComp=rand(NoUsers,1)>0.5;
                case 5 
                  %25% competent and 75% not competent
                  IsComp=rand(NoUsers,1)>0.75;              
                end
                switch Scheme
                  case {3,4,5}
                  %Users competent if one and not competent if 0
                  D=IsComp.*Maxd+(1-IsComp).*Mind;
                end
                %Now sample an answer key given the competency and the true
                %score
                %Sample an error matrix based on competencies
                Error=zeros(NoUsers,NoItems);
                for i=1:NoUsers
                  P=rand(1,NoItems);
                  Error(i,:) = norminv(P,0,(D(i)^(-0.5)));
                end
                %Add the error to the actual values of the items
                X=ones(NoUsers,1)*z+Error;
                X=round(X);
                X=min(max(1,X),Scale);   %Ensure in bounds
                %Replace any missing data by -1
                IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                AllAssigned=isempty(find(sum(1-IsMissing,1)==0))&&isempty(find(sum(1-IsMissing,2)==0));
                while (AllAssigned==0)
                  IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                  [IsMissing,AllAssigned]=FixMissing(IsMissing,1000);
                end
                X=-IsMissing+(1-IsMissing).*X;


                %Now run continuous cultural consensus theory
                [z2,D2,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT4(X,2,0,[0,0,0,0],[1e-6,1000,1],-1,DMax,DMax);
                [IC2] = InformationCriteria(MaxCrit,NoItems+NoUsers,sum(sum(1-IsMissing)));
                [z3,D3,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT4(X,1,0,[0,0,0,0],[1e-6,1000,1],-1,DMax,DMax);
                %Calculate all of the comparison statistics
                [z4] = CCTAggregate(X,-1,1);   %straight arithmetic mean
                [z5] = CCTAggregate(X,-1,2);   %straight geometric mean
                [z6] = CCTAggregate(X,-1,3,1e-6); %combined arithmetic/geometric mean
                [z7] = CCTAggregate(X,-1,4);   %The harmonic mean       
                [z8] = CCTAggregate(X,-1,5);   %Variance adjusted mean

                
                Results2=zeros(1,21);
                if IC2.AIC<0
                 temp=0;
                end
                %Return the AIC,AICc, and BIC for the two models
                Results2(1)=IC2.AIC;
                Results2(2)=IC2.CorAIC;
                Results2(3)=IC2.BIC;
                %Calculate the MAE and MSE between Ds for all models
                Results2(4)=sum((D-D2).^2)./NoUsers;
                Results2(5)=sum(abs(D-D2))./NoUsers;
                Results2(6)=sum((D-D3).^2)./NoUsers;
                Results2(7)=sum(abs(D-D3))./NoUsers;
                %Now calculate the accuracy of z
                Results2(8)=sum((z-z2).^2)./NoItems;
                Results2(9)=sum(abs(z-z2))./NoItems;
                Results2(10)=sum((z-z3).^2)./NoItems;
                Results2(11)=sum(abs(z-z3))./NoItems;                
                Results2(12)=sum((z-z4).^2)./NoItems;
                Results2(13)=sum(abs(z-z4))./NoItems;
                Results2(14)=sum((z-z5).^2)./NoItems;
                Results2(15)=sum(abs(z-z5))./NoItems;
                Results2(16)=sum((z-z6).^2)./NoItems;
                Results2(17)=sum(abs(z-z6))./NoItems;
                Results2(18)=sum((z-z7).^2)./NoItems;
                Results2(19)=sum(abs(z-z7))./NoItems;
                Results2(20)=sum((z-z8).^2)./NoItems;
                Results2(21)=sum(abs(z-z8))./NoItems;
                
                NewResults=[Results,Results2];
                AllResults=[AllResults;NewResults];
                save 'C:\CCOut\CONCLUSV2\NoBias1.txt' NewResults -append -ascii;
              end
            end
          end
        end
      end
    end
  end
end