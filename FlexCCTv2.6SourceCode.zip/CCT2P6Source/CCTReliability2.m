function [Basic,CCT] = CCTReliability2(X,MissingVal,d,Bias,IE)
%Reliability for continuous cultural consensus analysis.  This procedure
%returns the continuous reliability metric iota, as defined by Janson and Olson (2001)
%and also the consensus adjusted reliability metric, as defined by France
%and Batchelder.  Works for all models except for the additive item easiness model
%INPUTS
%X - The n user*m item matrix of ratings
%MissingVal - The indicator for missing value
%d   - An n*1 vector of user competencies
%Bias - An n*2 vecttor of biases (1st column additive, 2nd column multiplicative)
%IE   - A continuous m*1 answer key vector
%OUTPUTS
%Basic - The Basic reliability coefficient
%CCT - The CCT reliability coefficient, incorporating competency, bias, and item easiness
%Version     Author            Date
%   2.00     Stephen France    04/01/2016
%   2.50     Stephen France    06/08/2017
tic
[n,m]=size(X);
P=+(X~=MissingVal);

%Find the observed values
Obs=0;Exp=0;
WObs=0;WExp=0;
for k=1:m
  SX=X(:,k);
  SP=P(:,k);
  Sqm=repmat(SX.^2,1,n);
  Prod = SX*SX';
  Dist=Sqm+Sqm'-2*Prod;
  OuterProd=SP*SP';
  Dist=Dist.*OuterProd;
  Obs=Obs+sum(sum(Dist));
  Exp=Exp+sum(sum(Dist)); %Expected incorporates observed
  AddWeight=sum(sum(OuterProd-diag(diag(OuterProd))));
  WObs=WObs+AddWeight;
  WExp=WExp+AddWeight;
  lRange=[1:k-1,k+1:m];
  for j=1:m-1
    l=lRange(j);
    SX2=X(:,l);
    SP2=P(:,l);
    Sqm2=repmat(SX2.^2,1,n); 
    Prod = SX*SX2';
    Dist=Sqm+Sqm2'-2*Prod;
    Dist=Dist-diag(diag(Dist));
    OuterProd=SP*SP2';
    Dist=Dist.*OuterProd;
    Exp=Exp+sum(sum(Dist));
    AddWeight=sum(sum(OuterProd-diag(diag(OuterProd))));
    WExp=WExp+AddWeight;
  end
end

Obs=Obs./WObs; %Normalize expected values
Exp=Exp./WExp;

Basic=1-Obs./Exp;

%Adjust the values for the competencies
X=X-Bias(:,1)*ones(1,m);
X=X./(Bias(:,2)*ones(1,m));

%Now need to weight for competencies and item difficulties.  Taking 
%outer product of these values gives a competency matrix

WeightIE=ones(n,1)*IE;
%Find the observed values
Obs=0;Exp=0;
WObs=0;WExp=0;
for k=1:m
  SX=X(:,k);
  SP=P(:,k);
  %Need to find products of weights
  Weight=(d*d').*(IE(k).^2);
  Sqm=repmat(SX.^2,1,n);
  Prod = SX*SX';
  Dist=Sqm+Sqm'-2*Prod;
  Dist=Dist-diag(diag(Dist));
  OuterProd=SP*SP';
  OuterProd=OuterProd.*Weight;
  Dist=Dist.*OuterProd;
  Obs=Obs+sum(sum(Dist));
  Exp=Exp+sum(sum(Dist)); %Expected incorporates observed


  AddWeight=sum(sum(OuterProd-diag(diag(OuterProd))));
  WObs=WObs+AddWeight;
  WExp=WExp+AddWeight;
  lRange=[1:k-1,k+1:m];
  for j=1:m-1
    l=lRange(j);
    SX2=X(:,l);
    SP2=P(:,l);
    Weight2=(d*d').*(IE(k).*IE(l));
    Sqm2=repmat(SX2.^2,1,n); 
    Prod = SX*SX2';
    Dist=Sqm+Sqm2'-2*Prod;
    Dist=Dist-diag(diag(Dist));
    OuterProd=SP*SP2';
    OuterProd=OuterProd.*Weight2;
    Dist=Dist.*OuterProd;
    Exp=Exp+sum(sum(Dist));

    AddWeight=sum(sum(OuterProd-diag(diag(OuterProd))));
    WExp=WExp+AddWeight;
  end
end

Obs=Obs./WObs; %Normalize expected values
Exp=Exp./WExp;

CCT=1-Obs./Exp;
timediff=toc
tic






