function [ConvergeFail,Cluster1IX,Cluster2IX,CurS,BinBlock] = SimConverge(X,Converge,MaxIter,SimParams,P)
%Given a set of data X, calculates a bipartate clustering of the rows.  Calculates
%a convergent series of similarity matrices and then extracts the indexes
%for the two clusters from the resulting bipartate [-1,1] matrix.
%INPUTS
%X - An n*m input matrix
%N - The number of clusters to be employed
%Converge - The convergence value for the similarity transforms
%MaxIter - The maximum number of iterations for the similarity transforms
%SimParms - Parameters for the similarity transformations. [3] gives
%cosine, and [1,3] gives correlation (see CalSimilarity for more details)
%P - An indicator matrix with 1 for present data and 0 for missing data
%OUTPUTS
%ConvergeFail - 0 if algorithm converges correctly
%               1 if algorithm has not converged by MaxIter
%Cluster1IX   - The indexes of the items in the first cluster
%Cluster2IX   - The indexes of the items in the second cluster
%CurS         - The final value of the similarity matrix
%BinBlock     - The bipartate blocked version of the similarity matrix
%Version 0.10 - Stephen France 05/26/2012

%Outputs
  [n,m]=size(X);

  if ~exist('P','var')
    P=ones(n,m);
  end
 
  ConvergeFail=0;
  ConvCheck=1;
  Iteration=1;
  [CurS] = CalcSimilarity(X,P,SimParams);
  P=ones(n,n);
  %Go through iterative similarity calculation until converges to matrix
  %with all entries -1 or 1.  After initial estimation, should be no
  %missing values
  while (ConvCheck>Converge)
    [CurS] = CalcSimilarity(CurS,P,SimParams);
    ConvCheck=max(max(abs(abs(CurS)-1))); 
    Iteration=Iteration+1;
    if (Iteration>MaxIter)
      ConvergeFail=1;
      OrderedIX=-1;
      return;
    end
  end

  CurS=round(CurS);
  %It is trivial to put the matrix into a [1,0;0,1] block model
  Cluster1IX=find(CurS(:,1)'==1);
  Cluster2IX=find(CurS(:,1)'==-1);
  %Produce the bipartite block matrix
  AllIX=[Cluster1IX,Cluster2IX];
  BinBlock=CurS(AllIX,AllIX);

end

