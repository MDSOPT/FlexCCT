function [NewClusters,TotalMax,Fail] = UpdateMaxCriterion2FC(Clusters,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,Fuzzyq,DPrior)
%UNTITLED3 Summary of this function goes here
%Detailed explanation goes here
  NewClusters=Clusters;
  %Update the clusters
  TotalMax=0;

  %NewClusters.OP3All=zeros(Clusters.NoUsers,1);
  NewClusters.zAll=zeros(Clusters.NoClusters,Clusters.NoQ);
  NewClusters.QEAll=zeros(Clusters.NoClusters,Clusters.NoQ);
  NewClusters.DAll=zeros(Clusters.NoUsers,Clusters.NoClusters);
  for i=1:Clusters.NoClusters
    [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCTWRPFC(Clusters.X,OptMethod,EstMethod,BiasType,FixParams,OptParams, ...
      MissingVal,DMax,IEMax,NewClusters.U(:,i),Fuzzyq,DPrior);
    NewClusters.D{i}=D;
    NewClusters.DAll(:,i)=D;
    NewClusters.z{i}=z;
    NewClusters.zAll(i,:)=z;
    NewClusters.Bias{i}=Bias;
    NewClusters.QE{i}=QE;
    NewClusters.QEAll(i,:)=QE;
    %NewClusters.OP3All(NewClusters.Indexes{i})=OP3;
    NewClusters.MaxCrit{i}=MaxCrit;
    %Total max criterion (calculate the total maximum criterion)
    %N.B. The maximum likelihood values 
    TotalMax=TotalMax+NewClusters.MaxCrit{i};
  end

  %Need biases for all users on all clusters for calculating the centroid
  [NewClusters] = CalcAllBiases(NewClusters,EstMethod,BiasType,FixParams,OptParams,DMax);  %Need the biases relative to the clusters

  %Huge penalty for a nan solution.  This means that in a clusterwise
  %solution there are items without any user reviews (N.B. Create future
  %routine to remove items that will give this!
  if isnan(TotalMax)
    TotalMax=-1e19;
    Fail=true;
  else
    Fail=false;
  end
  
end

