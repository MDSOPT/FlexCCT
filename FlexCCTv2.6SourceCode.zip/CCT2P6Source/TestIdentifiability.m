Runs=[];
NoOpt=20;
Mode=2;
FileName=strcat('C:\CCOut\CONCLUSV2\TestIdent',num2str(Mode),'.txt');

  for BiasMode=0:2
    Runs=[Runs;[0,BiasMode,0,0,0,0]];
  end
  for FixBias=0:2
    switch FixBias
      case 0
        Runs=[Runs;[0,3,0,0,0,0]];
      case 1
        Runs=[Runs;[0,3,0,0,1,0]];
      case 2
        Runs=[Runs;[0,3,0,0,0,1]];
    end
  end



for Technique=[2,4,5]
  for BiasMode=0:2
    for Fixz=-1:1
      for Fixd=-1:1
        Runs=[Runs;[Technique,BiasMode,Fixz,Fixd,0,0]];
      end
    end
  end
  for BiasMode=3:3
    for Fixz=-1:1
      for Fixd=-1:1
        for FixBias=0:2
          switch FixBias
            case 0
              Runs=[Runs;[Technique,BiasMode,Fixz,Fixd,0,0]];
            case 1
              Runs=[Runs;[Technique,BiasMode,Fixz,Fixd,1,0]];
            case 2
              Runs=[Runs;[Technique,BiasMode,Fixz,Fixd,0,1]];
          end
        end
      end
    end
  end
end

NoRuns=size(Runs,1);

for i=1:NoRuns
  i
  for j=1:NoOpt
    RRow=Runs(i,:);
    if Mode==1
      [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT4(X,RRow(1),RRow(2),[RRow(3),RRow(4),RRow(5),RRow(6)],[1e-6,1000,1],-1,5,5);
    else
      [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT3(X,RRow(1),RRow(2),[RRow(3),RRow(4),RRow(5),RRow(6)],[1e-6,1000,1],-1,1,5,5);
    end
    Solns.z{j}=z;
    Solns.D{j}=D;
    Solns.Bias{j}=Bias;
    Solns.QE{j}=QE;
    Solns.MaxCrit{j}=MaxCrit;
  end
  TotalNum=NoRuns*(NoRuns-1)/2;
  zDiff=0;zSum=0;
  DDiff=0;DSum=0;
  BiasDiff=0;BiasSum=0;
  QEDiff=0;QESum=0;
  MaxCritDiff=0;MaxCritSum=0;
  for j=1:NoOpt-1
    for k=j+1:NoOpt
      zDiff=zDiff+ssq(Solns.z{j}-Solns.z{k});
      DDiff=DDiff+ssq(Solns.D{j}-Solns.D{k});
      BiasDiff=BiasDiff+ssq(Solns.Bias{j}-Solns.Bias{k});
      if RRow(1)>2
        QEDiff=QEDiff+ssq(Solns.QE{j}-Solns.QE{k});
      end
      MaxCritDiff=MaxCritDiff+ssq(Solns.MaxCrit{j}-Solns.MaxCrit{k});
      zSum=zSum+ssq(Solns.z{j}+Solns.z{k});
      DSum=DSum+ssq(Solns.D{j}+Solns.D{k});
      BiasSum=BiasSum+ssq(Solns.Bias{j}+Solns.Bias{k});
      if RRow(1)>2
        QESum=QESum+ssq(Solns.QE{j}+Solns.QE{k});
      end
      MaxCritSum=MaxCritSum+ssq(Solns.MaxCrit{j}+Solns.MaxCrit{k});
    end
  end
  zDiff=zDiff/zSum;
  DDiff=DDiff/DSum;
  BiasDiff=BiasDiff/BiasSum;
  if RRow(1)>2
    QEDiff=QEDiff/QESum;
  else
    QEDiff=0;
  end
  MaxCritDiff=MaxCritDiff/MaxCritSum;
  Results=[RRow,zDiff,DDiff,BiasDiff,QEDiff,LLDiff,MaxCritDiff];
  save(FileName, '-ascii','-append', 'Results');
end
