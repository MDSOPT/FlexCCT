function [BestClusters,BestMax,C,ZAll,DAll,AddBiasAll,MultBiasAll,QEAll] = CWContinuousCCT(X,NoClusters,Initialize,CWOptMethod,CWOptParams,...
  OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior)
%Clusterwise continuous cultural consensus theory.  Follows Batchelder and Romney
%(1989), but assumes multiple cultures.  Starts with an initial clustering
%solution, then uses gradient descent to maximize the total fit (as
%measured by one factor fit in the factor analysis.
%The classical implementation of Cultural Consensus Theory as described
%in Batchelder and Romney (1988)
%Inputs 
%X - An n*m subject*item matrix
%NoClusters - The number of consensus clusters
%Initialize - 1 Choose a random starting configuration
%           - 2 Randomly select points and form aggregate clusters, as per
%           Steinley
%CWOptMethod  - Opt Method
%           - 1 is simulated annealing
%           - 2 is steepest descent 
%           - 3 is a local search with random neighborhoods
%           - 4 is a k-means variant
%           - 5 C-Means fuzzy clustering
%CWOptParams - For the genetic algorithm
%   1 MinItems - Minimum no. of items in one cluster
%   2 STemp - Starting temperature for the genetic algorithm
%   3 ETemp - The end temperature for the genetic algorithm
%   4 CTemp - The change in temperature for the genetic algorithm
%   5 TermIt - The number of iterations to termination
%            - For the steepet descent algorithm
%   1 MinItems - Minimum no. of items in one cluster
%   2 NoStarts - Number of random starts for the algorithm
%OptMethod
%            - For CCTMeans clustering
%  1- Minitems (the minimum number of items in a cluster
%  2- The number of random starts
%  3 - InitMethod 
%               1 Random points within range of data
%               2 Centroid of partiton
%  4 - MaxIter - The maximum number of iterations of the k-means
%
%OptMethod  - The inner continuous optimization method
%           - 0 Fixed point: Fixed point estimation.
%           - 1 Two Stage Fixed Point. (N.B. This gives same result as 0,
%           as parameter fixing now controlled by FixParams)
%           - 2 Derivative Free: Standard MATLAB routine.
%           - 3 Gradient: MATLAB Gradient descent optimization, utilizing first order derivatives
%EstMethod - The estimation method
%          - 0 Average value
%          - 1 Min Res factor analysis
%          - 2 Maximum likelihood estimation
%          - 3 Item difficulty model no 1 Additive Variances
%          - 4 Item difficulty model no 2 dij=alpha(i)*beta(j)
%          - 5 Item difficulty model no 3 dij=alpha(i)+beta(j)   
%          - 6 The Weber-Fechner model, where variance = zk^2/(d^p)
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          = 3 Fit both additive and multiplicative bias together
%          - 4 Fit a weighted additive bias
%FixParams - Fix parameters. A one by four array of items that contains
%          the following information.
%Fixz      - 0 Don't fix z at all
%          - -1 Fix z if an initial optimization run using EstMethod=2
%          - 1 Partial fix of z.  Fix for the average value
%FixD      - 0 Don't fix D at all
%          - -1 Fix D if an initial optimization run using EstMethod=2
%          - 1 Partial fix of D. Fix for the average value
%FixAddBias- 0 Don't fix the additive bias at all
%          - -1 Fix the additive bias first before calculating the
%          multiplicative bias
%          - 1 Partial fix of the additive bias.  Fix for the average value
%FixMultBias- 0 Don't fix the multiplicative bias at all
%          - -1 Fix the multiplicative bias first before calculating the
%          multiplicative bias
%          - 1 Partial fix of multiplicative bias.  Fix for the average
%          value
%OptParms  - A row vector containing the optimization parameters.  This
%vector consists of the following fields:
%       Coverge - The converge value (difference between successive f
%       values) (default 1e6)
%       MaxIter - The maximum number of iterations for the procedure
%       (default 1000)
%       InitialType - The scheme used for the initial solution
%           - 0 Use the values from the average solution and no initial
%           bias (e.g., bias of 0 for additive, 1 for multiplicative)
%           - 1 Generate initial values from uniform distribution.
%              If 0 then use starting solution.  If 1 then use 
%           - 2 Calculate sample posterior distribution (NOT YET
%           IMPLEMENTED)
%MissingVal - The indicator for a missing value boundary of max(abs-1)
%OptLevel   - 0 if use only function value
%           - 1 if use first order derivatives
%DMax      - The maximum value of D
%IEMax     - The maximum value of the item easiness IE
%DPrior    - Prior guess for value D
%
%Outputs
%Clusters - For each cluster give the following:
%-------------------------------------------------------------------------
%Count - The number of items in the cluster
%Indexes - The indexes of the items in the cluster
%Z   - A continuous m*1 answer key vector
%D   - An n*1 vector of competencies from initial estimation
%D2  - An n*1 vector of competencies after replacing diagonal with (D^2) and
%performing PCA.
%OP3 - The third output parameter, contigent on the estimation method
%    - if EstMethod=3 then = bz - A continuous m*1 scale varible 
%    - If EstMethod=4 then = Diff - A continuous m*1 vector of Rasch item
%      diffs.
%-------------------------------------------------------------------------
%Version     Author            Date
%   0.10     Stephen France    05/02/2012

[n,m]=size(X);
P=+~(X==MissingVal(1)); 

if CWOptParams(1)>round((n./NoClusters)+1);
  'Value of minimum items is too high.  Please reduce' 
  return
end

%Ensure that if not set, maximum parameter values are infinity (get around
%MATLAB's lack of overloading)
if ~exist('DMax','var')||isempty(DMax)==true
  DMax=inf;
end
if ~exist('IEMax','var')||isempty(IEMax)==true
  IEMax=inf;
end
if ~exist('DPrior','var')
  DPrior=-1;
end

%Now optimize the clusters
if CWOptMethod==1
  [Clusters,CIDX] = CWCCCTInitialize(X,P,NoClusters,Initialize);
  [BestClusters,BestMax]=CWContGenetic (Clusters,CWOptParams,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior);
else
  %Local search or Steepest descent, pick number of random starts
  NoStarts=CWOptParams(2);
  BestMax=-1e20;
  i=0;
  while i<NoStarts
    %Out=[EstMethod,Initialize,NoStarts]
    i;
    switch CWOptMethod
      case 2
      [InitialClusters,CIDX] = CWCCCTInitialize(X,P,NoClusters,Initialize); 
      %Steepest descent technique
      [Clusters,CurMax,Fail]=CWContSteepest (InitialClusters,CWOptParams(1),OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior);
      case 3
      %Standard local search technique
      [InitialClusters,CIDX] = CWCCCTInitialize(X,P,NoClusters,Initialize); 
      [Clusters,CurMax,Fail]=CWContLocal (InitialClusters,CWOptParams(1),OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior);
      case 4
      %k-consensus clustering
      [Clusters,CurMax,Fail]=CWkConsensus(X,NoClusters,CWOptParams,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior);    
      case 5
      [Clusters,CurMax,Fail]=CWkConsensusFC(X,NoClusters,CWOptParams,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior);    
    end
    if Fail
       NoStarts=NoStarts+1;
       Fail=1;
       if NoStarts>6
        Initialize=1;  %Go back to random initialization (and set results flag for failure)
       end
    else
      if CurMax>BestMax
        BestMax=CurMax;
        BestClusters=Clusters;
      end
    end
    i=i+1;
  end
end    

%Setup aggregate values
C=zeros(n,NoClusters);
ZAll=zeros(NoClusters,m);
QEAll=zeros(NoClusters,m);


%Assignments are not valid for fuzzy clustering, as every item is a member
%of every type of cluster
if CWOptMethod~=5
  %Create a single assignments vector
  BestClusters.Assignments=zeros(n,1);
  for i=1:NoClusters
    %Calculate aggregate values for cluster
    try
  %   Remove 10/13/2013 - Duplicate as these values are included in the
  %   cluster definition
  %   ZAll(i,:)=BestClusters.z{i};
  %   D(BestClusters.Indexes{i})=BestClusters.D{i};
  %   Bias(BestClusters.Indexes{i},:)=BestClusters.Bias{i};
  %   QEAll(i,:)=BestClusters.QE{i};
    C(BestClusters.Indexes{i},i)=1;
    BestClusters.Assignments(BestClusters.Indexes{i})=i;
    catch error
      %a=1;
    end
  end
end

%Setup the output summary shortcuts
ZAll=BestClusters.zAll;
DAll=BestClusters.DAll;
AddBiasAll=BestClusters.AddBiasAll;
MultBiasAll=BestClusters.MultBiasAll;
QEAll=BestClusters.QEAll;

end


