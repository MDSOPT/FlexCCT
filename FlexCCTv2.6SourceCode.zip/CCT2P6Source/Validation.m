function varargout = Validation(varargin)
% VALIDATION MATLAB code for validation.fig
%      VALIDATION, by itself, creates a new VALIDATION or raises the existing
%      singleton*.
%
%      H = VALIDATION returns the handle to a new VALIDATION or the handle to
%      the existing singleton*.
%
%      VALIDATION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VALIDATION.M with the given input arguments.
%
%      VALIDATION('Property','Value',...) creates a new VALIDATION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Validation_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Validation_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help validation

% Last Modified by GUIDE v2.5 20-Jun-2017 01:23:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Validation_OpeningFcn, ...
                   'gui_OutputFcn',  @Validation_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before validation is made visible.
function Validation_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to validation (see VARARGIN)

% Choose default command line output for validation
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

set(hObject ,'WindowStyle','modal');
javaFrame = get(handle(hObject),'JavaFrame');
javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
% UIWAIT makes validation wait for user response (see UIRESUME)
% uiwait(handles.validation);

%Competencies dependent on estimation type
GUIEstMethod=getappdata(0,'EstMethod');

%Can always do holdout validation on z.
set(handles.chkHOz,'Value',getappdata(0,'HOz'));
set(handles.chkHOz,'Enable','on');
% if (GUIEstMethod==2)
%   set(handles.chkHOXPred,'Value',0);
%   set(handles.chkHOXPred,'Enable','off');
% else
  set(handles.chkHOXPred,'Value',getappdata(0,'HOXPred'));
  set(handles.chkHOXPred,'Enable','on');   
% end
if (GUIEstMethod==1)||((GUIEstMethod==2))
  set(handles.chkHOd,'Value',0);
  set(handles.chkHOd,'Enable','off');
else
  set(handles.chkHOd,'Value',getappdata(0,'HOd'));
  set(handles.chkHOd,'Enable','on');
end
%Check for availability of biases
GUIBiasType=getappdata(0,'BiasType');
%Additive bias
if (GUIBiasType==1)||((GUIBiasType==3))
  set(handles.chkHObA,'Value',0)
  %Disable the bias controls
  set(handles.chkHObA,'Enable','off')
else
  set(handles.chkHObA,'Value',getappdata(0,'HObA'));
  %Enable the bias controls
  set(handles.chkHObA,'Enable','on')
end

%Multiplicative bias
if (GUIBiasType==1)||((GUIBiasType==2))
  set(handles.chkHObM,'Value',0)
   %Disable the bias controls
  set(handles.chkHObM,'Enable','off')
else
  set(handles.chkHObM,'Value',getappdata(0,'HObM'));
  %Enable the bias controls
  set(handles.chkHObM,'Enable','on')
end

%Item easiness only if estimation type is 4 or 5
%Multiplicative bias
if (GUIEstMethod<4)
  set(handles.chkHOIE,'Value',0)
  set(handles.chkHOIE,'Enable','off')
else
  set(handles.chkHOIE,'Value',getappdata(0,'HOIE'));
  set(handles.chkHOIE,'Enable','on')
end

set(handles.txtNoHoldout,'String',getappdata(0,'NoHoldout'));
set(handles.txtMaxRuns,'String',getappdata(0,'MaxRuns'));

set(handles.chkMSE,'Value',getappdata(0,'MSE'));
set(handles.chkMSPE,'Value',getappdata(0,'MSPE'));
set(handles.chkMAE,'Value',getappdata(0,'MAE'));
set(handles.chkMAPE,'Value',getappdata(0,'MAPE'));
set(handles.chkCorrel,'Value',getappdata(0,'Correl'));

if (getappdata(0,'HasGroundTruth')==true)
  set(handles.chkRunGroundTruth,'Enable','on')
  set(handles.chkRunGroundTruth,'Value',getappdata(0,'RunGroundTruth'));
else
  set(handles.chkRunGroundTruth,'Enable','off')
end
set(handles.cmdSave,'Enable','off')

%If a file is available, set the number of items available.  Otherwise
%leave as N\A or not available
if (getappdata(0,'HasFile')==1);
  set(handles.lblNoRatersValue,'String',getappdata(0,'NoRaters'));
  set(handles.lblNoItemsValue,'String',getappdata(0,'NoItems'));
  set(handles.lblNoRatingsValue,'String',getappdata(0,'NoRatings'));
end



% --- Outputs from this function are returned to the command line.
function varargout = Validation_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in chkHOz.
function chkHOz_Callback(hObject, eventdata, handles)
% hObject    handle to chkHOz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkHOz
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes on button press in chkHOd.
function chkHOd_Callback(hObject, eventdata, handles)
% hObject    handle to chkHOd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkHOd
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes on button press in chkHObA.
function chkHObA_Callback(hObject, eventdata, handles)
% hObject    handle to chkHObA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkHObA
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes on button press in chkHObM.
function chkHObM_Callback(hObject, eventdata, handles)
% hObject    handle to chkHObM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkHObM
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes on button press in chkHOIE.
function chkHOIE_Callback(hObject, eventdata, handles)
% hObject    handle to chkHOIE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkHOIE
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end




function txtNoHoldout_Callback(hObject, eventdata, handles)
% hObject    handle to txtNoHoldout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtNoHoldout as text
%        str2double(get(hObject,'String')) returns contents of txtNoHoldout as a double
NoHoldout=str2double(get(handles.txtNoHoldout,'string'));
%if the value is less than or equal to zero or not a number change it to default one 
if NoHoldout>=1
  %do nothing unless not integer
  RoundNoHoldout=round(NoHoldout);
  if RoundNoHoldout~=NoHoldout
    set(handles.txtNoHoldout,'string',RoundNoHoldout);
  end
else
    set(handles.txtNoHoldout,'string',1);
end
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes during object creation, after setting all properties.
function txtNoHoldout_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtNoHoldout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in chkMSE.
function chkMSE_Callback(hObject, eventdata, handles)
% hObject    handle to chkMSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkMSE
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes on button press in chkMSPE.
function chkMSPE_Callback(hObject, eventdata, handles)
% hObject    handle to chkMSPE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkMSPE
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes on button press in cmdDefault.
function cmdDefault_Callback(hObject, eventdata, handles)
% hObject    handle to cmdDefault (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = MFquestdlg([0.3,0.5],'Are you sure that you would like to return to default settings?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes',
set(handles.chkHOz,'Value',0);
set(handles.chkHOd,'Value',0);
set(handles.chkHObA,'Value',0);
set(handles.chkHObM,'Value',0);
set(handles.chkHOIE,'Value',0);
set(handles.chkHOXPred,'Value',0);
set(handles.txtNoHoldout,'string','1');
set(handles.chkMSE,'Value',0);
set(handles.chkMSPE,'Value',0);
set(handles.chkMAE,'Value',0);
set(handles.chkMAPE,'Value',0);
set(handles.chkCorrel,'Value',0);

set(handles.chkRunGroundTruth,'Value',0);

cmdSave_Callback(hObject, eventdata, handles);
set(handles.cmdSave,'Enable','off');
case 'No'
return
end %switch


% --- Executes on button press in cmdSave.
function cmdSave_Callback(hObject, eventdata, handles)
% hObject    handle to cmdSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

setappdata(0,'HOz',get(handles.chkHOz,'Value'));
setappdata(0,'HOd',get(handles.chkHOd,'Value'));
setappdata(0,'HObA',get(handles.chkHObA,'Value'));
setappdata(0,'HObM',get(handles.chkHObM,'Value'));
setappdata(0,'HOIE',get(handles.chkHOIE,'Value'));
setappdata(0,'HOXPred',get(handles.chkHOXPred,'Value'));
setappdata(0,'NoHoldout',get(handles.txtNoHoldout,'String'));
setappdata(0,'MaxRuns',get(handles.txtMaxRuns,'String'));

%Save the reporting details
setappdata(0,'MSE',get(handles.chkMSE,'Value'));
setappdata(0,'MSPE',get(handles.chkMSPE,'Value'));
setappdata(0,'MAE',get(handles.chkMAE,'Value'));
setappdata(0,'MAPE',get(handles.chkMAPE,'Value'));
setappdata(0,'Correl',get(handles.chkCorrel,'Value'));

setappdata(0,'RunGroundTruth',get(handles.chkRunGroundTruth,'Value'));

set(handles.cmdSave,'Enable','off')

% --- Executes on button press in chkMAPE.
function chkMAPE_Callback(hObject, eventdata, handles)
% hObject    handle to chkMAPE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkMAPE
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes on button press in chkMAE.
function chkMAE_Callback(hObject, eventdata, handles)
% hObject    handle to chkMAE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkMAE
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end


% --- Executes when user attempts to close validation.
function Validation_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to validation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
selection = MFquestdlg([0.3,0.5],'Are you sure that you would like to close the Validation settings form?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes',
delete(hObject);
case 'No'
return
end %switch



function txtMaxRuns_Callback(hObject, eventdata, handles)
% hObject    handle to txtMaxRuns (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtMaxRuns as text
%        str2double(get(hObject,'String')) returns contents of txtMaxRuns as a double
% Hints: get(hObject,'String') returns contents of txtNoHoldout as text
%        str2double(get(hObject,'String')) returns contents of txtNoHoldout as a double
MaxRuns=str2double(get(handles.txtMaxRuns,'string'));
%if the value is less than or equal to zero or not a number change it to default one 
if MaxRuns>=1
  %do nothing unless not integer
  RoundMaxRuns=round(MaxRuns);
  if RoundMaxRuns~=MaxRuns
    set(handles.txtMaxRuns,'string',RoundMaxRuns);
  end
else
  %The default value for the maximum number of runs is 10000 
  set(handles.txtMaxRuns,'string',100000);
end
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end

% --- Executes during object creation, after setting all properties.
function txtMaxRuns_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtMaxRuns (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chkCorrel.
function chkCorrel_Callback(hObject, eventdata, handles)
% hObject    handle to chkCorrel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkCorrel
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end


% --- Executes during object creation, after setting all properties.
function lblNoRatersValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lblNoRatersValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in chkRunGroundTruth.
function chkRunGroundTruth_Callback(hObject, eventdata, handles)
% hObject    handle to chkRunGroundTruth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkRunGroundTruth
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end


% --- Executes during object creation, after setting all properties.
function Validation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to validation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in chkHOXPred.
function chkHOXPred_Callback(hObject, eventdata, handles)
% hObject    handle to chkHOXPred (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmp(get(handles.cmdSave,'Enable'),'off')==1
  set(handles.cmdSave,'Enable','on')
end
% Hint: get(hObject,'Value') returns toggle state of chkHOXPred
