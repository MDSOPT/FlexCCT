function [IsMissing2,AllAssigned] = FixMissing(IsMissing,MaxIter)
%A utility function to ensure that for a missing data indicator matrix, every row
%and every column has at least one entry that is not missing.
%INPUTS
%IsMissing - An n*m binary matrix with 1+ if data is missing and 0 if data
%            is not missing
%MaxIter   - The maximum number of iterations before giving up
%OUTPUTS
%IsMissing2 - The updated matrix
%Version 0.10 - Stephen France 08/01/2012

IsMissing2=IsMissing;
AllAssigned=true;
[n,m]=size(IsMissing2);

ColIndexes=find(ones(1,m));
RowIndexes=find(ones(n,1));
Fail=1;
Cols=[];Rows=[];ColFail=[];RowFail=[];
CurIter=0;

while Fail
  ColCount=size(ColFail,2);
  RowCount=size(RowFail,1);

  %Find the rows and columns with the most items
  ColOrder=sortrows([Cols;ColIndexes]',-1);
  RowOrder=sortrows([Rows,RowIndexes],-1);
  
  if mod(CurIter,2)==1
    for i=1:ColCount
      %Add item randomly to column without entries.  Remove item
      %from columns with most entries
      AddCol=ColFail(i);
      RemoveCol=ColOrder(i,:);
      if RemoveCol(1)>1  %Makes no sense to remove from column with only one entry
        AddRows=find(IsMissing2(:,AddCol)==1);
        AddCount=size(AddRows,1);
        AddRow=AddRows(floor(rand()*AddCount)+1);
        IsMissing2(AddRow,AddCol)=0;
        RemoveRows=find(IsMissing2(:,RemoveCol(2))==0);
        RemoveCount=size(RemoveRows,1);
        RemoveRow=RemoveRows(floor(rand()*RemoveCount)+1);
        IsMissing2(RemoveRow,RemoveCol(2))=1;
      end
    end
  else
    for i=1:RowCount
      %Add item randomly to row without entries.  Remove item
      %from rows with most entries
      AddRow=RowFail(i);
      RemoveRow=RowOrder(i,:);
      if RemoveRow(1)>1  %Makes no sense to remove from column with only one entry
        AddCols=find(IsMissing2(AddRow,:)==1);
        AddCount=size(AddCols,2);
        AddCol=AddCols(floor(rand()*AddCount)+1);
        IsMissing2(AddRow,AddCol)=0;
        IsMissing2(AddRow,floor(rand()*m)+1)=0;
        RemoveCols=find(IsMissing2(RemoveRow(2),:)==0);
        RemoveCount=size(RemoveCols,2);
        RemoveCol=RemoveCols(floor(rand()*RemoveCount)+1);
        IsMissing2(RemoveRow(2),RemoveCol)=1;
      end
    end
  end
  %Reset the columns and the rows
  Cols=sum(1-IsMissing2,1);
  Rows=sum(1-IsMissing2,2);
  ColFail=find(Cols<2);
  RowFail=find(Rows<2);
  Fail=~(isempty(ColFail)&&isempty(RowFail));
  if (CurIter==MaxIter)
    Fail=0;
    AllAssigned=false;
  end
  CurIter=CurIter+1;
end

