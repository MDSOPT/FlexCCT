function [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCTWRPFC(X,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,FuzzyU,Fuzzyq,DPrior)
%A wrapper for continuous CCT for fuzzy clustering.  See ContinuousCCT4FC for a
%full description of parameters.  
%Version     Author            Date
%   0.10     Stephen France    08/31/2013
%   2.00     Stephen France    03/31/2016

%   Detailed explanation goes here
  switch OptMethod
    case {0,1}
	  %Fixed Point Optimization
      if DPrior==-1
        [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT4FC(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,FuzzyU,Fuzzyq);
      else
        [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT4FC(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,FuzzyU,Fuzzyq,DPrior);
      end
    case 2
      %Not currently implemented, so raise error
      throw(MException('FuzzyCluster:NotImplemented', 'Currently, only fixed point optimization is implemented for fuzzy clustering'));

%       if DPrior==-1
%         [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT3FC(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,0,DMax,IEMax,FuzzyU,Fuzzyq);
%       else
%         [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT3FC(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,0,DMax,IEMax,FuzzyU,Fuzzyq,DPrior);
%       end
    case 3
      %Not currently implemented, so raise error
      throw(MException('FuzzyCluster:NotImplemented', 'Currently, only fixed point optimization is implemented for fuzzy clustering'));
%       if DPrior==-1
%         [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT4FC(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,1,DMax,IEMax);
%       else
%         [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT4FC(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,1,DMax,IEMax,DPrior);
%       end
      
  end


end

