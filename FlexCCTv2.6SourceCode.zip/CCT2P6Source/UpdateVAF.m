function [NewClusters,AverageVAF,NewBestf] = UpdateVAF(Clusters,DPenalty,Bestf,FactorOptMethod,OptLevel)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
  NewClusters=Clusters;
 %Update the clusters
 Penalty=0;
 for i=1:Clusters.NoClusters
   Clusters.UMatrix{i}=Clusters.UserMatrix(Clusters.Indexes{i},Clusters.Indexes{i});
   switch FactorOptMethod
   case 0
    [D,Resid]= PrincipalAxesFA(Clusters.UMatrix{i},1e-5,1);
   case 1
    [D,Resid] = ResidualFA(Clusters.UMatrix{i},1,1e-5);
   case 2
    if ~exist('OptLevel','var')
      OptLevel=0; %Default to non-gradient optimization
    end   
   [D,Resid] = ResidualFA2(Clusters.UMatrix{i},1,OptLevel,1e-5);
   end
   Clusters.D{i}=D; 
   Penalty=sum(D<0).*DPenalty;
   Clusters.Resid{i}=Resid;
   Clusters.Mean{i}=mean(mean(Clusters.UMatrix{i}));
   Clusters.VAF{i}=1-(ssq(Resid)./ssq(Clusters.UMatrix{i}-Clusters.Mean{i}));
 end
  
  
  AverageVAF=0;
  for i=1:Clusters.NoClusters
    AverageVAF=AverageVAF+Clusters.VAF{i}.*Clusters.Count{i};
  end
  AverageVAF=AverageVAF./Clusters.UserCount;
  AverageVAF=AverageVAF-Penalty;
  
  if AverageVAF>Bestf
    NewBestf=AverageVAF;
    %Store the current configuration in the NoClusters+1 to 2*NoClusters
    for i=1:Clusters.NoClusters
      NewClusters.Indexes{Clusters.NoClusters+i}=Clusters.Indexes{i};
      NewClusters.Count{Clusters.NoClusters+i}=Clusters.Count{i};
      NewClusters.UMatrix{Clusters.NoClusters+i}=Clusters.UMatrix{i};
      NewClusters.D{Clusters.NoClusters+i}=Clusters.D{i}; 
      NewClusters.Resid{Clusters.NoClusters+i}=Clusters.Resid{i};
      NewClusters.Mean{Clusters.NoClusters+i}=Clusters.Mean{i};
      NewClusters.VAF{Clusters.NoClusters+i}=Clusters.VAF{i};
    end
  else
    NewBestf=Bestf;
  end 
  
end

