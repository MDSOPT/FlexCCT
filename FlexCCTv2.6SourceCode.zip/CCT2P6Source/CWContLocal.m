function [Clusters,f,Fail]=CWContLocal(InitialClusters,MinItems,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior)
%A local descent algorithm for optimizing the clusterwise continuous 
%cultural consensus model .  Takes a set of clusters and then optimizes 
%these clusters to maximize the total maximum likelihood function.
%At each stage, iterates through a set of possible moves and chooses the
%first move that reduces the objective function
%Inputs
%InitialClusters - See header for CWCContinuousCCT.m for description
%MinItems - The minimum number of items allowed in a cluster
%OptMethod  - The inner continuous optimization method
%           - 0 Fixed point: Fixed point estimation.
%           - 1 Two Stage Fixed Point. (N.B. This gives same result as 0,
%           as parameter fixing now controlled by FixParams)
%           - 2 Derivative Free: Standard MATLAB routine.
%           - 3 Gradient: MATLAB Gradient descent optimization, utilizing first order derivatives
%EstMethod - The estimation method
%          - 0 Average value
%          - 1 Min Res factor analysis
%          - 2 Maximum likelihood estimation
%          - 3 Item difficulty model no 1 Additive Variances
%          - 4 Item difficulty model no 2 dij=alpha(i)*beta(j)
%          - 5 Item difficulty model no 3 dij=alpha(i)+beta(j)   
%          - 6 The Weber-Fechner model, where variance = zk^2/(d^p)
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          = 3 Fit both additive and multiplicative bias together
%FixParams - Fix parameters. A one by four array of items that contains
%          the following information.
%Fixz      - 0 Don't fix z at all
%          - -1 Fix z if an initial optimization run using EstMethod=2
%          - 1 Partial fix of z.  Fix for the average value
%FixD      - 0 Don't fix D at all
%          - -1 Fix D if an initial optimization run using EstMethod=2
%          - 1 Partial fix of D. Fix for the average value
%FixAddBias- 0 Don't fix the additive bias at all
%          - -1 Fix the additive bias first before calculating the
%          multiplicative bias
%          - 1 Partial fix of the additive bias.  Fix for the average value
%FixMultBias- 0 Don't fix the multiplicative bias at all
%          - -1 Fix the multiplicative bias first before calculating the
%          multiplicative bias
%          - 1 Partial fix of multiplicative bias.  Fix for the average
%          value
%OptParms  - A row vector containing the optimization parameters.  This
%vector consists of the following fields:
%       Coverge - The converge value (difference between successive f
%       values) (default 1e6)
%       MaxIter - The maximum number of iterations for the procedure
%       (default 1000)
%       InitialType - The scheme used for the initial solution
%           - 0 Use the values from the average solution and no initial
%           bias (e.g., bias of 0 for additive, 1 for multiplicative)
%           - 1 Generate initial values from uniform distribution.
%              If 0 then use starting solution.  If 1 then use 
%           - 2 Calculate sample posterior distribution (NOT YET
%           IMPLEMENTED)
%MissingVal - The indicator for a missing value boundary of max(abs-1)
%DMax      - The maximum value of D
%IEMax     - The maximum value of the item easiness IE
%DPrior    - Prior guess for value D
%Outputs
%BestClusters - See header for CWClassicalCCT.m for description.
%fBest - The optimial value of the likelihood function
%-------------------------------------------------------------------------
%Version     Author            Date
%   0.10     Stephen France    08/07/2012

  Debug=[];
  
  %Shorthand for the count variables
  n=InitialClusters.UserCount;
  m=InitialClusters.QCount;
  NoClusters=InitialClusters.NoClusters;

  %Calculate initial f
  fOld=-1e19;
  [Clusters,f,fBest]=UpdateMaxCriterion(InitialClusters,fOld,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior); 
    
  %Define as item and a cluster shift (1-(NoClusters-1))
  MoveCount=n*(NoClusters-1);
  Moves=zeros(MoveCount,2);
  Indexes=find(ones(n,1));
  Assignments=zeros(n,1);
  for i=1:NoClusters-1
    Moves(1+(i-1)*n:i*n,:)=[Indexes,ones(n,1).*i];
    %Set the cluster assignments
    Assignments(Clusters.Indexes{i})=i;
  end
  Assignments(Clusters.Indexes{NoClusters})=NoClusters;
  %Iter=0;
  FoundChange=true;
  while (FoundChange==true)
    %Iter=Iter+1;
    FoundChange=false;   %Assume a negative change in -max LL
    %Go through all possible (randomized) moves until improvement is found.  In total n*(k-1) moves as each item
    %can be moved to any one of the other clusters
    RandMoves=Moves(randperm(n*(NoClusters-1)),:);
    MoveCounter=0;
    while (FoundChange==false)&&(MoveCounter<MoveCount)
      MoveCounter=MoveCounter+1;
      %Create the new test clusters
      TClusters=Clusters;
      ChangeIndex=RandMoves(MoveCounter,1);
      %Find the index
      try
      Clusi=Assignments(ChangeIndex);
      catch
        bb=0
      end
      if Clusters.Count{Clusi}>MinItems
        RemoveIndex=find(Clusters.Indexes{Clusi}==ChangeIndex);
        %New cluster is cluster + (circular) cluster shift
        Clusj=Clusi+RandMoves(i,2)-(+(Clusi+RandMoves(i,2)>NoClusters)).*NoClusters;
        switch RemoveIndex
          case 1
            TClusters.Indexes{Clusi}=TClusters.Indexes{Clusi}(2:TClusters.Count{Clusi});
          case TClusters.Count{Clusi}
            TClusters.Indexes{Clusi}=TClusters.Indexes{Clusi}(1:TClusters.Count{Clusi}-1);
          otherwise
            TClusters.Indexes{Clusi}=[TClusters.Indexes{Clusi}(1:RemoveIndex-1),TClusters.Indexes{Clusi}(RemoveIndex+1:TClusters.Count{Clusi})];
        end
        TClusters.Count{Clusi}=TClusters.Count{Clusi}-1;
        TClusters.SX{Clusi}=TClusters.X(TClusters.Indexes{Clusi},:);
        %Add to the cluster j
        TClusters.Indexes{Clusj}=sort([TClusters.Indexes{Clusj},ChangeIndex]);
        TClusters.Count{Clusj}=TClusters.Count{Clusj}+1;
        TClusters.SX{Clusj}=TClusters.X(TClusters.Indexes{Clusj},:);
        %Find the new function value
        fNew=0;
        for i=1:Clusters.NoClusters
          [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCTWRP(TClusters.SX{i},OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior);
          TClusters.D{i}=D; 
          TClusters.z{i}=z; 
          TClusters.Bias{i}=Bias;
          TClusters.QE{i}=QE;
          TClusters.MaxCrit{i}=MaxCrit;
          %Total max criterion (calculate the total maximum criterion)
          %N.B. The maximum likelihood values 
          fNew=fNew+TClusters.MaxCrit{i};
        end
        TChange=f-fNew;  %Convert to minimization problem
        if TChange<0
          Clusters=TClusters;
          f=fNew;
          Assignments(ChangeIndex)=Clusj;
          FoundChange=true;
        end
      end
    end
  end
  
  [Clusters,f,fBest,Fail]=UpdateMaxCriterion(Clusters,fOld,OptMethod,EstMethod,BiasType,FixParams,OptParams,MissingVal,DMax,IEMax,DPrior); 

end

