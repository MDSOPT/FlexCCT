function [Basic,CCT] = CCTReliabilityAdd3(X,MissingVal,d,Bias,IE)
%Reliability for continuous cultural consensus analysis.  This procedure
%returns the continuous reliability metric iota, as defined by Janson and Olson (2001)
%and also the consensus adjusted reliability metric, as defined by France
%and Batchelder.  Works specifically for the additive item easiness model
%INPUTS
%X - The n user*m item matrix of ratings
%d   - An n*1 vector of user competencies
%Bias - An n*2 vecttor of biases (1st column additive, 2nd column multiplicative)
%IE   - A continuous m*1 answer key vector
%OUTPUTS
%Basic - The Basic reliability coefficient
%CCT - The CCT reliability coefficient, incorporating competency, bias, and item easiness
%Version     Author            Date
%   2.00     Stephen France    04/01/2016

[n,m]=size(X);
P=+(X~=MissingVal);

%Find the observed values
Sqm=((X.^2).*P)*(P');
Dist=Sqm+Sqm'-2*(X.*P)*((X.*P)');
Obs=sum(sum(Dist));
Exp=Obs; %Expected incorporates observed
Prod=P*P';
ObsW=sum(sum(Prod-diag(diag(Prod))));
ExpW=ObsW;
 %(m*n*(n-1)); %Normalize expected values

%Go through for expected, iterating one column at a time
for i=1:m-1
 X2=[X(:,m-i+1:m),X(:,1:m-i)];
 P2=[P(:,m-i+1:m),P(:,1:m-i)];
 Sqm=((X.^2).*P)*(P2');
 Sqm2=((X2.^2).*P2)*(P');  
 Dist=Sqm+Sqm2'-2*(X.*P)*((X2.*P2)');
 Dist=Dist-diag(diag(Dist));
 Exp=Exp+sum(sum(Dist));
 Prod=P*P2';
 ExpW=ExpW+sum(sum(Prod-diag(diag(Prod))));
end
Obs=Obs./ObsW;  
Exp=Exp./ExpW;

Basic=1-Obs./Exp;

%Adjust the values for the competencies
X=X-Bias(:,1)*ones(1,m);
X=X./(Bias(:,2)*ones(1,m));

%Now need to weight for competencies and item difficulties.  Taking 
%outer product of these values gives a competency matrix
Weightdidj=(d*ones(1,n)).*((d*ones(1,n))');
Weightdi=(d*ones(1,n));
Weightdj=(d*ones(1,n))';
WeightIE=ones(n,1)*IE;

%Calculate basic with no additive item easiness weights.
Sqm=((X.^2).*P)*(P');
SqmW=((X.^2).*WeightIE.*P)*(P');
SqmW2=((X.^2).*(WeightIE.^2).*P)*(P');

%Calculate the distannce components from
%(di+bk)(dk+bl)(xik^2+xjl^2-2xikxjl)
Distdidj=Weightdidj.*(Sqm+Sqm'-2*(X.*P)*((X.*P)'));
DistdiBl=Weightdi.*(SqmW+SqmW'-2*(X.*P)*(((X.*P).*WeightIE)'));
DistdjBk=Weightdj.*(SqmW+SqmW'-2*((X.*P).*WeightIE)*((X.*P)'));
DistdjBk2=SqmW2+SqmW2'-2*((X.*P).*WeightIE)*(((X.*P).*WeightIE)');
Dist=Distdidj+DistdiBl+DistdjBk+DistdjBk2;
Dist=Dist-diag(diag(Dist));

%Weights are sum of (di+bk)(dk+bl)
WeightAll=(d*ones(1,m))+(ones(n,1)*IE);
TotalWeight=WeightAll*WeightAll';
TotalWeight=TotalWeight-diag(diag(TotalWeight));
Obs=sum(sum(Dist));
Exp=Obs; %Expected incorporates observed
ObsW=sum(sum(TotalWeight));
ExpW=ObsW;

%Go through for expected, iterating one column at a time
for i=1:m-1
  X2=[X(:,m-i+1:m),X(:,1:m-i)];
  P2=[P(:,m-i+1:m),P(:,1:m-i)];
  IE2=[IE(m-i+1:m),IE(1:m-i)];
  WeightIE2=ones(n,1)*IE2;
  %didj term sums of X^2
  Sqm=((X.^2).*P)*(P2');
  Sqm2=((X2.^2).*P2)*(P');
  %Sums of X^2 Weights for k
  SqmWk=((X.^2).*WeightIE.*P)*(P2');
  Sqm2Wk=((X2.^2).*WeightIE.*P2)*(P');
  %Sums of X^2 Weights for l
  SqmWl=((X.^2).*WeightIE2.*P)*(P2');
  Sqm2Wl=((X2.^2).*WeightIE2.*P2)*(P');
  %Sums of X^2 Weights for k and l
  SqmW2=((X.^2).*(WeightIE).*(WeightIE2).*P)*(P2');
  Sqm2W2=((X2.^2).*(WeightIE).*(WeightIE2).*P2)*(P');
  %Calculate the distannce components from
 %(di+bk)(dk+bl)(xik^2+xjl^2-2xikxjl)
  Distdidj=Weightdidj.*(Sqm+Sqm2'-2*(X.*P)*((X2.*P2)'));
  DistdiBl=Weightdi.*(SqmWl+Sqm2Wl'-2*(X.*P)*((X2.*P2.*WeightIE2)'));
  DistdjBk=Weightdj.*(SqmWk+Sqm2Wk'-2*(X.*P.*WeightIE)*((X2.*P2)'));
  DistBkBl=SqmW2+Sqm2W2'-2*(X.*P.*WeightIE)*((X2.*P2.*WeightIE2)');  
  
  Dist=Distdidj+DistdiBl+DistdjBk+DistBkBl;
  Dist=Dist-diag(diag(Dist));
  WeightAll=(d*ones(1,m))+(ones(n,1)*IE);
  WeightAll2=(d*ones(1,m))+(ones(n,1)*IE2);
  TotalWeight=WeightAll*WeightAll2';
  TotalWeight=TotalWeight-diag(diag(TotalWeight));
  Exp=Exp+sum(sum(Dist));
  ExpW=ExpW+sum(sum(TotalWeight));
end
Obs=Obs/ObsW;
Exp=Exp./ExpW;

CCT=1-Obs./Exp;





