function [Basic,CCT] = CCTReliability(X,d,Bias,IE)
%Reliability for continuous cultural consensus analysis.  This procedure
%returns the continuous reliability metric iota, as defined by Janson and Olson (2001)
%and also the consensus adjusted reliability metric, as defined by France
%and Batchelder.  Works for all models except for the additive item easiness model
%INPUTS
%X - The n user*m item matrix of ratings
%d   - An n*1 vector of user competencies
%Bias - An n*2 vecttor of biases (1st column additive, 2nd column multiplicative)
%IE   - A continuous m*1 answer key vector
%OUTPUTS
%Basic - The Basic reliability coefficient
%CCT - The CCT reliability coefficient, incorporating competency, bias, and item easiness
%Version     Author            Date
%   2.00     Stephen France    04/01/2016

[n,m]=size(X);

%Find the observed values
Sqm=repmat(sum(X.^2,2),1,n);
Dist=Sqm+Sqm'-2*(X)*(X');
Obs=sum(sum(Dist));
Exp=Obs; %Expected incorporates observed
Obs=Obs./(m*n*(n-1)); %Normalize expected values

%Go through for expected, iterating one column at a time
for i=1:m-1
 X2=[X(:,m-i+1:m),X(:,1:m-i)];
 Sqm2=repmat(sum(X2.^2,2),1,n);  
 Dist=Sqm+Sqm2'-2*(X)*(X2');
 Dist=Dist-diag(diag(Dist));
 Exp=Exp+sum(sum(Dist));
end
Exp=Exp./(m*m*n*(n-1));

Basic=1-Obs./Exp;

%Adjust the values for the competencies
X=X-Bias(:,1)*ones(1,m);
X=X./(Bias(:,2)*ones(1,m));

%Now need to weight for competencies and item difficulties.  Taking 
%outer product of these values gives a competency matrix
Weightd=(d*ones(1,n)).*((d*ones(1,n))');
WeightIE=ones(n,1)*IE;
Sqm=repmat(sum((X.^2).*(WeightIE.^2),2),1,n);
Dist=Sqm+Sqm'-2*(X.*WeightIE)*((X.*WeightIE)');
Dist=Weightd.*Dist;
WeightAll=(d*ones(1,m)).*(WeightIE);
TotalWeight=WeightAll*WeightAll';
TotalWeight=TotalWeight-diag(diag(TotalWeight));
Obs=sum(sum(Dist));
SumW=sum(sum(TotalWeight));
Obs=Obs/SumW;


%Go through for expected, iterating one column at a time
Exp=0;ExpW=0;
for i=1:m
  X2=[X(:,m-i+1:m),X(:,1:m-i)];
  IE2=[IE(m-i+1:m),IE(1:m-i)];
  WeightIE2=ones(n,1)*IE2;
  Sqm=repmat(sum((X.^2).*(WeightIE.*WeightIE2),2),1,n);
  Sqm2=repmat(sum((X2.^2).*(WeightIE.*WeightIE2),2),1,n);  
  Dist=Sqm+Sqm2'-2*(X.*WeightIE)*((X2.*WeightIE2)');
  Dist=Weightd.*Dist;
  Dist=Dist-diag(diag(Dist));
  WeightAll=(d*ones(1,m)).*(ones(n,1)*IE);
  WeightAll2=(d*ones(1,m)).*(ones(n,1)*IE2);
  TotalWeight=WeightAll*WeightAll2';
  TotalWeight=TotalWeight-diag(diag(TotalWeight));
  Exp=Exp+sum(sum(Dist));
  ExpW=ExpW+sum(sum(TotalWeight));
end
Exp=Exp./ExpW;

CCT=1-Obs./Exp;





