function [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT(X,EstMethod,BiasType,Converge,MaxIter,MissingVal,DMax,DPrior,ZPrior,AddParams)
%An implementation of continuous Cultural Consensus Theory as described
%in Batchelder and Romney (1988) and France and Batchelder (2013).  In this
%version, the answer key z and competencies b are fit initially and then
%other parameters are estimated with z fixed, all using first order
%conditions and a fixed point optimization routine.
%Inputs
%X - An n*m subject*item input matrix
%EstMethod - The estimation method
%          - 0 Average value
%          - 1 Min Res factor analysis
%          - 2 Maximum likelihood estimation
%          - 3 Item difficulty model no 1 Additive Variances
%          - 4 Item difficulty model no 2 dij=alpha(i)*beta(j)
%          - 5 Item difficulty model no 3 dij=alpha(i)+beta(j)   
%          - 6 The Weber-Fechner model, where variance = zk^2/(d^p)
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          Currently bias 1 and 2 are only available for estimation methods
%          3,4, and 5
%Coverge   - The converge value (difference between successive f values)
%MaxIter   - The maximum number of iterations for the procedure
%MissingVal - The indicator for a missing value boundary of max(abs-1)
%DMax      - The maximum value of D
%DPrior    - Prior guess for value D
%ZPrior    - An previous estimate of z, use this value as an additional
%            "fake" question when all other data are missing
%AddParams - Additional parameters
%          - If EstMethod=3 then
%               P1 - The number of items to edge correct for the Rasch
%               method
%               P2 - The prior probability of the edge correctted items
%Outputs (if not included in the model then return all 1s
%z   - A continuous m*1 answer key vector
%D   - An n*1 vector of user competencies
%Bias - The model bias
%    - if EstMethod=3 then = bz - A continuous n*1 scale varible 
%    - If EstMethod=4 then = Diff - A continuous m*1 vector of Rasch item diffs.
%MaxCrit  - A maximization criteria for goodness of fit.
%LLPartial - A (3*m) matrix of partial likelihood values.  The first row
%contains the actual likelihood value, the second the value for the integer
%below the value and the third the value for the integer above the value.

  [n,m]=size(X);
  MaxCrit=0;
 
  P=+~(X==MissingVal);
  
  %If no items for a question or user then add a question based on a
  %pseudo-Bayesian prior
  SumZ=sum(P,1);
  SumZ2=sum(P,2);
  if (~isempty(find(sum(P,1)==0)))||(~isempty(find(sum(P,2)==0)))
    AddLine=true;
    n=n+1;
    X=[X;SumZ];
    P=[P;ones(1,m)];
  else
    AddLine=false;
  end
  
  if (EstMethod==1)
    %Minimum residual factor analysis
    [CorrMatrix] = CalcSimilarity(X,P,[1,3]);
    if sum(sum(isnan(CorrMatrix)))>0
      ErrorText='Badly formed correlation matrix'
    else
      %Use correlation to estimate the initial competencies
      [D,Resid] = ResidualFA(CorrMatrix,1,1e-5); 
    end
  else
    if exist('DPrior','var')
      D=ones(n,1).*DPrior;
    else
      D=ones(n,1);
    end
  end  
    
  Num=sum((D*ones(1,m).*X.*P),1);
  Denom=sum((D*ones(1,m).*P),1);
  Denom=max(Denom,1);
  z=Num./Denom;
  %Set inital values of bias and QE
  Bias=[zeros(n,1),ones(n,1)];   %Row of additive biases and row of multiplicative biases
  QE=ones(1,m);

  switch EstMethod
   case {0,1}
    %Do nothing
   case {2,3,4,5}
    %Now recalculate Z and d until convergence
    ParamChange=Converge*1000;
    Iter=0;
    while (ParamChange>Converge)&&(Iter<MaxIter)
      %Old parameters used to calculate convergence
      Oldz=z;OldD=D;
      Num=sum(D*ones(1,m).*X.*P,1);
      Denom=sum(D*ones(1,m).*P,1);
      z=Num./Denom;
      Num=sum(P,2);
      Denom=sum(P.*((X-(ones(n,1)*z)).^2),2);
      D=Num./Denom; %Account for the missing data
      if DMax>0
        if sum(D>DMax)>0
          D=min(D,DMax);
        end
      end
      ParamChange=sum(abs(Oldz-z))+sum(abs(OldD-D));
      Iter=Iter+1;
    end
    case 6
      %Now recalculate Z and d until convergence
      OP3=ones(n,1);
      ParamChange=Converge*1000;
      Iter=0;
      while (ParamChange>Converge)&&(Iter<MaxIter)
        %Basic estimation for the Weber-Fechner law
        Oldz=z;OldD=D;
%       Num=sum(D*ones(1,m).*((X.^2)-X.*(ones(n,1)*z)).*P,1);
%       Denom=sum(P,1);
%       z=(Num./Denom).^0.5;
        Num=sum(D*ones(1,m).*X.*P,1);
        Denom=sum(D*ones(1,m).*P,1);
        z=Num./Denom;
        Num=sum(P,2);
        Denom=sum(P.*(((X-(ones(n,1)*z)).^2)./(ones(n,1)*(z.^2))),2);
        D=Num./Denom; %Account for the missing data
        if DMax>0
          if sum(D>DMax)>0
            D=min(D,DMax);
          end
        end
        ParamChange=sum(abs(Oldz-z))+sum(abs(OldD-D));
        Iter=Iter+1;
      end
  end
  
 switch EstMethod
   case {1,6}
      %Do nothing for pricipal axes factor analysis
      %For the moment do nothing with 
   case {0,2,4}
      %Have basic estimate (now second stage of estimating with regression
      %function
      ParamChange=Converge*1000;
      Iter=0;
      while (ParamChange>Converge)&&(Iter<MaxIter)
        OldD=D;OldBias=Bias;OldQE=QE;

        %Firstly calculate the inner estimation
        switch BiasType
        case 0
          %Do not estimate the bias
          InnerTerm=(X-ones(n,1)*z);
        case 1
         %Estimate the bias parameter
          Num=sum(D*ones(1,m).*(X-ones(n,1)*z).*P,2);
          Denom=sum(D*ones(1,m).*P,2);
          Bias(:,1)=Num./Denom;
          InnerTerm=(X-(Bias(:,1)*ones(1,m))-ones(n,1)*z);
        case 2
          %Multiplicative bias
          Num=sum(P.*X.*(ones(n,1)*z),2);
          Denom=sum(P.*(ones(n,1)*(z.^2)),2);
          Bias(:,2)=Num./Denom;
          InnerTerm=(X-Bias(:,2)*z);
        end
       
        %If incorporating item difficulty then include an update
        if (EstMethod==4)
          %Estimate the easyness parameter
          Num=sum(P,1);
          Denom=sum((D*ones(1,m)).*(InnerTerm.^2).*P,1);
          QE=Num./Denom;
        end
        
        if EstMethod>0
          %Now estimate the competency based on the model used
          Num=sum(P,2);
          Denom=sum(P.*(ones(n,1)*QE).*(InnerTerm.^2),2);
          D=Num./Denom;
        end
       
        if DMax>0
          if sum(D>DMax)>0
            D=min(D,DMax);
          end
          if sum(QE>DMax)>0
            QE=min(QE,DMax);
          end
        end
        ParamChange=sum(sum(abs(OldBias-Bias)))+sum(abs(OldD-D))+sum(abs(OldQE-QE));
        Iter=Iter+1;

      end
    case 3
      %Estimate the values of Alpha(i) and Beta(j)
      Iter=0;
      ParamChange=Converge*1000;
      while (ParamChange>Converge)&&(Iter<MaxIter)
        OldD=D;OldQE=QE;OldBias=Bias;
        
        %Firstly calculate the inner estimation
        switch BiasType
        case 0
          %Do not estimate the bias
          InnerTerm=(X-ones(n,1)*z);
        case 1
         %Estimate the bias parameter
          Num=sum(D*ones(1,m).*(X-ones(n,1)*z).*P,2);
          Denom=sum(D*ones(1,m).*P,2);
          Bias(:,1)=Num./Denom;
          InnerTerm=(X-(Bias(:,1)*ones(1,m))-ones(n,1)*z);
        case 2
          %Multiplicative bias
          Num=sum(P.*X.*(ones(n,1)*z),2);
          Denom=sum(P.*(ones(n,1)*(z.^2)),2);
          Bias(:,2)=Num./Denom;
          InnerTerm=(X-Bias(:,2)*z);
        end
        
        %Estimate the easiness parameter
        BR=(D*ones(1,m))./((D*ones(1,m))+(ones(n,1)*QE));   %beta/(alpha+beta)
        Num=sum(P.*BR,1);
        Denom=sum(P.*(BR.^2).*(InnerTerm.^2),1);
        QE=Num./Denom;

        %Estimate the competancy D
        BR=(ones(n,1)*QE)./((D*ones(1,m))+(ones(n,1)*QE));   %beta/(alpha+beta)
        Num=sum(P.*BR,2);
        Denom=sum(P.*(BR.^2).*((InnerTerm).^2),2);
        D=Num./Denom;
        if DMax>0
          if sum(D>DMax)>0
            D=min(D,DMax);
          end
          if sum(QE>DMax)>0
            QE=min(QE,DMax);
          end
        end
        ParamChange=sum(abs(OldQE-QE))+sum(abs(OldD-D))+sum(sum(abs(OldBias-Bias)));
        Iter=Iter+1;
      end
    case 5
      %Item difficulty with dij=?(i)+?(j)
      ParamChange=Converge*1000;
      Iter=0;
      D=D./2;
      QE=rand(1,m);
      while (ParamChange>Converge)&&(Iter<MaxIter)
        OldD=D;OldQE=QE;OldBias=Bias;
        
        %Calculate the current bias
        switch BiasType
        case 0
          %Do not estimate the bias
          InnerTerm=(X-ones(n,1)*z);
        case 1
         %Estimate the bias parameter
          Num=sum(D*ones(1,m).*(X-ones(n,1)*z).*P,2);
          Denom=sum(D*ones(1,m).*P,2);
          Bias(:,1)=Num./Denom;
          InnerTerm=(X-(Bias(:,1)*ones(1,m))-ones(n,1)*z);
        case 2
          %Multiplicative bias
          Num=sum(P.*X.*(ones(n,1)*z),2);
          Denom=sum(P.*(ones(n,1)*(z.^2)),2);
          Bias(:,2)=Num./Denom;
          InnerTerm=(X-Bias(:,2)*z);
        end
      
        %Estimate the easyness parameter
        Num=sum(P,1);
        Term1=sum((InnerTerm.^2).*P,1);
        Term2=sum((1./(D(2:n)*ones(1,m)+ones(n-1,1)*QE)).*P(2:n,:),1);
        QE=1./(Term1-Term2)-D(1);
        %Estimate competency D
        Num=sum(P,2);
        Term1=sum((InnerTerm.^2).*P,2);
        Term2=sum((1./(D*ones(1,m-1)+ones(n,1)*QE(2:m))).*P(:,2:m),2);
        D=1./(Term1-Term2)-QE(1);
        if DMax>0
          if sum(D>DMax)>0
            D=min(D,DMax);
          end
          if sum(QE>DMax)>0
            QE=min(QE,DMax);
          end
        end

        ParamChange=sum(abs(OldQE-QE))+sum(abs(OldD-D))+sum(sum(abs(OldBias-Bias)));
        Iter=Iter+1;
      end
  end
  
  %No remove the additional value of X
  if AddLine==true
    n=n-1;
    X=X(1:n,:);
    P=P(1:n,:);
    D=D(1:n);
    Bias=Bias(1:n,:);
  end
  
  
  %Calculate the criterion value
  switch EstMethod
    case 1
      %Calculate the residual from the VAF
      MeanVal=mean(mean(CorrMatrix));
      MaxCrit=1-(ssq(Resid)./ssq(CorrMatrix-MeanVal));
      %Weight using the number of items (need this to make it consistant
      %for the clusterwise estimation procedure
      MaxCrit=MaxCrit.*sum(sum(P));
      LLPartial=-1;
    case {0,2,3,4,5}
      %Calculate the inner term for the bias
      InnerTerm=(X-(Bias(:,1)*ones(1,m))-Bias(:,2)*z);
      
      switch EstMethod
        case {0,2,4}
          %Calculate the maximum log likelihood value
          Part1=P.*(log(((D*QE)./(2*pi)).^0.5));
          Part2=P.*((-D*QE).*(InnerTerm.^2)./2);
          MaxCrit=sum(sum(Part1))+sum(sum(Part2));
        case 3
          Ratio=(D*QE)./((D*ones(1,m))+(ones(n,1)*QE));
          Part1=log((Ratio./(2*pi)).^0.5);
          Part2=P.*-Ratio.*(InnerTerm.^2)./2;
          MaxCrit=sum(sum(Part1))+sum(sum(Part2));         
        case 5
          Part1=P.*(log(((D*ones(1,m)+ones(n,1)*QE)./(2*pi)).^0.5));
          Part2=P.*(-(D*ones(1,m)+ones(n,1)*QE).*(InnerTerm.^2)./2);
          MaxCrit=sum(sum(Part1))+sum(sum(Part2));            
      end
          
      %Calculate the partial log likelihoods
      LLPartial=zeros(3,m);
      for j=1:m
        zval=z(j);
        %Store z, the lower bound and the upper bound
        zAll=[zval,fix(zval),fix(zval+1)];
        QEAll=QE(j)*ones(1,3);
        %Estimate the inner term
        InnerTerm=(X(:,j)*ones(1,3)-Bias(:,1)*ones(1,3)-Bias(:,2)*zAll);
        %Estimate partial log likelihoods
        switch EstMethod
        case {0,2,4}
          Part1=(P(:,j)*ones(1,3)).*(log(((D*QEAll)./(2*pi)).^0.5));
          Part2=(P(:,j)*ones(1,3)).*(-D*QEAll).*(((InnerTerm).^2)./2);
          LLPartial(:,j)=(sum(Part1,1)+sum(Part2,1))';
        case 3
          Part1=(P(:,j)*ones(1,3)).*(log((((D*ones(1,3)).*(ones(n,1)*QEAll))./(((D*ones(1,3))+(ones(n,1)*QEAll))*2*pi)).^0.5));
          Part2=(P(:,j)*ones(1,3)).*((-((D*ones(1,3)).*(ones(n,1)*QEAll))).*((X(:,j)*ones(1,3)-ones(n,1)*zAll).^2)./(2*((D*ones(1,3))+(ones(n,1)*QEAll))));
          LLPartial(:,j)=(sum(Part1,1)+sum(Part2,1))';        
        case 5
          Part1=(P(:,j)*ones(1,3)).*(log(((D*ones(1,3)+ones(n,1)*QEAll)./(2*pi)).^0.5));
          Part2=(P(:,j)*ones(1,3)).*(-(D*ones(1,3)+ones(n,1)*QEAll).*((X(:,j)*ones(1,3)-ones(n,1)*zAll).^2)./2);
          LLPartial(:,j)=(sum(Part1,1)+sum(Part2,1))';
        end

      end 
    case 6
      Part1=P.*(log((1./(ones(n,1)*z)).*(((D*ones(1,m))./(2*pi)).^0.5)));
      Part2=P.*((-D*ones(1,m)).*((X-(ones(n,1)*z)).^2)./(2.*ones(n,1)*(z.^2)));
      MaxCrit=sum(sum(Part1))+sum(sum(Part2));
      %Calculate the partial log likelihoods
      LLPartial=zeros(3,m);
      for j=1:m
        zval=z(j);
        %Store z, the lower bound and the upper bound
        zAll=[zval,fix(zval),fix(zval+1)];
        Part1=(P(:,j)*ones(1,3)).*(log((1./(ones(n,1)*zAll)).*(((D*ones(1,3))./(2*pi)).^0.5)));
        Part2=(P(:,j)*ones(1,3)).*((-D*ones(1,3)).*((X(:,j)*ones(1,3)-(ones(n,1)*zAll)).^2)./(2.*ones(n,1)*(zAll.^2)));
        LLPartial(:,j)=(sum(Part1,1)+sum(Part2,1))';
      end
    
  end
  
  
  
  