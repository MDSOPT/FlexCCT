function [Z,D,g,HR,FPR] = CCTMajorityRule(X,RunMode)
%A simple majority rule algorithm for cultural consensus analysis.
%Includes three variants for getting around the problems of ties.
%
%Inputs 
%X - An n*m subject*item matrix
%RunMode- The method for dealing with ties.
%      0- Simple majority rule.  Leave a probability of 0.5 if there is a tie
%      1- Simple majority rule.  50/50 guess if there is a tie
%      2- Two stage.  1st stage ignore ties and calculate competencies.  2nd stage
%      Give precedence to answers for users with the highest aggregate competancy
%Outputs (for best solution)
%Z - An 1*m  answer key vector
%D - An n*1 vector of competencies
%g - An n*1 set of bias parameters
%HR - The hit rate (X=1 Z=1)
%FPR - The false positive rate (X=1 Z=0)
%Version     Author            Date
%   0.10     Stephen France    05/10/2012
[n,m]=size(X);

QSum=sum(X,1);

switch RunMode
  case 0
    %Simple majority rule.  Leave a probability of 0.5 if there is a tie
    Z=(QSum>(n./2))+(QSum==(n./2)).*0.5;
  case 1 
    %Simple majority rule.  Guess if there is a tie
    Z=(QSum>(n./2))+(QSum==(n./2)).*(rand(1,m)>0.5); %50 
  case 2
    %Two stage.  1st stage ignore ties and calculate competencies.  2nd stage
    %Give precedence to answers for users with the highest aggregate
    %competancy
    Z=(QSum>(n./2));
    NSI=find(QSum==(n./2))  %Indexes with no solution 
    if ~isempty(NSI)
      SI=find(QSum~=(n./2))       %Indexes with solution
      TempZ=Z(SI);
      TempX=X(:,SI);
      [OptValue,HR,FPR] = CCTFunction(TempX,TempZ,0);
      D=HR-FPR;
      %Replace the answers with the competancies
      ChkX=((2.*X)-1).*(D*ones(1,m));
      Z(:,NSI)=sum(ChkX(:,NSI),1)>0;
    end
end

%Don't use the optvalue, but use HR and FPR
[OptValue,HR,FPR] = CCTFunction(X,Z,0);

%Calculate the values of D and g
D=HR-FPR;
%If perfect D then (1-D)=0 and g is undefined.
Denom=(1-D);
g=FPR./Denom;



