
MinScale=0.5;
IsRun=false;
OverallRun=0;
DMax=5;


for iData=12:320
  z=Allz(iData,:);
  D=AllD(:,iData);
  Bias=AllBias(:,1+2*(iData-1):2*iData);
  
  %Load the data matrix X into memory
  XName =strcat('C:\CCOut\DO\RCSV\X',num2str(round(iData)),'.csv');
  X=csvread(XName);
  NoItems=size(X,1);
  Results2=[];

  
  AddBias=DLBase(iData,10);
  MultBias=DLBase(iData,11);
  
%   for Identify=-1:1
%     tic;
%     if AddBias==0&&MultBias==0  
%       [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT4(X,2,0,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
%     elseif AddBias==1&&MultBias==0
%       [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT4(X,2,1,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
%     elseif AddBias==0&&MultBias==1
%       [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT4(X,2,2,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
%     else
%       [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT4(X,2,3,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
%     end
%     t=toc;
%     Results2=[Results2;[iData,14+Identify,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,sum((D-DI).^2)./NoItems, ...
%       sum(abs(D-DI))./NoItems,sum((Bias(:,1)-BiasI(:,1)).^2)./NoItems,sum(abs(Bias(:,1)-BiasI(:,1)))./NoItems,...
%       sum((Bias(:,2)-BiasI(:,2)).^2)./NoItems,sum(abs(Bias(:,2)-BiasI(:,2)))./NoItems,t]];    
%   end 
% 
%   for Identify=-1:1
%     tic;
%     if AddBias==0&&MultBias==0  
%       [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT4(X,2,0,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
%     elseif AddBias==1&&MultBias==0
%       [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT4(X,2,1,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
%     elseif AddBias==0&&MultBias==1
%       [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT4(X,2,2,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
%     else
%       [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT4(X,2,3,[Identify,Identify,Identify,0],[1e-6,1000,1],-1,DMax,DMax);      
%     end
%     t=toc;
%     Results2=[Results2;[iData,17+Identify,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,sum((D-DI).^2)./NoItems, ...
%       sum(abs(D-DI))./NoItems,sum((Bias(:,1)-BiasI(:,1)).^2)./NoItems,sum(abs(Bias(:,1)-BiasI(:,1)))./NoItems,...
%       sum((Bias(:,2)-BiasI(:,2)).^2)./NoItems,sum(abs(Bias(:,2)-BiasI(:,2)))./NoItems,t]];
%   end   
 
%   
%   for Identify=-1:1
%     tic;
%     if AddBias==0&&MultBias==0  
%       [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,0,[Identify,Identify,0,0],[1e-6,1000,1],-1,1,DMax,DMax);
%     elseif AddBias==1&&MultBias==0
%       [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,1,[Identify,Identify,0,0],[1e-6,1000,1],-1,1,DMax,DMax);
%     elseif AddBias==0&&MultBias==1
%       [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,2,[Identify,Identify,0,0],[1e-6,1000,1],-1,1,DMax,DMax);
%     else
%       [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,3,[Identify,Identify,0,Identify],[1e-6,1000,1],-1,1,DMax,DMax);
%     end
%     t=toc;
%     Results2=[Results2;[iData,20+Identify,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,sum((D-DI).^2)./NoItems, ...
%       sum(abs(D-DI))./NoItems,sum((Bias(:,1)-BiasI(:,1)).^2)./NoItems,sum(abs(Bias(:,1)-BiasI(:,1)))./NoItems,...
%       sum((Bias(:,2)-BiasI(:,2)).^2)./NoItems,sum(abs(Bias(:,2)-BiasI(:,2)))./NoItems,t]];               
%   end
%   
  for Identify=-1:1
    tic;
    if AddBias==0&&MultBias==0  
      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,0,[Identify,Identify,0,0],[1e-6,1000,1],-1,1,DMax,DMax);
    elseif AddBias==1&&MultBias==0
      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,1,[Identify,Identify,-99,0],[1e-6,1000,1],-1,1,DMax,DMax);
    elseif AddBias==0&&MultBias==1
      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,2,[Identify,Identify,0,-99],[1e-6,1000,1],-1,1,DMax,DMax);
    else
      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,3,[Identify,Identify,-99,-99],[1e-6,1000,1],-1,1,DMax,DMax);
    end
    t=toc;
    Results2=[Results2;[iData,23+Identify,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,sum((D-DI).^2)./NoItems, ...
      sum(abs(D-DI))./NoItems,sum((Bias(:,1)-BiasI(:,1)).^2)./NoItems,sum(abs(Bias(:,1)-BiasI(:,1)))./NoItems,...
      sum((Bias(:,2)-BiasI(:,2)).^2)./NoItems,sum(abs(Bias(:,2)-BiasI(:,2)))./NoItems,t]];               
  end
  
  for Identify=-1:1
    tic;
    if AddBias==0&&MultBias==0  
      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,0,[Identify,Identify,0,0],[1e-6,1000,1],-1,1,DMax,DMax);
    elseif AddBias==1&&MultBias==0
      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,1,[Identify,Identify,-99,0],[1e-6,1000,1],-1,1,DMax,DMax);
    elseif AddBias==0&&MultBias==1
      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,2,[Identify,Identify,0,-99],[1e-6,1000,1],-1,1,DMax,DMax);
    else
      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,3,[Identify,Identify,-99,0],[1e-6,1000,1],-1,1,DMax,DMax);
    end
    t=toc;
    Results2=[Results2;[iData,26+Identify,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,sum((D-DI).^2)./NoItems, ...
      sum(abs(D-DI))./NoItems,sum((Bias(:,1)-BiasI(:,1)).^2)./NoItems,sum(abs(Bias(:,1)-BiasI(:,1)))./NoItems,...
      sum((Bias(:,2)-BiasI(:,2)).^2)./NoItems,sum(abs(Bias(:,2)-BiasI(:,2)))./NoItems,t]];               
    end
  
  for Identify=-1:1
    tic;
    if AddBias==0&&MultBias==0  
      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,0,[Identify,Identify,0,0],[1e-6,1000,1],-1,1,DMax,DMax);
    elseif AddBias==1&&MultBias==0
      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,1,[Identify,Identify,-99,0],[1e-6,1000,1],-1,1,DMax,DMax);
    elseif AddBias==0&&MultBias==1
      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,2,[Identify,Identify,0,-99],[1e-6,1000,1],-1,1,DMax,DMax);
    else
      [zI,DI,BiasI,QEI,MaxCritI,LLPartialI] = ContinuousCCT3(X,2,3,[Identify,Identify,0,-99],[1e-6,1000,1],-1,1,DMax,DMax);
    end
    t=toc;
    Results2=[Results2;[iData,29+Identify,sum((z-zI).^2)./NoItems,sum(abs(z-zI))./NoItems,sum((D-DI).^2)./NoItems, ...
      sum(abs(D-DI))./NoItems,sum((Bias(:,1)-BiasI(:,1)).^2)./NoItems,sum(abs(Bias(:,1)-BiasI(:,1)))./NoItems,...
      sum((Bias(:,2)-BiasI(:,2)).^2)./NoItems,sum(abs(Bias(:,2)-BiasI(:,2)))./NoItems,t]];               
  end
  
  
  save 'C:\CCOut\DO\MLDanceOff4.txt' Results2 -append -ascii;

end                      
                      
