function [HOOut] = HoldoutValidation(Holdout,X,EstMethod,BiasType,OptMethod,FixParams,OptParams,XSpec,DMax,IEMax)
%Runs the process of hold-k out validation.  Inputs the actual values of
%parameters, along with the holdout values
%INPUTS
%Holdout   - HasItemHoldout 1 if CIs for raters, 0 otherwise
%          - HasRaterHoldout 1 if CIs for raters, 0 otherwise
%          - NoHoldout - The number of items removed for the holdout validation
%          - HOz,HOIE, HOd, HObadd, HObmult - 1 if HO for variable, otherwise
%          - MSE, MSPE, MAE, MAPE, Corr - The error criterion - 1 if included, 0 otherwise
%X         - The n rater*m item ratings matrix
%EstMethod - The estimation method
%          - 0 Average value
%          - 1 Minimum Residual factor analysis
%          - 2 Maximum likelihood estimation
%          - 3 Item difficulty model no 1 Additive Variances
%          - 4 Item difficulty model no 2 dij=alpha(i)*beta(j)
%          - 5 Item difficulty model no 3 dij=alpha(i)+beta(j)   
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          - 3 Fit additive and multiplicative bias
%          Currently bias 1 and 2 are only available for estimation methods
%          0,2,3,4, and 5
%          - 4 Fit a bias that declines linearly in proportion to the
%          remaining length of interval         
%OptMethod - 0 Fixed point: Fixed point estimation.
%          - 1 Two Stage Fixed Point. The values of z and d are estimated first, followed by other parameters.
%          - 2 Derivative Free: Standard MATLAB routine.
%          - 3 Gradient: MATLAB Gradient descent optimization, utilizing first order derivatives
%FixParams - A row vector containing the parameter fixing/identifiability parameters.  See ContinuousCCT3 header for more details 
%OptParms  - A row vector containing the optimization parameters.  See ContinuousCCT3 header for more details
%MissingVal- The indicator for a missing value boundary of max(abs-1)
%DMax      - The maximum value of D
%IEMax     - The maximum value of the item easiness IE
%OUTPUTS
%HOout 	   - Contains holdout information and metrics for each variable set
%that can be tested for holdout validation
%		   - ResHOd,ResHObadd, ResHObmult,ResHOz,ResHOIE
%	     - Each of these contains the following the following
%      - Ind - a 5*1 array containing true/false indicators for MSE, MSPE,
%      MAE, MAPE, Corr as to whether the metrics are used or not
%      - Values Values of the metrics matching the actual indicators
%Version     Author            Date
%   2.50     Stephen France    01/02/2017
[n,m]=size(X);

%Calculate the number of samples
[pos]=find(X~=-1);
NoItems=size(pos,1);

%Get the total number of runs
NoRuns=ceil(NoItems/Holdout.NoHoldout);
NoRuns=min(NoRuns,Holdout.MaxRuns);
ItemPerm=randperm(NoItems);
ItemPerm=pos(ItemPerm);
%Set up the comparisons
%Order the values into percentiles
if Holdout.HOd==true
  HOOut.ResHOd=zeros(n,NoRuns);
end
if Holdout.HObadd==true
  HOOut.ResHObadd=zeros(n,NoRuns);
end
if Holdout.HObmult==true
  HOOut.ResHObmult=zeros(n,NoRuns);
end
if Holdout.HOz==true
  HOOut.ResHOz=zeros(m,NoRuns);
end
if Holdout.HOIE==true
  HOOut.ResHOIE=zeros(m,NoRuns);
end
if Holdout.HOXPred==true
  HOOut.XActual=[];HOOut.XPred=[];
  HOOut.Xd=[];HOOut.XIE=[];
end

EndPos=0;
for i=1:NoRuns
  %Determine the items to be held out and replace by -1
  StartPos=EndPos+1;
  EndPos=min(StartPos+Holdout.NoHoldout-1,NoItems);
  HoldoutItems=ItemPerm(StartPos:EndPos);
  XRS=X;
  XRS(HoldoutItems)=-1;

  %Now perform the CCT
  switch OptMethod
  case {1}
    %Gradient
    [z,D,Bias,IE,MaxCrit,LLPartial] = ContinuousCCT3(XRS,EstMethod,BiasType,FixParams,OptParams,XSpec,1,DMax,IEMax);
  case {2}
    %Derivative Free
    [z,D,Bias,IE,MaxCrit,LLPartial] = ContinuousCCT3(XRS,EstMethod,BiasType,FixParams,OptParams,XSpec,0,DMax,IEMax);
  case {3}
    %Fixed point optimization
    [z,D,Bias,IE,MaxCrit,LLPartial] = ContinuousCCT5(XRS,EstMethod,BiasType,FixParams,OptParams,XSpec,DMax,IEMax);
  end
  
  %Store the output results
  if Holdout.HOd==true
    HOOut.ResHOd(:,i)=D;
  end
  if Holdout.HObadd==true
    HOOut.ResHObadd(:,i)=Bias(:,1);
  end
  if Holdout.HObmult==true
    HOOut.ResHObmult(:,i)=Bias(:,2);
  end
  if (Holdout.HOz==true)
    HOOut.ResHOz(:,i)=z';
  end 
  if (Holdout.HOIE==true)
    HOOut.ResHOIE(:,i)=IE';
  end
  %This is the holdout where we predict the X values from the scores and
  %biases
  if Holdout.HOXPred==true
    Cols=ceil(HoldoutItems./n);
    Rows=HoldoutItems-(Cols-1)*n;
    XPred=(Bias(:,2)*z)+Bias(:,1)*ones(1,m);
    HOOut.XActual=[HOOut.XActual;X(HoldoutItems)];
    HOOut.XPred=[HOOut.XPred;XPred(HoldoutItems)];
    HOOut.Xd=[HOOut.Xd;D(Rows)];
    HOOut.XIE=[HOOut.XIE;IE(Cols)'];
  end
end

%Calculate the overall statistics
if Holdout.HOd==true
  HOOut.dHOMetrics=HOMetrics(HOOut.ResHOd,Holdout.d,NoRuns,n,Holdout);
end
if Holdout.HObadd==true
  HOOut.baddHOMetrics=HOMetrics(HOOut.ResHObadd,Holdout.badd,NoRuns,n,Holdout);
end
if Holdout.HObmult==true
  HOOut.bmultHOMetrics=HOMetrics(HOOut.ResHObmult,Holdout.bmult,NoRuns,n,Holdout);
end
if Holdout.HOz==true
  HOOut.zHOMetrics=HOMetrics(HOOut.ResHOz,Holdout.z',NoRuns,m,Holdout);
end
if Holdout.HOIE==true
  HOOut.IEHOMetrics=HOMetrics(HOOut.ResHOIE,Holdout.IE',NoRuns,m,Holdout);
end
if Holdout.HOXPred==true
  %Predict z from overall biases
  CSize=size(HOOut.XActual,1);  %Use size to prevent any rounding errors
  HOOut.XPredHOMetrics=HOMetricsBiasReconstuct(HOOut.XPred,HOOut.XActual,HOOut.Xd,HOOut.XIE,CSize,Holdout,EstMethod);
end


