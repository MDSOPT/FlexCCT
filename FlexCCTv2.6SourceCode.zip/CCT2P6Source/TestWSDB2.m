%The first experiment for the web search and data mining conference

AllResults=[];
MinScale=0.5;
OverallRun=0;
StopMode=true;

for NoItems=100:100:200
  for NoUsers=100:100:200
    for Scale=5:5:10
      Range=Scale-1;
      Centre=1+(Range/2);
      for TrueDist=1:2
        for MissingPC=0
          for PropRange=5:2:9
            for DMax=40:40
              for NoClusters=2:1:5
                for Lambda=0:0.25:1    %Set the value of lambda 
                  if TrueDist==2
                    StopMode=false;
                  end
                  %First randomly select true review scores
                  z = zeros(NoClusters,NoItems);
                  if TrueDist==1
                    %Sample from normal distribution with mean at the center
                    %point and with 1 standard devation = 1/6 range
                    zBase = norminv(rand(1,NoItems),Centre,Range/5);
                    zCluster = zeros(NoClusters,NoItems);
                    for k=1:NoClusters
                      zCluster(k,:)=norminv(rand(1,NoItems),Centre,Range/5);
                      z(k,:)=Lambda*zCluster(k,:)+(1-Lambda)*zBase;
                    end
                  else
                    %Sample from uniform distribution
                    zBase=(rand(1,NoItems).*Range)+1;
                    zCluster = zeros(NoClusters,NoItems);
                    for k=1:NoClusters
                      zCluster(k,:)=(rand(1,NoItems).*Range)+1;
                      z(k,:)=Lambda*zCluster(k,:)+(1-Lambda)*zBase;
                    end
                  end
                  %Randomly assign users to clusters, to create cluster
                  %membership matrix.  N.B. Keep clusters of equal size
                  Perm=randperm(NoUsers);
                  Assignments=ones(NoUsers,1);
                  for i=2:NoClusters
                    SubPerm=Perm(floor(NoUsers*(i-1)/NoClusters)+1:floor(NoUsers*i/NoClusters));
                    Assignments(SubPerm)=i;
                  end  
                    
                  %Determine latent competencies for users
                  Mind=(Range/3)^(-2);
                  Midd=(Range/6)^(-2);
                  Maxd=(Range/9)^(-2);
                  
                  %Select all users to have higher competancy within their
                  %cluster, from s standard deviation 1/5 range to standard
                  %deviation 1/9 of a range
                  D=ones(NoUsers,1).*(Range/PropRange)^(-2);
                  
                  %Now sample an answer key given the competency and the true
                  %score
                  %Sample an error matrix based on competencies
                  Error=zeros(NoUsers,NoItems);
                  for i=1:NoUsers
                    P=rand(1,NoItems);
                    Error(i,:) = norminv(P,0,(D(i)^(-0.5)));
                  end

                  %Add the error to the actual values of the items
                  X=z(Assignments',:)+Error;
                  X=round(X);
                  X=min(max(1,X),Scale);   %Ensure in bounds
                  %Replace any missing data by -1
                  IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                  AllAssigned=isempty(find(sum(1-IsMissing,1)==0))&&isempty(find(sum(1-IsMissing,2)==0));
                  while (AllAssigned==0)
                    IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                    [IsMissing,AllAssigned]=FixMissing(IsMissing,1000);
                  end
                  X=-IsMissing+(1-IsMissing).*X;

                  %Now run clusterwise continuous cultural consensus theory
                  CWOptParams=[5,5]; %Parameters are minimum items in cluster and the number of optimization runs
                  
                  %Go through different sets of runs
                  for Initialize=1:2
                    OverallRun=OverallRun+1;
                    if mod(OverallRun,10)==0
                      OverallRun
                    end
                    if (StopMode==false)
                      tic;
                      Results=[NoItems,NoUsers,Scale,TrueDist,MissingPC,PropRange,DMax,NoClusters,Lambda,Initialize];
                      Results2=zeros(1,12);
                      [Clusters,MaxCrit0,C,ZAll,D,OP3] = CWContinuousCCT(X,NoClusters,Initialize,2,0,1e-6,1000,-1,CWOptParams,DMax,Midd);
                      [Rand0,AdjRand0] = RandIndex2(Assignments,Clusters.Assignments);
                      [Clusters2,MaxCrit2,C,ZAll,D,OP3,EndInitialize] = CWContinuousCCT(X,NoClusters,Initialize,2,2,1e-6,1000,-1,CWOptParams,DMax,Midd);
                      [Rand2,AdjRand2] = RandIndex2(Assignments,Clusters.Assignments);
                      %If had to change the k-means initialization to random
                      %initialization set error flag
                      Results2(1)=~(EndInitialize==Initialize);
                      [Clusters4,MaxCrit4,C,ZAll,D,OP3,EndIntiailize] = CWContinuousCCT(X,NoClusters,Initialize,2,4,1e-6,1000,-1,CWOptParams,DMax,Midd);
                      Results2(2)=~(EndInitialize==Initialize);
                      [Rand4,AdjRand4] = RandIndex2(Assignments,Clusters.Assignments);         
                      %Calculate the MAE and MSE between Ds for all models
                      Results2(3)=MaxCrit0;
                      Results2(4)=MaxCrit2;
                      Results2(5)=MaxCrit4;
                      Results2(6)=Rand0;
                      Results2(7)=Rand2;
                      Results2(8)=Rand4;
                      Results2(9)=AdjRand0;
                      Results2(10)=AdjRand2;
                      Results2(11)=AdjRand4;
                      Results2(12)=toc;
                      NewResults=[Results,Results2];
                      AllResults=[AllResults;NewResults];
                      save 'C:\CCOut\NewClusterMD0.txt' NewResults -append -ascii;
                    end
                  end
                end
              end
            end
          end
        end
      end
    end
  end
end