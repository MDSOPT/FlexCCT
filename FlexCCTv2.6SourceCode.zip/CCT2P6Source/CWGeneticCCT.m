function [BestResults,RunTime] = CWGeneticCCT(X,NoClusters,OptFunction,CWeight,STemp,ETemp,CTemp,TermIt,IsMissing,MissingVal,InitialC,InitialZ)
%The maximum likelihood approach for clusterwise Cultural Consensus Theory. 
%Each subject is assigned to a cluster.  For each combination o
%data will be dealt with with setting each element of the likelihood
%function with missing data to 1 (the log likelihood for the element will
%be 0)
%
%Inputs 
%X - An n*m subject*item matrix
%NoClusters - The number of clusters
%OptFunction-The function to maximize/minimize
%          - 0 Linear Function (hits - false positives)
%          - 1 Maximum Likelihood function
%CWeight - The proportion [0,1] of changes for the cluster assignment.
%          - If OptWeight=0 then clusters are fixed.  If 1 then Z is fixed.
%STemp     - The start temperature for the annealing process
%ETemp     - The end temperature for the annealing process
%CTemp     - The change in temperature for each stage of the annealing
%            proceess
%TermIt    - The number of iterations with no change before terminating
%IsMissing - 1 if missing values are present, 0 otherwise
%MissingVal   - The identifier for missing data (should be outside range of actual values) 
%InitialC  - An (n*c) binary cluster assignment matrix
%InitialZ  - A  (c*m) binary cluster assignment matrix
%Outputs
%BestResults - A results variable consisting of the following 
%------------------------------------------------------------
%C - A n*c matrix of binary cluster assignments
%Z - A matrix of c*m answer key vectors (one for each cluster)
%For each cluster there is the following (indexed by i)
%Count - The number of subjects assigned to the cluster
%Indexes - The indexes of the subjects assigned to the clusters
%D - A Count{i}*1 vector of competencies
%g - An Count{i}*1 set of bias parameters
%f - The value of the likelihood function
%HR - The value of the hit rate for the 
%Runtime - The runtime for the algorithm
%------------------------------------------------------------ 


%Version     Author            Date
%   0.10     Stephen France    04/20/2012

  [n,m]=size(X);
  tic;
  
  %Check out the initial values of Z
  if (IsMissing==1)
    P=(X~=MissingVal);
  end

  %Check out the initial values of C. 
  if ~exist('InitialC','var')
    %Each consumer assigned to 1 cluster
    RI=find(ones(n,1));
    CI=floor(rand(n,1)*NoClusters)+1;
    InitialC=full(spconvert([RI,CI,ones(n,1)]));
  end  
  
  %Check out the initial values of Z
  if ~exist('InitialZ','var')
    InitialZ=round(rand(NoClusters,m));
  end
  
  BestZ=InitialZ;CurZ=InitialZ;
  BestC=InitialC;CurC=InitialC;
  CurTemp=STemp;
  
  %Calculate the initial value
  if (IsMissing==0)
    [f,HR,FPR] = CWCCTFunction(X,CurZ,CurC,OptFunction);
  else
    [f,HR,FPR] = CWCCTFunctionMissing(X,CurZ,CurC,P,OptFunction);
  end
  Bestf=f;
  BestHR=HR;
  BestFPR=FPR;

  NoChangeIt=0;
  
  while (NoChangeIt<TermIt) || (CurTemp>ETemp)
    %Either cluster assignment can change or the answer key can change
    TestZ=CurZ;
    TestC=CurC;
    
    if rand()<CWeight
      %Choose a cluster assignment to change
      SChange=floor(rand()*n)+1;
      %Only one cluster per subject, so cannot go to the current subject
      CurCluster=find(TestC(SChange,:)==1);
      TestC(SChange,CurCluster)=0;
      %Select from one of the k-1 remaining items (excluding current
      %cluster) 
      NewCluster=floor(rand()*(NoClusters-1))+1;
      if NewCluster>=CurCluster
        NewCluster=NewCluster+1;
      end
      TestC(SChange,NewCluster)=1;    
    else
      CChange=floor(rand()*NoClusters)+1;
      ZChange=floor(rand()*m)+1;
      TestZ(CChange,ZChange)=mod(TestZ(CChange,ZChange)+1,2);     %Assume a zero one Z
    end  
    
    if (IsMissing==0)
      [fNew,HR,FPR] = CWCCTFunction(X,TestZ,TestC,OptFunction);
    else
      [fNew,HR,FPR] = CWCCTFunctionMissing(X,TestZ,TestC,P,OptFunction);
    end
    fChange=fNew-f;
    
    if fChange<0
      Accept=true;
    else
      PAccept=exp(-fChange/CurTemp);
      %Implement the simulated annealing
      if rand<PAccept
        Accept=true;
      else
        Accept=false;
      end
    end
  
    if (Accept==true)
      f=fNew;
      CurZ=TestZ;
      CurC=TestC;
      if f<Bestf
        BestZ=CurZ;
        BestC=TestC;
        Bestf=f;
        BestHR=HR;
        BestFPR=FPR;
        T1=(BestFPR<0);
        if sum(T1)>0
          A
        end
      end
      NoChangeIt=0;
    else
      NoChangeIt=NoChangeIt+1;
    end
    CurTemp=max(ETemp,CurTemp-CTemp);

  end

RunTime=toc;

BestResults.Z=BestZ;
BestResults.C=BestC;
BestResults.HR=BestHR;
BestResults.FPR=BestFPR;

%Calculate the values of D and g
BestResults.D=BestHR-BestFPR;
%If perfect D then (1-D)=0 and g is undefined.  Set to allow bias to be 0
Denom=(1-BestResults.D);%+((1-D)==0);
BestResults.g=BestResults.FPR./Denom;

%Now calculate clusterwise statistics
for i=1:NoClusters
  Z=BestZ(i,:);
  BestResults.CWRealHR{i}=sum(Hits,2)./(sum(Z));
  BestResults.CWHR{i}=sum(Hits,2)./(sum(Z)+((sum(Z))==0));
  BestResults.CWRealFPR{i}=sum(FPositives,2)./(sum(1-Z));
  BestResults.CWFPR{i}=sum(FPositives,2)./(sum(1-Z)+((sum(1-Z))==0));  
 
end

