function DebugBlocks(Blocks,DisplayIndexes)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

DisplayCount=max(size(DisplayIndexes));

for i=1:DisplayCount
  BlockIndex=DisplayIndexes(i)
  Parent=Blocks.Parent{BlockIndex}
  Active=Blocks.Active{BlockIndex}
  Data=Blocks.Data{BlockIndex}
  RowCount=Blocks.RowCount{BlockIndex}
  ColCount=Blocks.ColCount{BlockIndex}
  RowIndexes=Blocks.mRowIndexes{BlockIndex}
  ColIndexes=Blocks.mColIndexes{BlockIndex}
  ColMeans=Blocks.ColMeans{BlockIndex}
  RowMeans=Blocks.RowMeans{BlockIndex}'
  RowFixed=Blocks.RowFixed{BlockIndex}
  ColFixed=Blocks.ColFixed{BlockIndex}
end

end
