function [Basic,CCT] = CCTReliabilitySp(X,MissingVal,d,Bias,IE)
%Reliability for continuous cultural consensus analysis.  This procedure
%returns the continuous reliability metric iota, as defined by Janson and Olson (2001)
%and also the consensus adjusted reliability metric, as defined by France
%and Batchelder.  Works for all models except for the additive item easiness model
%INPUTS
%X - The n user*m item matrix of ratings
%MissingVal - The indicator for missing value
%d   - An n*1 vector of user competencies
%Bias - An n*2 vecttor of biases (1st column additive, 2nd column multiplicative)
%IE   - A continuous m*1 answer key vector
%OUTPUTS
%Basic - The Basic reliability coefficient
%CCT - The CCT reliability coefficient, incorporating competency, bias, and item easiness
%Version     Author            Date
%   2.00     Stephen France    04/01/2016
%   2.50     Stephen France    06/08/2017
tic
[n,m]=size(X);
[r,c,v]=find(X~=MissingVal);
v=X(X~=MissingVal);

AllX=[r,c,v];
dn=size(AllX,1);
%Find the observed values
Obs=0;Exp=0;
WObs=0;WExp=0;
for i=1:n
  AllXTes=AllX(r==i,:);
  AllXRem=AllX(r~=i,:);
  nTes=size(AllXTes,1);mRem=size(AllXRem,1);
  %Remove each item and compare with the others
  WExp=WExp+mRem*nTes;
  C2=AllXRem(:,3);
  for j=1:nTes
    C1=repmat(AllXTes(j,3),mRem,1);
    Exp=Exp+sum((C1-C2).^2);
  end
end


for k=1:m
  AllX2=AllX(c==k,:);
  dns=size(AllX2,1);
  for i=1:dns 
    C1=repmat(AllX2(i,3),dns-1,1);
    C2=[AllX2(1:i-1,3);AllX2(i+1:dns,3)];
    Obs=Obs+sum((C1-C2).^2);
  end
  WObs=WObs+dns*(dns-1);
end

Obs=Obs./WObs; %Normalize expected values
Exp=Exp./WExp;

Basic=1-Obs./Exp;

%Adjust the values for the competencies
X=X-Bias(:,1)*ones(1,m);
X=X./(Bias(:,2)*ones(1,m));

X2=X.*(X~=-MissingVal);

[r,c,v]=find(X2);

AllX=[r,c,v];

dn=size(AllX,1);


%Find the observed values
Obs=0;Exp=0;
WObs=0;WExp=0;

for i=1:n
  AllXTes=AllX(r==i,:);
  AllXRem=AllX(r~=i,:);
  nTes=size(AllXTes,1);nRem=size(AllXRem,1);
  %Remove each item and compare with the others
  C2=AllXRem(:,3);
  d2=d(AllXRem(:,1));
  IE2=IE(AllXRem(:,2))';
  for j=1:nTes
    C1=repmat(AllXTes(j,3),nRem,1);
    d1=repmat(d(AllXTes(j,1)),nRem,1);
    IE1=repmat(IE(AllXTes(j,2)),nRem,1);
    Weight=d1.*d2.*IE1.*IE2;
    Exp=Exp+sum(Weight.*((C1-C2).^2));
    WExp=WExp+sum(Weight);
  end
end

for k=1:m
  AllX2=AllX(c==k,:);
  dns=size(AllX2,1);
  for i=1:dns 
    C1=repmat(AllX2(i,3),dns-1,1);
    dval=repmat(d(AllX2(i,1)),dns-1,1);
    IEVal=repmat(IE(AllX2(i,2)),dns-1,1);
    C2=[AllX2(1:i-1,3);AllX2(i+1:dns,3)];
    dval2=d([AllX2(1:i-1,1);AllX2(i+1:dns,1)]);
    IEVal2=IE([AllX2(1:i-1,2);AllX2(i+1:dns,2)])';
    Obs=Obs+sum(dval.*dval2.*IEVal.*IEVal2.*(C1-C2).^2);
    WObs=WObs+sum(dval.*dval2.*IEVal.*IEVal2);
  end

end

Obs=Obs./WObs; %Normalize expected values
Exp=Exp./WExp;

CCT=1-Obs./Exp;

timediff=toc
tic



