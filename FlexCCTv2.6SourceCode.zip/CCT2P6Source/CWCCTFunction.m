function [OptValue,RealHR,RealFPR] = CWCCTFunction(X,Z,C,OptFunction)
%Calculates the maximum likelihood function for cultural consensus theory
%where there is a binary true/false response.
%INPUTS
%X -          An n*m subject*item matrix
%Z -          A c*m answer key vector
%C -          A n*c cluster matrix.
%OptFunction-  The function to maximize/minimize
%          - 0 Linear Function (hits - false positives)
%          - 1 Maximum Likelihood function
%          - 2 1/2 a Maximum Likelihood function (only HR and (1-FPR)
%OUTPUTS
%OptValue  - The value of the function
%RealHR    - An n*0 vector of hit rates
%RealFP    - An n*1 vector of false positive rates
%Version     Author            Date
%   0.10     Stephen France    04/20/2012

  BigN=1E6;

  [n,m]=size(X);

  %Firstly calculate the values of D and g
  Hits=X.*(C*Z);
  FPositives=X.*(1-(C*Z));
  %Proportion of hits and false positives)
  %If Z=1 for all items or Z=0 for all items then the problem is not
  %Fully defined (take as 0 (e.g. no false positives or hits)
  RealHR=sum(Hits,2)./(sum(C*Z,2));
  HR=sum(Hits,2)./(sum(C*Z,2)+(sum(C*Z,2)==0));
  RealFPR=sum(FPositives,2)./(sum(1-C*Z,2));
  FPR=sum(FPositives,2)./(sum(1-C*Z,2)+(sum(1-C*Z,2)==0));  
  
  %Ensure penalties for breaking model assumptions.
  Penalty=sum(max(RealFPR-HR,0))*BigN;
  
  if (OptFunction==0)
    OptValue=Penalty+sum(FPR)-sum(HR);
  else
    %If all values are 0 then ignore likelihood terms.  Can do this
    %As all values of the second term will be 0.  Ensure that 
    
    LogHR=log(HR+(HR==0));
    LogFPR=log(FPR+(FPR==0));
    LogNHR=log((1-HR)+((1-HR)==0));
    LogNFPR=log((1-FPR)+((1-FPR)==0));
    
    %Calculate maximum likelihood
    HitLK=(LogHR*ones(1,m)).*(X.*(C*Z));
    FPLK= (LogFPR*ones(1,m)).*(X.*(1-(C*Z)));
    NotHitLK=(LogNHR*ones(1,m)).*((1-X).*(C*Z));
    NotFPLK=(LogNFPR*ones(1,m)).*((1-X).*(1-(C*Z)));
    if (OptFunction==1)
      OptValue=(sum(sum(HitLK))+sum(sum(FPLK))+sum(sum(NotHitLK))+sum(sum(NotFPLK)));
    else
      %Only take 1/2 the parameters (HR and (1-FPR))
      OptValue=(sum(sum(HitLK))+sum(sum(NotFPLK)));
    end  
    %Matlab sometimes has complex number, probably slight rounding error
    OptValue=Penalty-real(OptValue);
  end
end

