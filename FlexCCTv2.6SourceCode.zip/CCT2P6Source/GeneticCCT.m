function [BestResults,RunTime] = GeneticCCT(X,OptFunction,STemp,ETemp,CTemp,TermIt,IsMissing,MissingVal,InitialZ)
%The maximum likelihood approach for Cultural Consensus Theory.  Missing
%data will be dealt with with setting each element of the likelihood
%function with missing data to 1 (the log likelihood for the element will
%be 0)
%
%Inputs 
%X - An n*m subject*item matrix
%OptFunction-The function to maximize/minimize
%          - 0 Linear Function (hits - false positives)
%          - 1 Maximum Likelihood function
%          - 2 The half maximum likelihood function
%          - 3 Maximum likelihood function, but weighting on compentencies
%          from the majority rule
%STemp     - The start temperature for the annealing process
%ETemp     - The end temperature for the annealing process
%CTemp     - The change in temperature for each stage of the annealing
%            proceess
%TermIt    - The number of iterations with no change before terminating
%IsMissing - 1 if missing data and 0 if no missing data
%MissingVal- The identifier for missing data (should be outside range of actual values) 
%InitialZ  - An initial value for Z (defaults to random soln)
%Outputs (for best solution)
%BestResults - A results variable consisting of the following 
%------------------------------------------------------------
%Z - An 1*m  answer key vector
%D - An n*1 vector of competencies
%g - An n*1 set of bias parameters
%f - The "maximum" value of the log likelihood function
%HR - The hit rate (X=1 Z=1)
%FPR - The false positive rate (X=1 Z=0)
%------------------------------------------------------------ 
%RunTime - The runtime for the algorithm
%IDD1,IDDiff1 - D and item difficulty for ratio estimation (see CalVarDiff)
%IDD2,IDDiff2,SEIDD,SEIDDiff2,Resid - Values from Rasch estimation (see
%CalcVarDiffRasch)
%LKRatio - Likelihood rati
%Version     Author            Date
%   0.10     Stephen France    04/20/2012

  [n,m]=size(X);
  tic;
  
  %Check out the initial values of Z
  if (IsMissing==1)
    P=(X~=MissingVal);
  end
  
  %Check out the initial values of Z
  if ~exist('InitialZ','var')
    InitialZ=round(rand(1,m));
  end
  
  %Calculate weights
  if (OptFunction==3)
    [TempZ,TempD,Tempg] = CCTMajorityRule(X,0);
    W=TempD*ones(1,m);
    OptFunction=1;  %Now use maximum likelihood with the weights
  else
    W=ones(n,m);
  end
  
  
  BestZ=InitialZ;
  CurZ=InitialZ;
  CurTemp=STemp;
  
  %Calculate the initial value
  if (IsMissing==0)
    [f,HR,FPR] = CCTFunction(X,CurZ,OptFunction,W);
  else
    [f,HR,FPR] = CCTFunctionMissing(X,CurZ,P,OptFunction,W);
  end
  Bestf=f;
  BestHR=HR;
  BestFPR=FPR;
  
  NoChangeIt=0;
  %Terminate if out of annealing schedule + no change for TermIt 
  while (NoChangeIt<TermIt) || (CurTemp>ETemp)
    ZChange=floor(rand()*m)+1;
    TestZ=CurZ;
    TestZ(ZChange)=mod(TestZ(ZChange)+1,2);     %Assume a zero one Z
    
    if (IsMissing==0)
      [fNew,HR,FPR] = CCTFunction(X,TestZ,OptFunction,W);
    else
      [fNew,HR,FPR] = CCTFunctionMissing(X,TestZ,P,OptFunction,W);
    end
    fChange=fNew-f;
    
    if fChange<0
      Accept=true;
    else
      PAccept=exp(-fChange/CurTemp);
      %Implement the simulated annealing
      if rand<PAccept
        Accept=true;
      else
        Accept=false;
      end
    end
  
    if (Accept==true)
      f=fNew;
      CurZ=TestZ;
      if f<Bestf
        BestZ=CurZ;
        Bestf=f;
        BestHR=HR;
        BestFPR=FPR;
      end
      NoChangeIt=0;
    else
      NoChangeIt=NoChangeIt+1;
    end
    CurTemp=max(ETemp,CurTemp-CTemp);

  end

RunTime=toc;

BestResults.HR=BestHR;
BestResults.FPR=BestFPR;
BestResults.Z=BestZ;
BestResults.f=Bestf;
%Calculate the values of D and g
BestResults.D=BestHR-BestFPR;
%If perfect D then (1-D)=0 and g is undefined.  Set to allow bias to be 0
Denom=(1-BestResults.D);%+((1-D)==0);
BestResults.g=BestResults.FPR./Denom;

%Calculate Rash difficulties using ratio forumula
[MinVal,IDD,IDDiff]=CalcVarDiff(X,BestZ,1E6);
BestResults.IDD1=IDD;
BestResults.IDDiff1=IDDiff;
%Calculate Rasch competencies and item difficulties, using an edge correct
%of two items and a prior of 0.5.
[IDD,IDDiff,SEIDD,SEIDDiff,Resid] = CalcVarDiffRasch(X,BestZ,2,0.5);
BestResults.IDD2=IDD;
BestResults.IDDiff2=IDDiff;
BestResults.SEIDD=SEIDD; 
BestResults.SEIDDiff2=Resid; 
BestResults.Resid=Resid;
%Calculate maximum likelihood ratios for individual quesgtions
if (IsMissing==0)
  [LKRatio] = LKHoodStats(X,BestZ,W);
else
  [LKRatio] = LKHoodStats(X,BestZ,W,P);
end
BestResults.LKRatio=LKRatio;

