
MinScale=0.5;
IsRun=false;
OverallRun=0;


for NoItems=200:200:1000
  for NoUsers=200:200:1000
    for Scale=5:10
      Range=Scale-1;
      Centre=1+(Range/2);
      for TrueDist=1:2
        for MissingPC=0:20:80
          for Scheme=1:5
            for DMax=5:5
                %for RangeDivisor=5:2:11
                %First randomly select true review scores
                if TrueDist==1
                  %Sample from normal distribution with mean at the center
                  %point and with 1 standard devation = 1/6 range
                  z = norminv(rand(1,NoItems),Centre,Range/6);
                else
                  %Sample from uniform distribution
                  z=(rand(1,NoItems).*Range)+1;
                end
                %Determine latent competencies for users
                Mind=(Range/3)^(-2);
                Midd=(Range/6)^(-2);
                Maxd=(Range/9)^(-2);
                switch Scheme
                case 1
                  %Select all users to have the average competancy
                  D=ones(NoUsers,1).*Midd;
                case 2
                  %Random competencies between min and max
                  D=Mind+rand(NoUsers,1).*(Maxd-Mind);
                case 3
                  %75% competent and 25% not competent
                  IsComp=rand(NoUsers,1)>0.25;
                case 4
                  %50% competent and 50% not competent
                  IsComp=rand(NoUsers,1)>0.5;
                case 5 
                  %25% competent and 75% not competent
                  IsComp=rand(NoUsers,1)>0.75;              
                end
                switch Scheme
                  case {3,4,5}
                  %Users competent if one and not competent if 0
                  D=IsComp.*Maxd+(1-IsComp).*Mind;
                end

                for AddBias=0:1
                  for MultBias=0:1
                    if AddBias==0
                      Bias=zeros(NoUsers,1);
                    else
                      Bias=norminv(rand(NoUsers,1),0,Range/10);
                    end 
                    if MultBias==0
                      Bias=[Bias,ones(NoUsers,1)];
                    else
                      Bias=[Bias,norminv(rand(NoUsers,1),1,0.1)];
                    end
                    %Now sample an answer key given the competency and the true
                    %score
                    %Sample an error matrix based on competencies
                    Error=zeros(NoUsers,NoItems);
                    for i=1:NoUsers
                      P=rand(1,NoItems);
                      Error(i,:) = norminv(P,0,(D(i)^(-0.5)));
                    end
                    %Add the error to the actual values of the items
                    X=Bias(:,2)*z+Bias(:,1)*ones(1,NoItems)+Error;
                    X=round(X);
                    X=min(max(1,X),Scale);   %Ensure in bounds
                    %Replace any missing data by -1
                    IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                    AllAssigned=isempty(find(sum(1-IsMissing,1)==0))&&isempty(find(sum(1-IsMissing,2)==0));
                    while (AllAssigned==0)
                      IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                      [IsMissing,AllAssigned]=FixMissing(IsMissing,1000);
                    end
                    X=-IsMissing+(1-IsMissing).*X;
                  
                    for Identify=-1:1
                      OverallRun=OverallRun+1;
                      
                        Results=[OverallRun,NoItems,NoUsers,Scale,TrueDist,MissingPC,Scheme,DMax,AddBias,MultBias,Identify];
                        if mod(OverallRun,10)==0
                          OverallRun
                        end
                        %0 is no identify, 1 is soft identify, 2 is hard
                        %identify 
                        [z0,D0,Bias0,QE0,MaxCrit0,LLPartial0] = ContinuousCCT4(X,0,0,[0,0,0,0],[1e-6,1000,1],-1,DMax,DMax);
                        [IC] = InformationCriteria(MaxCrit0,NoItems+NoUsers,sum(sum(1-IsMissing)));
                        [z2,D2,Bias2,QE2,MaxCrit2,LLPartial2] = ContinuousCCT4(X,2,0,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
                        [IC2] = InformationCriteria(MaxCrit2,NoItems+NoUsers,sum(sum(1-IsMissing)));
                        if AddBias==0&&MultBias==0  
                          [z4,D4,Bias4,QE4,MaxCrit4,LLPartial4] = ContinuousCCT4(X,2,0,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
                        elseif AddBias==1&&MultBias==0
                          [z4,D4,Bias4,QE4,MaxCrit4,LLPartial4] = ContinuousCCT4(X,2,1,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
                        elseif AddBias==0&&MultBias==1
                          [z4,D4,Bias4,QE4,MaxCrit4,LLPartial4] = ContinuousCCT4(X,2,2,[Identify,Identify,0,0],[1e-6,1000,1],-1,DMax,DMax);
                        else
                          [z4,D4,Bias4,QE4,MaxCrit4,LLPartial4] = ContinuousCCT4(X,2,3,[Identify,Identify,Identify,0],[1e-6,1000,1],-1,10,10);
                        end
                        [IC4] = InformationCriteria(MaxCrit4,NoItems+NoUsers,sum(sum(1-IsMissing)));
                        %Calculate all of the comparison statistics
                        [z5] = CCTAggregate(X,-1,1);   %straight arithmetic mean
                        [z6] = CCTAggregate(X,-1,2);   %straight geometric mean
                        [z7] = CCTAggregate(X,-1,3,1e-6); %combined arithmetic/geometric mean
                        [z8] = CCTAggregate(X,-1,4);   %The harmonic mean                  
                        [z9] = CCTAggregate(X,-1,5);   %Variance adjusted mean
                        Results2=zeros(1,30);
                        if IC2.AIC<0
                         temp=0;
                        end
                        %Calculate the MAE and MSE between Ds for all models
                        Results2(1)=sum((D-D2).^2)./NoUsers;
                        Results2(2)=sum(abs(D-D2))./NoUsers;
                        Results2(3)=sum((D-D4).^2)./NoUsers;
                        Results2(4)=sum(abs(D-D4))./NoUsers; 
                        %Now calculate the accuracy of z
                        Results2(5)=sum((z-z0).^2)./NoItems;
                        Results2(6)=sum(abs(z-z0))./NoItems;
                        Results2(7)=sum((z-z2).^2)./NoItems;
                        Results2(8)=sum(abs(z-z2))./NoItems;
                        Results2(9)=sum((z-z4).^2)./NoItems;
                        Results2(10)=sum(abs(z-z4))./NoItems;
                        Results2(11)=sum((z-z5).^2)./NoItems;
                        Results2(12)=sum(abs(z-z5))./NoItems;
                        Results2(13)=sum((z-z6).^2)./NoItems;
                        Results2(14)=sum(abs(z-z6))./NoItems;
                        Results2(15)=sum((z-z7).^2)./NoItems;
                        Results2(16)=sum(abs(z-z7))./NoItems;
                        Results2(17)=sum((z-z8).^2)./NoItems;
                        Results2(18)=sum(abs(z-z8))./NoItems;
                        Results2(19)=sum((z-z9).^2)./NoItems;
                        Results2(20)=sum(abs(z-z9))./NoItems;
                        %Now calculate the actual additive and multiplicative
                        %biases
                        Results2(21)=sum((Bias(:,1)-Bias4(:,1)).^2)./NoItems;
                        Results2(22)=sum(abs(Bias(:,1)-Bias4(:,1)))./NoItems;
                        Results2(23)=sum((Bias(:,2)-Bias4(:,2)).^2)./NoItems;
                        Results2(24)=sum(abs(Bias(:,2)-Bias4(:,2)))./NoItems;        

                        %Return the AIC,AICc, and BIC for the two models
                        Results2(25)=IC2.AIC;
                        Results2(26)=IC2.CorAIC;
                        Results2(27)=IC2.BIC;
                        Results2(28)=IC4.AIC;
                        Results2(29)=IC4.CorAIC;
                        Results2(30)=IC4.BIC;

                        NewResults=[Results,Results2];

                        save 'C:\CCOut\CONCLUSV2\BiasTest.txt' NewResults -append -ascii;
                    end                
                  end
                end

              %end
            end
          end
        end
      end
    end
  end
end