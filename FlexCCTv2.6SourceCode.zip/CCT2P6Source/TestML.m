X=Contagious;

[n,m]=size(X);
Results=[];

for i=0:m
  Z1=[ones(1,i),zeros(1,m-i)]
  Z2=1-Z1
  [OptValue1,HR,FPR] = CCTFunction(Contagious,Z1,1);
  [OptValue2,HR,FPR] = CCTFunction(Contagious,Z2,1);
  Results=[Results;[i,OptValue1,OptValue2]];

 end