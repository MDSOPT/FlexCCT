function [ConvergeFailNo,Blocks] = CONCOR(X,N,CMode,SimParams,Converge,MaxIter,MissingVal)
%An algorithm for clustering relational data, as described in Brieger,
%Borman and Arabie (1975). The user gives the predefined number of clusters
%and the algorithm gives a tree structure.
%Inputs
%X - An n*m input matrix
%N - The number of clusters to be employed
%CMode - 0 Cluster the rows
%        1 Cluster the columns
%SimParms - Parameters for the similarity transformations. [3] gives
%cosine, and [1,3] gives correlation (see CalSimilarity for more details)
%Converge - The convergence value for the similarity transforms
%MaxIter - The maximum number of iterations for the similarity transforms
%MissingVal - The indicator for a missing value boundary of max(abs-1)
%Outputs
%ConvergeFailNo - 0 if the similarity transformation converges for all
%clusters, otherwise i where i is the current number of clusters
%clusters, otherwise i is the cluster split where the fail occured
%Blocks - A set of detailed cluster information for the block clusters

  [n,m]=size(X);

  if exist('MissingVal','var')
    P=+~(X==MissingVal);
  else
    P=ones(n,m);
  end
  
  %Give information for the base block (e.g. all of the items)
  Blocks.Count=1;
  Blocks.ActiveCount=1;
  Blocks.Active{1}=1;
  Blocks.Data{1}=X;
  Blocks.P{1}=P;
  Blocks.Parent{1}=0;
  if (CMode==0)
    %Cluster on rows
    Blocks.ItemCount{1}=n; 
    Blocks.mItemIndexes{1}=find(ones(1,n));
  else
    Blocks.ItemCount{1}=m; 
    Blocks.mItemIndexes{1}=find(ones(1,m));
  end
  
  for i=2:N
    %Split the cluster with the highest in cluster variance
    if (Blocks.Count==1)
      CurBlock=1;
    else
      %Split the block with the worst fit
      MaxVariance=-1;
      for j=2:Blocks.Count   %First block doesn't have this information
        if (Blocks.Active{i}==1)
          if Blocks.AvgVar{i}>MaxVariance
            CurBlock=i;
          end
        end
      end
    end
    
    if (CMode==0)
      %Cluster on rows
      [ConvergeFail,Cluster1IX,Cluster2IX,FinalS,BinBlock] = SimConverge(Blocks.Data{CurBlock},Converge,MaxIter,SimParams,Blocks.P{CurBlock});
      if (ConvergeFail==0)
        Blocks.Data{Blocks.Count+1}=Blocks.Data{CurBlock}(Cluster1IX,:);
        Blocks.Data{Blocks.Count+2}=Blocks.Data{CurBlock}(Cluster2IX,:);
        Blocks.P{Blocks.Count+1}=Blocks.P{CurBlock}(Cluster1IX,:);
        Blocks.P{Blocks.Count+2}=Blocks.P{CurBlock}(Cluster2IX,:);
        %Find average column variance
        Blocks.AvgVar{Blocks.Count+1}=mean(spvar(Blocks.Data{Blocks.Count+1},Blocks.P{Blocks.Count+1},1));
        Blocks.AvgVar{Blocks.Count+2}=mean(spvar(Blocks.Data{Blocks.Count+2},Blocks.P{Blocks.Count+2},1));
      else
        ConvergeFailNo=i;
      end
    else
      %Cluster on columns
      [ConvergeFail,Cluster1IX,Cluster2IX,FinalS,BinBlock] = SimConverge(Blocks.Data{CurBlock}',Converge,MaxIter,SimParams,Blocks.P{CurBlock}');
      if (ConvergeFail==0)
        Blocks.Data{Blocks.Count+1}=Blocks.Data{CurBlock}(:,Cluster1IX);
        Blocks.Data{Blocks.Count+2}=Blocks.Data{CurBlock}(:,Cluster2IX);
        Blocks.P{Blocks.Count+1}=Blocks.P{CurBlock}(:,Cluster1IX);
        Blocks.P{Blocks.Count+2}=Blocks.P{CurBlock}(:,Cluster2IX);
        %Find average row variance
        Blocks.AvgVar{Blocks.Count+1}=mean(spvar(Blocks.Data{Blocks.Count+1},Blocks.P{Blocks.Count+1},2));
        Blocks.AvgVar{Blocks.Count+2}=mean(spvar(Blocks.Data{Blocks.Count+2},Blocks.P{Blocks.Count+2},2));
      else
        ConvergeFailNo=i;
        sprintf('Algorithm does not converge at cluster split %d.',i)
        return;
      end
    end
    
    %Save summary of the splitting/convergence results
    Blocks.FinalSim{CurBlock}=FinalS;
    Blocks.BlockSim{CurBlock}=BinBlock;
    %Set parent cluster to be inactive and populate remainder of 2 new clusters
    %Parent block is now inactive.  Child clusters point to the parent.
    Blocks.Active{CurBlock}=0;
    Blocks.Active{Blocks.Count+1}=1;
    Blocks.Active{Blocks.Count+2}=1;
    Blocks.Parent{Blocks.Count+1}=CurBlock;
    Blocks.Parent{Blocks.Count+2}=CurBlock;
    %Indexes should be relative to the overall indexes
    Blocks.mItemIndexes{Blocks.Count+1}=Blocks.mItemIndexes{CurBlock}(Cluster1IX);
    Blocks.mItemIndexes{Blocks.Count+2}=Blocks.mItemIndexes{CurBlock}(Cluster2IX);
    Blocks.ItemCount{Blocks.Count+1}=size(Cluster1IX,2);
    Blocks.ItemCount{Blocks.Count+2}=size(Cluster2IX,2);
    Blocks.Count=Blocks.Count+2;
    Blocks.ActiveCount=Blocks.ActiveCount+1;
  end
  ConvergeFailNo=0;
  
  
end

