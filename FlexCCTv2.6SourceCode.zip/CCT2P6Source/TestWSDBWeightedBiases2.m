%Set experiment as peer grading

EDesign=load('EDesign1.mat');
EDesign1=EDesign.EDesign1;
AllResults=[];
MinScale=0.5;
OverallRun=0;

NoRuns=size(EDesign1,1);
for i=1:NoRuns
  NoUsers=EDesign1(i,1);
  NoItems=NoUsers;
  Scale=EDesign1(i,2);
  TrueDist=EDesign1(i,3);
  Scheme=EDesign1(i,4);
  RangeDivisor=EDesign1(i,5);
  %Defaults are not included in the experiment
  MissingPC=0;
  DMax=0;


%First randomly select true review scores
if TrueDist==1
  %Sample from normal distribution with mean at the center
  %point and with 1 standard devation = 1/6 range
  z = norminv(rand(1,NoItems),Centre,Range/5);
else
  %Sample from uniform distribution
  z=(rand(1,NoItems).*Range)+1;
end
%Determine latent competencies for users
Mind=(Range/3)^(-2);
Midd=(Range/6)^(-2);
Maxd=(Range/9)^(-2);
switch Scheme
case 1
  %Select all users to have the average competancy
  D=ones(NoUsers,1).*Midd;
case 2
  %Random competencies between min and max
  D=Mind+rand(NoUsers,1).*(Maxd-Mind);
case 3
  %75% competent and 25% not competent
  IsComp=rand(NoUsers,1)>0.25;
case 4
  %50% competent and 50% not competent
  IsComp=rand(NoUsers,1)>0.5;
case 5 
  %25% competent and 75% not competent
  IsComp=rand(NoUsers,1)>0.75;              
end
switch Scheme
  case {3,4,5}
  %Users competent if one and not competent if 0
  D=IsComp.*Maxd+(1-IsComp).*Mind;
end
%Select biases based upon the range divisor
Biases= norminv(rand(NoUsers,1),0,Range/RangeDivisor);
%Calculate the full biases
BiasFull=(Biases(:,1))*ones(1,NoItems);
BiasPos=((Biases(:,1)>0)*ones(1,NoItems));
WeightedBias=BiasFull.*(BiasPos.*(ones(NoUsers,1)*((Scale-z)./(Scale-1)))+(1-BiasPos).*(ones(NoUsers,1)*((z-1)./(Scale-1))));

%Now sample an answer key given the competency and the true
%score
%Sample an error matrix based on competencies
Error=zeros(NoUsers,NoItems);
for i=1:NoUsers
  P=rand(1,NoItems);
  Error(i,:) = norminv(P,0,(D(i)^(-0.5)));
end
%Add the error to the actual values of the items
X=ones(NoUsers,1)*z+WeightedBias+Error;
X=round(X);
X=min(max(1,X),Scale);   %Ensure in bounds         

%Assign each user to a set of random items, ensuring that 
%the current item is not included (set n-1 items and shift
%items at the current item or higher up by 1)
ChosenItems=zeros(NoUsers,NoPerUser);
%Calculate permutations for each row
for AssignNo=1:NoPerUser
  ChosenItems(:,AssignNo)=randperm(NoUsers)';
  if AssignNo>1
    IsRepeat=true;
    while IsRepeat==true
      %Now must ensure that the same item is not included twice
      TestItems=ChosenItems(:,AssignNo)*ones(1,AssignNo-1);
      Match=sum(TestItems==ChosenItems(:,1:AssignNo-1),2);
      [row,col]=find(Match);
      if ~isempty(row)
        for SwapNo=1:size(row,1)
          Swap1=row(SwapNo);
          Swap2=floor(rand()*NoUsers)+1;
          %Swap with random row
          temp=ChosenItems(Swap1,AssignNo);
          ChosenItems(Swap1,AssignNo)=ChosenItems(Swap2,AssignNo);
          ChosenItems(Swap2,AssignNo)=temp;
        end
      else
        IsRepeat=false;
      end
    end
  end
end
%Get basic item matrix
Users=(1:NoUsers)'*ones(1,NoPerUser);
SparseP=[reshape(Users,NoUsers*NoPerUser,1),reshape(ChosenItems,NoUsers*NoPerUser,1),ones(NoUsers*NoPerUser,1)];
P=full(spconvert(SparseP));

X=-(1-P)+P.*X;
for Replications=1:1
  OverallRun=OverallRun+1
  if OverallRun==47
    IsRunning=true;
  end
%                   if mod(OverallRun,10)==0
%                     OverallRun
%                   end
  if IsRunning==true
    Results=[DMax,NoItems,NoUsers,Scale,TrueDist,MissingPC,Scheme,RangeDivisor];
    %Now run continuous cultural consensus theory
    [z0,D0,Biases0,QE,MaxCrit0,LLPartial] = ContinuousCCT5(X,0,0,[0,0,0,0],[1e-6,1000,1],[-1,1,Scale],5,5);
    [z1,D1,Biases1,QE,MaxCrit1,LLPartial] = ContinuousCCT5(X,2,0,[0,0,0,0],[1e-6,1000,1],[-1,1,Scale],5,5);                  
    [z2,D2,Biases2,QE,MaxCrit2,LLPartial] = ContinuousCCT5(X,2,4,[0,0,0,0],[1e-6,1000,1],[-1,1,Scale],5,5);
    [z3,D3,Biases3,QE,MaxCrit3,LLPartial] = ContinuousCCT5(X,2,4,[1,0,0,0],[1e-6,1000,1],[-1,1,Scale],5,5);
    [z4,D4,Biases4,QE,MaxCrit4,LLPartial] = ContinuousCCT5(X,2,4,[-1,0,0,0],[1e-6,1000,1],[-1,1,Scale],5,5); 
    [IC0] = InformationCriteria(MaxCrit0,NoUsers*2,NoUsers*NoPerUser);
    [IC1] = InformationCriteria(MaxCrit1,NoUsers*2,NoUsers*NoPerUser);
    [IC2] = InformationCriteria(MaxCrit2,NoUsers*2,NoUsers*NoPerUser);
    [IC3] = InformationCriteria(MaxCrit3,NoUsers*2,NoUsers*NoPerUser);
    [IC4] = InformationCriteria(MaxCrit4,NoUsers*2,NoUsers*NoPerUser);
    Results2=zeros(1,45);

    %Calculate the MAE and MSE between Ds for all models
    Results2(1)=sum(abs(D-D0))./NoUsers;
    Results2(2)=sum(abs(D-D1))./NoUsers;
    Results2(3)=sum(abs(D-D2))./NoUsers;
    Results2(4)=sum(abs(D-D3))./NoUsers;
    Results2(5)=sum(abs(D-D4))./NoUsers;
    Results2(6)=sum((D-D0).^2)./NoUsers;
    Results2(7)=sum((D-D1).^2)./NoUsers;                  
    Results2(8)=sum((D-D2).^2)./NoUsers;
    Results2(9)=sum((D-D3).^2)./NoUsers;
    Results2(10)=sum((D-D4).^2)./NoUsers;                   
    %Now calculate the accuracy of z
    Results2(11)=sum(abs(z-z0))./NoItems;
    Results2(12)=sum(abs(z-z1))./NoItems;                  
    Results2(13)=sum(abs(z-z2))./NoItems;
    Results2(14)=sum(abs(z-z3))./NoItems;
    Results2(15)=sum(abs(z-z4))./NoItems;
    Results2(16)=sum((z-z0).^2)./NoItems;
    Results2(17)=sum((z-z1).^2)./NoItems;                  
    Results2(18)=sum((z-z2).^2)./NoItems;
    Results2(19)=sum((z-z3).^2)./NoItems;
    Results2(20)=sum((z-z4).^2)./NoItems;                  
    %Now calculate the actual biases
    Results2(21)=sum(abs(Biases-Biases2(:,1)))./NoItems; 
    Results2(22)=sum(abs(Biases-Biases2(:,1)))./NoItems;                   
    Results2(23)=sum(abs(Biases-Biases2(:,1)))./NoItems;               
    Results2(24)=sum(abs(Biases-Biases3(:,1)))./NoItems;  
    Results2(25)=sum(abs(Biases-Biases4(:,1)))./NoItems;
    Results2(26)=sum((Biases-Biases0(:,1)).^2)./NoItems;                    
    Results2(27)=sum((Biases-Biases1(:,1)).^2)./NoItems;                    
    Results2(28)=sum((Biases-Biases2(:,1)).^2)./NoItems;               
    Results2(29)=sum((Biases-Biases3(:,1)).^2)./NoItems;  
    Results2(30)=sum((Biases-Biases4(:,1)).^2)./NoItems;                  
    %Return the AIC,AICc, and BIC for the two models
    Results2(31)=IC0.AIC;
    Results2(32)=IC0.CorAIC;
    Results2(33)=IC0.BIC;                  
    Results2(34)=IC1.AIC;
    Results2(35)=IC1.CorAIC;
    Results2(36)=IC1.BIC;                  
    Results2(37)=IC2.AIC;
    Results2(38)=IC2.CorAIC;
    Results2(39)=IC2.BIC;
    Results2(40)=IC3.AIC;
    Results2(41)=IC3.CorAIC;
    Results2(42)=IC3.BIC;
    Results2(43)=IC4.AIC;
    Results2(44)=IC4.CorAIC;
    Results2(45)=IC4.BIC;
    NewResults=[Results,Results2];
    save 'C:\CCOut\Biases2014.txt' NewResults -append -ascii;  
  end
