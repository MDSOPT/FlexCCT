function [F,Residual,MinVal] = ResidualFA2(X,InitialMode,OptLevel,Epsilon,InitialF)
%Residual factor analysis using a nonlinear optimization technique
%Inputs
%X - An n*n data matrix to be decomposed
%InitialMode - The mode for the initial solution
%            - 0 A fixed soln, defaults to all entries equal to 0.5
%            - 1 A random soln, with all elements drawn from uniform - [0.1]
%OptLevel - If OptMethod = 3 then the level of the optimization procedure used 
%          - 0 Use non-derivative optimization method
%          - 1 Also use the first derivatives (gradient vector)
%          - 2 Also use the second derivatives (Hessian matrix)
%Epsilon   - The convergence criteria
%InitialF - An n*1 initial soln.  Defaults to a random solution from uniform
%distribution in range [0,1]
%Outputs
%F - (n*NFactor) -    The factors to be extracted to approximate (F-X'X)
%Lambda - (NFactor) - The values of the eigenvalues
%Residual -  X-F'F
%Version     Author            Date
%   0.10     Stephen France    04/01/2012

n=size(X,1);

if ~exist('Epsilon','var')
  Epsilon=1e-6;
end

%Configure initial solution
if (InitialMode == 0)
  %Fixed solution
  if ~exist('InitialF','var')
    InitialF=ones(n,1).*0.5;
  end
else
  %Random solution
  InitialF=rand(n,1);
end
X=X-diag(diag(X));
%Set the level of optimisation
switch OptLevel
  case 0
    options = optimset('GradObj','off','Hessian','off','Display','off');
    f = @(x)faMin0(x,X);
  case 1
    options = optimset('GradObj','on','Hessian','off','Display','off');
    f = @(x)faMin1(x,X);
  case 2
    options = optimset('GradObj','on','Hessian','on','Display','off');
    f = @(x)faMin2(x,X);
end


[F,MinVal] = fminunc(f,InitialF,options);
SqF=F*F';
Residual=X-(SqF-diag(diag(SqF)));
  






