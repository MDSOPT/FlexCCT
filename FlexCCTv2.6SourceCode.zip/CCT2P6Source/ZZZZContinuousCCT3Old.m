function [z,D,Bias,QE,MaxCrit,LLPartial] = ContinuousCCT3(X,EstMethod,BiasType,FixParams,OptParams,MissingVal,OptLevel,DMax,IEMax,DPrior)
%An implementation of continuous Cultural Consensus Theory as described
%in Batchelder and Romney (1988) and France and Batchelder (2013).  In this
%version, the answer key z and competencies b are fit initially and then
%other parameters are estimated with z fixed, all using first order
%conditions and a fixed point optimization routine.
%Inputs
%X - An n*m subject*item input matrix
%EstMethod - The estimation method
%          - 0 Average value
%          - 1 Min Res factor analysis
%          - 2 Maximum likelihood estimation
%          - 3 Item difficulty model no 1 Additive Variances
%          - 4 Item difficulty model no 2 dij=alpha(i)*beta(j)
%          - 5 Item difficulty model no 3 dij=alpha(i)+beta(j)   
%          - 6 The Weber-Fechner model, where variance = zk^2/(d^p)
%BiasType  - 0 No bias
%          - 1 Fit additive bias
%          - 2 Fit multiplicative bias
%          Currently bias 1 and 2 are only available for estimation methods
%          3,4, and 6
%FixParams - Fix parameters. A one by four array of items that contains
%          the following information.
%Fixz      - 0 Don't fix z at all
%          - -1 Fix z if an initial optimization run using EstMethod=2
%          - 1 Partial fix of z.  Fix for the average value
%FixD      - 0 Don't fix D at all
%          - -1 Fix D if an initial optimization run using EstMethod=2
%          - 1 Partial fix of D. Fix for the average value
%FixAddBias- 0 Don't fix the additive bias at all
%          - -1 Fix the additive bias first before calculating the
%          multiplicative bias
%          - 1 Partial fix of the additive bias.  Fix for the average value
%FixMultBias- 0 Don't fix the multiplicative bias at all
%          - -1 Fix the multiplicative bias first before calculating the
%          multiplicative bias
%          - 1 Partial fix of multiplicative bias.  Fix for the average
%          value
%OptParms  - A row vector containing the optimization parameters.  This
%vector consists of the following fields:
%       Coverge - The converge value (difference between successive f
%       values) (default 1e6)
%       MaxIter - The maximum number of iterations for the procedure
%       (default 1000)
%       InitialType - The scheme used for the initial solution
%           - 0 Use the values from the average solution and no initial
%           bias (e.g., bias of 0 for additive, 1 for multiplicative)
%           - 1 Generate initial values from uniform distribution.
%              If 0 then use starting solution.  If 1 then use 
%           - 2 Calculate sample posterior distribution (NOT YET
%           IMPLEMENTED)
%MissingVal - The indicator for a missing value boundary of max(abs-1)
%OptLevel   - 0 if use only function value
%           - 1 if use first order derivatives
%DMax      - The maximum value of D
%IEMax     - The maximum value of the item easiness IE
%DPrior    - Prior guess for value D
%Outputs (if not included in the model then return all 1s
%z   - A continuous m*1 answer key vector
%D   - An n*1 vector of user competencies
%Bias - The model bias
%    - if EstMethod=3 then = bz - A continuous n*1 scale varible 
%    - If EstMethod=4 then = Diff - A continuous m*1 vector of Rasch item diffs.
%MaxCrit  - A maximization criteria for goodness of fit.
%LLPartial - A (3*m) matrix of partial likelihood values.  The first row
%contains the actual likelihood value, the second the value for the integer
%below the value and the third the value for the integer above the value.

  [n,m]=size(X);
  MaxCrit=0;
  if ~exist('DMax','var')||isempty(DMax)==true
    DMax=inf;
  end
  if ~exist('IEMax','var')||isempty(IEMax)==true
    IEMax=inf;
  end
  
  Fixz=FixParams(1);FixD=FixParams(2);
  FixAddBias=FixParams(3);FixMultBias=FixParams(4);
  %Cannot fix both additive bias and multiplicative bias values
  if (FixAddBias~=0)&&(FixMultBias~=0)
      Exception = MException('InputError:BiasFix',...
         'Only one type of bias can be fixed.  Both additive bias and multiplicative bias cannot be fixed together');
      throw(Exception); 
  end
  
  Converge=OptParams(1);
  MaxIter=OptParams(2);
  InitialType=OptParams(3);
 
  P=+~(X==MissingVal);
  
  %If no items for a question or user then add a question based on a
  %pseudo-Bayesian prior
  SumZ=sum(P,1);
  SumZ2=sum(P,2);
  if (~isempty(find(SumZ==0)))||(~isempty(find(SumZ2==0)))
    AddLine=true;
    n=n+1;
    X=[X;SumZ];
    P=[P;ones(1,m)];
  else
    AddLine=false;
  end
 
  if ~exist('OptLevel','var')
    OptLevel=0;
  end
  
  if (EstMethod==1)
    %Minimum residual factor analysis
    [CorrMatrix] = CalcSimilarity(X,P,[1,3]);
    if sum(sum(isnan(CorrMatrix)))>0
      ErrorText='Badly formed correlation matrix'
    else
      %Use correlation to estimate the initial competencies
      [D,Resid] = ResidualFA(CorrMatrix,1,1e-5); 
    end
    QE=ones(1,m);
  else
    if DMax==inf
      DMax=-1;
    end
    if IEMax==inf
      IEMax=-1;
    end
    if InitialType==0
      if exist('DPrior','var')
        D=ones(n,1).*DPrior;
      else
        D=ones(n,1);
      end 
    else
      %Find information on the size of the range
      MinX=X;
      MinX(find(X==MissingVal))=max(max(X));
      MaxX=X;
      MaxX(find(X==MissingVal))=min(min(X));  
      MinVal=min(min(MinX));
      MaxVal=max(max(MaxX));
      %Sample D from 1 to DMax (if not set then assume a maximum of 10)
      switch EstMethod
        case 0
          D=ones(n,1);
        case {2,3,4,5,6}
          if DMax==-1
            RDMax=10;
          else
            RDMax=DMax;
          end
          D=rand(n,1).*RDMax;
      end
    end
  end
  
  %The factor analysis method cannot fit additional parameters, so these
  %parameters are left at their default values.
  if (EstMethod==0)||(EstMethod==1)||(InitialType==0)
    %Set the initial parameters to base values
    QE=ones(1,m);
    Num=sum((D*ones(1,m).*X.*P),1);
    Denom=sum((D*ones(1,m).*P),1);
    Denom=max(Denom,1);
    z=Num./Denom;
  else
    %Sample IE from 1 to DMax (if not set then assume a maximum of 10)
    switch EstMethod
      case {2,6}
        QE=ones(1,m);
      case {3,4,5,6}
        if IEMax==-1
          RIEMax=10;
        else
          RIEMax=IEMax;
        end
      QE=rand(1,m).*RIEMax;
    end
    %Sample z from this range
    z=MinVal+rand(1,m).*(MaxVal-MinVal);
  end
  
  %If estimation method is 0 then the existing z is irrelevant, otherwise
  %if fixing z then create z with the ContinuousCCT 
  if EstMethod==0||EstMethod==1
    HasExistingz=true;
    HasExistingD=true;
    zPre=z;DPre=D;
  else
    if Fixz~=0
      %We create the initial z
      HasExistingz=true;
      if FixD~=0
        [zPre,DPre] = ContinuousCCT3(X,2,0,[0,0,0,0],OptParams,MissingVal,OptLevel,DMax,IEMax);
        HasExistingD=true;
        if FixD==1
          %Find the closed value to the median and update Fixed z to be this
          %value
          [V,I]=sort(abs(median(DPre)-DPre));
          FixD=I(1);
          DPre=DPre(FixD);
        end
      else
        [zPre] = ContinuousCCT3(X,2,0,[0,0,0,0],OptParams,MissingVal,OptLevel,DMax,IEMax);
        HasExistingD=false;
      end
      %Setup z depending on whether partially or fully fixed
      if Fixz==1
        %Find the closed value to the mean and update Fixed z to be this
        %value
        [V,I]=sort(abs(median(zPre)-zPre));
        Fixz=I(1);
        zPre=zPre(Fixz);
      end
    else
      HasExistingz=false;
      HasExistingD=false;
    end
  end
  
  if (EstMethod==1)||(InitialType==0)
     %Set inital values of bias and QE
    BiasAdd=zeros(n,1);
    BiasMult=ones(n,1);   %Row of additive biases and row of multiplicative biases
  else
    %Set random biases, but only if they can be fit.  Biases are random
    %withing range.  The additive bias range is from [-RangeX/2 to +RangeX/2) and
    %the multiplicative bias is from [0.5 to 2]
    switch BiasType
      case {0,2}
        %No additive bias
        BiasAdd=zeros(n,1);
      case {1,3}
        BiasAdd=rand(n,1)*(MaxVal-MinVal)-((MaxVal-MinVal)/2);
    end
    switch BiasType
      case {0,1}
        %No multiplicative bias
        BiasMult=ones(n,1);
      case {2,3}
        %Create an n*2 matrix and have one column containing the random
        %multiplication factor.  The scale assignments determine whether
        %this factor is or is not a recipricol.
        ScaleMatrix=ones(n,2);
        AssignIndexes=[1:n]+floor(rand(n,1)*2)'*n;
        ScaleMatrix(AssignIndexes)=rand(n,1)+1;
        BiasMult=ScaleMatrix(:,1)./ScaleMatrix(:,2);
    end      
  end  

  if (EstMethod==1)
    %The bias is not implemented for factor analysis, so use default values
    Bias=[BiasAdd,BiasMult];
  else
    %The initial values of competency and answer key
    if HasExistingz==1
      if Fixz>0
        Initialx=[z(1:Fixz-1),z(Fixz+1:m)]';
      else
        Initialx=[];
      end
    else
      Initialx=(z');
    end 
    
    if HasExistingD==false;
      Initialx=[Initialx;D];
    else
      %Run with partial fix
      if FixD>0  
        Initialx=[Initialx;D(1:FixD-1);D(FixD+1:n)];
      end
    end
    
    %Add bias variables depending on implemented bias
    RunFixedBias=false;
    BiasRunType=BiasType; %Run initially as either additive or multiplicative bias
    switch BiasType
      case 1
        Initialx=[Initialx;BiasAdd];
      case 2
        Initialx=[Initialx;BiasMult];   
      case 3
        %For a bias type of 3, if fixed bias then there are two runs, one for
        %the bias to be fixed and the second for the "opposite" bias.
        %Cannot fix both additive and multiplicative bias
        if FixAddBias~=0
          Initialx=[Initialx;BiasAdd];
          x2=BiasMult;
          RunFixedBias=true;
          BiasRunType=1;
        elseif FixMultBias~=0
          %Firstly fix the multiplicative bias
          Initialx=[Initialx;BiasMult];
          x2=BiasAdd;
          RunFixedBias=true;
          BiasRunType=2;
        else
          %None of the biases are fixed
          Initialx=[Initialx;BiasAdd;BiasMult];
        end
    end
    
    %Add question easyness parameters
    switch EstMethod
      case {0,1,2,6}
        HasQE=false;
      case {3,4,5}
        HasQE=true;
        Initialx=[Initialx;QE'];
    end
    
    %The additional parameter is the optimization level
    switch OptLevel
    case 0
      options = optimset('GradObj','off','Hessian','off','Display','off');
      if HasExistingz==true
        if HasExistingD==true
          f = @(x)CCCTMin0(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0],zPre,DPre);
        else
          f = @(x)CCCTMin0(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0],zPre);          
        end
      else
        f = @(x)CCCTMin0(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0]);
      end
    case 1
      options = optimset('GradObj','on','Hessian','off','Display','off');
      if HasExistingz==true
        if HasExistingD==true
          f = @(x)CCCTMin1(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0],zPre,DPre);
        else
          f = @(x)CCCTMin1(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0],zPre);
        end
      else
        f = @(x)CCCTMin1(x,X,P,EstMethod,BiasRunType,[Fixz,FixD,0,0]);       
      end
    case 2
      ExceptionNI = MException('ContinuousCCT3:HessianSearch','This feature is not yet implemented');
      throw(ExceptionNI);
      %options = optimset('GradObj','on','Hessian','on','Display','off');
      %f = @(x)CCCTMin2(x,X);
    end
    
    if isempty(Initialx)==false
      if (DMax>0)||(IEMax>0)
        %Constrain the competencies (and the easinesses for no 5).  Start
        %with D and z
        if HasExistingz==true
          if Fixz>0
            %Minimum and maximum values where one item is removed
            MinValues=ones(m-1,1)*-Inf;
            MaxValues=ones(m-1,1)*Inf;            
          else
            MinValues=[];MaxValues=[];
          end
        else
          %Constrain values for both D and for z
          MinValues=ones(m,1)*-Inf;
          MaxValues=ones(m,1)*Inf;
        end
        if HasExistingD==false
          MinValues=[MinValues;zeros(n,1)];
          if DMax>0
            MaxValues=[MaxValues;ones(n,1).*DMax];
          else
            MaxValues=[MaxValues;ones(n,1).*Inf];
          end
        elseif (HasExistingD==true&&FixD>0)
          MinValues=[MinValues;zeros(n-1,1)];
          if DMax>0
            MaxValues=[MaxValues;ones(n-1,1).*DMax];
          else
            MaxValues=[MaxValues;ones(n-1,1).*Inf];
          end          
        end
        switch BiasType
        case {1,2,3}
          MinValues=[MinValues;ones(n,1)*-Inf];
          MaxValues=[MaxValues;ones(n,1)*Inf];
        end
        %If free ranging bias of type 3 then both additive and
        %multiplicative items, so 2*n items
        if (BiasType==3)&&(FixAddBias==0)&&(FixMultBias==0)
          MinValues=[MinValues;ones(n,1)*-Inf];
          MaxValues=[MaxValues;ones(n,1)*Inf];            
        end
        if (HasQE==true)
          MinValues=[MinValues;zeros(m,1)];
          if IEMax>0
            MaxValues=[MaxValues;ones(m,1).*IEMax];
          else
            MaxValues=[MaxValues;ones(m,1).*inf];        
          end
        end
        [x,MinVal] = fmincon(f,Initialx,[],[],[],[],MinValues,MaxValues,[],options);
      else
        %Run the unconstrained version of the algorithm
        [x,MinVal] = fminunc(f,Initialx,options);
      end
    end
      
    if HasExistingz==true;
      if Fixz>0
        %One value fixed, so slot in at the correct position
        z=[x(1:Fixz-1);zPre;x(Fixz:m-1)]';
        VarCount=m-1;
      else
        z=zPre;
        VarCount=0;
      end
    else
      z=x(1:m)';
      VarCount=m;
    end
    
    if HasExistingD==true
      if FixD>0
        %One value fixed, so slot in at the correct position
        D=[x(VarCount+1:VarCount+FixD-1);DPre;x(VarCount+FixD:VarCount+n-1)];
        VarCount=VarCount+n-1;
      else
        D=DPre;
      end
    else
      D=x(VarCount+1:VarCount+n);
      VarCount=VarCount+n;
    end

    switch BiasType
      case 0
        %No bias
        Bias=[zeros(n,1),ones(n,1)];
      case 1
        %Additive bias
        Bias=[x(VarCount+1:VarCount+n),ones(n,1)];
        VarCount=VarCount+n;
      case 2
        %Multiplicative bias
        Bias=[zeros(n,1),x(VarCount+1:VarCount+n)];
        VarCount=VarCount+n;
      case 3
        %If fixed bias then save temporary bias for later optimization.
        %N.B. Only one of FixedAddBias and MultAddBias can be different
        %from 0
        Bias=[];
        if FixAddBias==0&&FixMultBias==0
          Bias=[x(VarCount+1:VarCount+n),x(VarCount+n+1:VarCount+2*n)];
          VarCount=VarCount+2*n;
        else
          BiasCol=x(VarCount+1:VarCount+n);
          VarCount=VarCount+n;
          [V,I]=sort(abs(median(BiasCol)-BiasCol));
          if FixAddBias>0 
            FixAddBias=I(1);
            BiasCol=BiasCol(FixAddBias);
          elseif FixMultBias>0
            FixMultBias=I(1);
            BiasCol=BiasCol(FixMultBias);
          end
        end       
    end
    if (HasQE==false)
      QE=ones(1,m);
    else
      %Question easyness model
      QE=x(VarCount+1:VarCount+m)';
    end
  end
  
  %If on part of the bias has been fixed then rerun with the main
  %parameters and the bias not fixed.  Only fixing the initial bias, which
  %does not need to be bounded.
  if RunFixedBias==true
    %if only partial fix then fix on the average value
    if FixAddBias>0
      %x2 is the multiplicative bias.  Add all additive bias values - fixed
      %value first
      x2=[BiasAdd(1:FixAddBias-1);BiasAdd(FixAddBias+1:n);x2];
    end
    if FixMultBias>0
      %x2 is the additive bias.  Add all multiplicative bias values - fixed
      %bias value first
      x2=[x2;BiasMult(1:FixMultBias-1);BiasMult(FixMultBias+1:n)];
    end
    f = @(x)CCCTMin1(x,X,P,EstMethod,BiasType,[-1,-1,FixAddBias,FixMultBias],z,D,BiasCol,QE);
    [x,MinVal] = fminunc(f,x2,options);
    %Add the bias depending on the bias type
    switch FixAddBias
      case 0
        %No fixing of  additive bias
      case -1
        %Additive bias is ficed annd multiplicative bias is fixed at the
        %second stage
        Bias=[BiasCol,x];
      otherwise
        Bias=[[x(1:FixAddBias-1);BiasCol;x(FixAddBias:n-1)],[x(n:2*n-1)]];
    end
    switch FixMultBias
      case 0
        %No fixing of the multiplicative bias
      case -1
        %Multiplicative bias is fixed
        Bias=[x,BiasCol]; 
      otherwise
        Bias=[[x(1:n)],[x(n+1:n+FixMultBias-1);BiasCol;x(n+FixMultBias:2*n-1)]];        
    end
  end
  
  %Remove the additional value of X
  if AddLine==true
    n=n-1;
    X=X(1:n,:);
    P=P(1:n,:);
    D=D(1:n,:);
    Bias=Bias(1:n,:);
  end
  
   %Calculate the criterion value
  switch EstMethod
    case 1
      %Calculate the residual from the VAF
      MeanVal=mean(mean(CorrMatrix));
      MaxCrit=1-(ssq(Resid)./ssq(CorrMatrix-MeanVal));
      %Weight using the number of items (need this to make it consistant
      %for the clusterwise estimation procedure
      MaxCrit=MaxCrit.*100;
      LLPartial=zeros(3,m);
    case {0,2,3,4,5}
      %Calculate the inner term for the bias
      InnerTerm=(X-(Bias(:,1)*ones(1,m))-Bias(:,2)*z); 
      
      switch EstMethod
        case {0,2,4}
          %Calculate the maximum log likelihood value
          Part1=P.*(log(((D*QE)./(2*pi)).^0.5));
          Part2=P.*((-D*QE).*(InnerTerm.^2)./2);
          MaxCrit=sum(sum(Part1))+sum(sum(Part2));
        case 3
          Ratio=(D*QE)./((D*ones(1,m))+(ones(n,1)*QE));
          Part1=log((Ratio./(2*pi)).^0.5);
          Part2=P.*-Ratio.*(InnerTerm.^2)./2;
          MaxCrit=sum(sum(Part1))+sum(sum(Part2));         
        case 5
          Part1=P.*(log(((D*ones(1,m)+ones(n,1)*QE)./(2*pi)).^0.5));
          Part2=P.*(-(D*ones(1,m)+ones(n,1)*QE).*(InnerTerm.^2)./2);
          MaxCrit=sum(sum(Part1))+sum(sum(Part2));            
      end
          
      %Calculate the partial log likelihoods
      LLPartial=zeros(3,m);
      for j=1:m
        zval=z(j);
        %Store z, the lower bound and the upper bound
        zAll=[zval,fix(zval),fix(zval+1)];
        QEAll=QE(j)*ones(1,3);
        InnerTerm=(X(:,j)*ones(1,3)-(Bias(:,1)*ones(1,3))-Bias(:,2)*zAll);

        %Estimate partial log likelihoods
        switch EstMethod
        case {0,2,4}
          Part1=(P(:,j)*ones(1,3)).*(log(((D*QEAll)./(2*pi)).^0.5));
          Part2=(P(:,j)*ones(1,3)).*(-D*QEAll).*(((InnerTerm).^2)./2);
          LLPartial(:,j)=(sum(Part1,1)+sum(Part2,1))';
        case 3
          Part1=(P(:,j)*ones(1,3)).*(log((((D*ones(1,3)).*(ones(n,1)*QEAll))./(((D*ones(1,3))+(ones(n,1)*QEAll))*2*pi)).^0.5));
          Part2=(P(:,j)*ones(1,3)).*((-((D*ones(1,3)).*(ones(n,1)*QEAll))).*((X(:,j)*ones(1,3)-ones(n,1)*zAll).^2)./(2*((D*ones(1,3))+(ones(n,1)*QEAll))));
          LLPartial(:,j)=(sum(Part1,1)+sum(Part2,1))';        
        case 5
          Part1=(P(:,j)*ones(1,3)).*(log(((D*ones(1,3)+ones(n,1)*QEAll)./(2*pi)).^0.5));
          Part2=(P(:,j)*ones(1,3)).*(-(D*ones(1,3)+ones(n,1)*QEAll).*((X(:,j)*ones(1,3)-ones(n,1)*zAll).^2)./2);
          LLPartial(:,j)=(sum(Part1,1)+sum(Part2,1))';
        end

      end 
    case 6
      Part1=P.*(log((1./(ones(n,1)*z)).*(((D*ones(1,m))./(2*pi)).^0.5)));
      Part2=P.*((-D*ones(1,m)).*((X-(ones(n,1)*z)).^2)./(2.*ones(n,1)*(z.^2)));
      MaxCrit=sum(sum(Part1))+sum(sum(Part2));
      %Calculate the partial log likelihoods
      LLPartial=zeros(3,m);
      for j=1:m
        zval=z(j);
        %Store z, the lower bound and the upper bound
        zAll=[zval,fix(zval),fix(zval+1)];
        Part1=(P(:,j)*ones(1,3)).*(log((1./(ones(n,1)*zAll)).*(((D*ones(1,3))./(2*pi)).^0.5)));
        Part2=(P(:,j)*ones(1,3)).*((-D*ones(1,3)).*((X(:,j)*ones(1,3)-(ones(n,1)*zAll)).^2)./(2.*ones(n,1)*(zAll.^2)));
        LLPartial(:,j)=(sum(Part1,1)+sum(Part2,1))';
      end
    
  end



