%The first experiment for the web search and data mining conference

AllResults=[];
MinScale=0.5;
OverallRun=0;

for NoItems=50:50:250
  for NoUsers=50:50:250
    for Scale=5:10
      Range=Scale-1;
      Centre=1+(Range/2);
      for TrueDist=1:2
        for MissingPC=0:10:90
          for Scheme=1:5
            for DMax=10:10
              for BiasAdd=0:0.25:1
                for BiasMult=0:0.25:1
                  OverallRun=OverallRun+1;
                  if mod(OverallRun,10)==0
                    OverallRun
                  end
                  Results=[1,NoItems,NoUsers,Scale,TrueDist,MissingPC,Scheme,BiasAdd,BiasMult];
                  %First randomly select true review scores
                  if TrueDist==1
                    %Sample from normal distribution with mean at the center
                    %point and with 1 standard devation = 1/6 range
                    z = norminv(rand(1,NoItems),Centre,Range/5);
                  else
                    %Sample from uniform distribution
                    z=(rand(1,NoItems).*Range)+1;
                  end
                  %Determine latent competencies for users
                  Mind=(Range/3)^(-2);
                  Midd=(Range/6)^(-2);
                  Maxd=(Range/9)^(-2);
                  switch Scheme
                  case 1
                    %Select all users to have the average competancy
                    D=ones(NoUsers,1).*Midd;
                  case 2
                    %Random competencies between min and max
                    D=Mind+rand(NoUsers,1).*(Maxd-Mind);
                  case 3
                    %75% competent and 25% not competent
                    IsComp=rand(NoUsers,1)>0.25;
                  case 4
                    %50% competent and 50% not competent
                    IsComp=rand(NoUsers,1)>0.5;
                  case 5 
                    %25% competent and 75% not competent
                    IsComp=rand(NoUsers,1)>0.75;              
                  end
                  switch Scheme
                    case {3,4,5}
                    %Users competent if one and not competent if 0
                    D=IsComp.*Maxd+(1-IsComp).*Mind;
                  end
                  %Additive biases standard deviation up to 1/6 of range
                  if BiasAdd>0
                    AddBiases=norminv(rand(NoUsers,1),0,Range.*BiasAdd/6);
                  else
                    AddBiases=zeros(NoUsers,1);
                  end
                  %Multiplicative biases scalar on the user
                  if BiasMult>0
                    MultBiases=norminv(rand(NoUsers,1),1,BiasMult/6);
                  else
                    MultBiases=ones(NoUsers,1);
                  end
                  %Now sample an answer key given the competency and the true
                  %score
                  %Sample an error matrix based on competencies
                  Error=zeros(NoUsers,NoItems);
                  for i=1:NoUsers
                    P=rand(1,NoItems);
                    Error(i,:) = norminv(P,0,(D(i)^(-0.5)));
                  end
                  %Add the biases to the base score
                  X=(ones(NoUsers,1)*z).*(MultBiases*ones(1,NoItems))+(AddBiases*ones(1,NoItems))
                  %Add the error to the actual values of the items
                  X=X+Error;
                  X=round(X);
                  X=min(max(1,X),Scale);   %Ensure in bounds
                  %Replace any missing data by -1
                  IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                  AllAssigned=isempty(find(sum(1-IsMissing,1)==0))&&isempty(find(sum(1-IsMissing,2)==0));
                  while (AllAssigned==0)
                    IsMissing=rand(NoUsers,NoItems)<(MissingPC/100); 
                    [IsMissing,AllAssigned]=FixMissing(IsMissing,1000);
                  end
                  X=-IsMissing+(1-IsMissing).*X;

                  %Now run continuous cultural consensus theory
                  [z0,D0,OP3,MaxCrit] = ContinuousCCT(X,0,1e-6,1000,-1,DMax,Midd);
                  [z2a,D2a,OP32a,MaxCrit,LLPartial] = ContinuousCCT(X,2,1e-6,1000,-1,DMax,Midd);
                  [IC2a] = InformationCriteria(MaxCrit,NoItems+NoUsers,sum(sum(1-IsMissing)));
                  [z3a,D3a,OP33a,MaxCrit,LLPartial] = ContinuousCCT(X,3,1e-6,1000,-1,DMax,Midd);
                  [IC3a] = InformationCriteria(MaxCrit,NoItems+NoUsers,sum(sum(1-IsMissing)));
                  [z4a,D4a,OP34a,MaxCrit,LLPartial] = ContinuousCCT(X,4,1e-6,1000,-1,DMax,Midd);
                  [IC4a] = InformationCriteria(MaxCrit,NoItems+(2*NoUsers),sum(sum(1-IsMissing)));
                  [z2b,D2b,OP32b,MaxCrit,LLPartial] = ContinuousCCT2(X,2,1e-6,1000,-1,DMax,Midd);
                  [IC2b] = InformationCriteria(MaxCrit,NoItems+NoUsers,sum(sum(1-IsMissing)));
                  [z3b,D3b,OP33b,MaxCrit,LLPartial] = ContinuousCCT2(X,3,1e-6,1000,-1,DMax,Midd);
                  [IC3b] = InformationCriteria(MaxCrit,NoItems+NoUsers,sum(sum(1-IsMissing)));
                  [z4b,D4b,OP34b,MaxCrit,LLPartial] = ContinuousCCT2(X,4,1e-6,1000,-1,DMax,Midd);
                  [IC4b] = InformationCriteria(MaxCrit,NoItems+(2*NoUsers),sum(sum(1-IsMissing)));
                  Results2=zeros(1,23);

                  %Calculate the MSE and MAE between Ds for all models
                  Results2(1)=sum((D-D2a).^2)./NoUsers;
                  Results2(2)=sum((D-D3a).^2)./NoUsers;
                  Results2(3)=sum((D-D4a).^2)./NoUsers;
                  Results2(4)=sum((D-D2b).^2)./NoUsers;
                  Results2(5)=sum((D-D3b).^2)./NoUsers;
                  Results2(6)=sum((D-D4b).^2)./NoUsers;
                  %Now calculate the accuracy of z
                  Results2(7)=sum((z-z0).^2)./NoItems;
                  Results2(8)=sum((z-z2a).^2)./NoItems;
                  Results2(9)=sum((z-z3a).^2)./NoItems;
                  Results2(10)=sum((z-z4a).^2)./NoItems;
                  Results2(11)=sum((z-z2b).^2)./NoItems;
                  Results2(12)=sum((z-z3b).^2)./NoItems;
                  Results2(13)=sum((z-z4b).^2)./NoItems;
                  %Now calculate the actual biases
                  Results2(14)=sum((MultBiases-OP33a).^2)./NoItems;
                  Results2(15)=sum((AddBiases-OP34a).^2)./NoItems; 
                  Results2(16)=sum((MultBiases-OP33b).^2)./NoItems;
                  Results2(17)=sum((AddBiases-OP34b).^2)./NoItems; 

                  %Return the AIC,AICc, and BIC for the two models
                  Results2(18)=IC2a.LLHood;
                  Results2(19)=IC3a.LLHood;
                  Results2(20)=IC4a.LLHood;
                  Results2(21)=IC2b.LLHood;
                  Results2(22)=IC3b.LLHood;
                  Results2(23)=IC4b.LLHood;

                  NewResults=[Results,Results2];
                  AllResults=[AllResults;NewResults];
                  save 'C:\CCOut\BiasesNew.txt' NewResults -append -ascii;
                end
              end
            end
          end
        end
      end
    end
  end
end