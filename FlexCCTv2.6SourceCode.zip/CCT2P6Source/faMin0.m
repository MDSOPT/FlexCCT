function [f] = faMin0(x,R)
%fa2Min - Provides the function value and for the residual 
%factor analysis procedure
%Inputs
%x - The current value of the function parameters (F, but gone with Matlab
%notation)
%R - The source matrix
%Outputs
%f - The function value for x
%Version     Author            Date
%   0.10     Stephen France    04/01/2012

%Calculating nonzero function differences
DiffSq=(R-x*x').^2;
DiffSq=DiffSq-diag(diag(DiffSq));
f=sum(sum(DiffSq))./2;

end

