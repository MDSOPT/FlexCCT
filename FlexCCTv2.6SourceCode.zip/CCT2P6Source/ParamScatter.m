function varargout = ParamScatter(varargin)
% PARAMSCATTER MATLAB code for ParamScatter.fig
%      PARAMSCATTER, by itself, creates a new PARAMSCATTER or raises the existing
%      singleton*.
%
%      H = PARAMSCATTER returns the handle to a new PARAMSCATTER or the handle to
%      the existing singleton*.
%
%      PARAMSCATTER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PARAMSCATTER.M with the given input arguments.
%
%      PARAMSCATTER('Property','Value',...) creates a new PARAMSCATTER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ParamScatter_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ParamScatter_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ParamScatter

% Last Modified by GUIDE v2.5 04-Feb-2017 07:27:31

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ParamScatter_OpeningFcn, ...
                   'gui_OutputFcn',  @ParamScatter_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ParamScatter is made visible.
function ParamScatter_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ParamScatter (see VARARGIN)
try

  % Choose default command line output for Residual
  handles.output = hObject;

  % Update handles structure
  guidata(hObject, handles);

  %Set the icon to be the standard icon
  javaFrame = get(handle(hObject),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));

  %Fill up the number of clusters and available confidence intervals
  %Setup the number of clusters
  NoCultures=str2num(getappdata(0,'NoCultures'));
  for i=1:NoCultures
    ComboText{i} = num2str(i);
  end
  set(handles.cboCultureNo,'String',ComboText);
  set(handles.cboCultureNo,'Value',1);
  clear ComboText

  %Create the text for the combo boxes and also for the sub item/rater combo
  %boxes for the Y Axis
  ComboText{1}='z';
  ComboItemText{1}='z';

  ComboText{2}='d';
  ComboRaterText{1}='d';

  ComboText{3}='b(add)';
  ComboRaterText{2}='b(add)';

  ComboText{4}='b(mult)';
  ComboRaterText{3}='b(mult)';
  
  ComboText{5}='IE';
  ComboItemText{2}='IE';
 
  set(handles.cboXAxis,'String',ComboText);
  set(handles.cboXAxis,'Value',1);
  set(handles.cboYAxis,'String',ComboItemText);
  set(handles.cboYAxis,'Value',1);
  setappdata(0,'IsItemData',true);
  
  setappdata(0,'ComboText',ComboText);
  setappdata(0,'ComboItemText',ComboItemText);
  setappdata(0,'ComboRaterText',ComboRaterText);
  setappdata(0,'ScatterNames',getappdata(0,'ColHeaderAll'));
  
  % UIWAIT makes ConfidenceInterval wait for user response (see UIRESUME)
  % uiwait(handles.ConfidenceInterval);
  if strcmp(get(hObject,'Visible'),'off')
    PlotGraph(handles);
  end

catch err
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h); 
end


% --- Outputs from this function are returned to the command line.
function varargout = ParamScatter_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in cmdExit.
function cmdExit_Callback(hObject, eventdata, handles)
% hObject    handle to cmdExit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = MFquestdlg([0.3,0.5],'Are you sure that you would like to close the scatterplots pane?','FlexCCT Question','Yes','No','Yes');
switch selection
  case 'Yes',
  delete(gcf);
case 'No'
  return
end %switch

% --- Executes on button press in cmdSave.
function cmdSave_Callback(hObject, eventdata, handles)
% hObject    handle to cmdSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
  %get the filepath to save the file
  [FileName,FilePath]=uiputfile({'*.bmp;*.gif;*.jpg;*.png;*.tif;','All Image Files';...
          '*.*','All Files' },'Save Image',...
          'newfile.png');
  ExPath = [FilePath FileName];

  if(FileName~=0)
    %save the file in correct graphics format
    export_fig(handles.axes1, ExPath);
  end
catch err
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h); 
end

% --- Executes on button press in cmdUpdate.
function cmdUpdate_Callback(hObject, eventdata, handles)
% hObject    handle to cmdUpdate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
PlotGraph(handles)
 


function PlotGraph(handles)
try
  %Get residual information and culture information from the 
  Results=getappdata(0,'Results');
  NoCultures=getappdata(0,'NoCultures');
  CultureIndex = get(handles.cboCultureNo, 'Value');
  XParams = get(handles.cboXAxis,'String'); 
  XParamName = XParams{get(handles.cboXAxis,'Value')};
  YParams = get(handles.cboYAxis,'String'); 
  YParamName = YParams{get(handles.cboYAxis,'Value')};

  switch XParamName
    case 'z'
      XVector=Results.z{CultureIndex}';
    case 'd'
      XVector=Results.D{CultureIndex};
    case 'b(add)'
      XVector=Results.Bias{CultureIndex}(:,1);
    case 'b(mult)'
      XVector=Results.Bias{CultureIndex}(:,2);
    case 'IE'
      XVector=Results.QE{CultureIndex}';
  end
  switch YParamName
    case 'z'
      YVector=Results.z{CultureIndex}';
    case 'd'
      YVector=Results.D{CultureIndex};
    case 'b(add)'
      YVector=Results.Bias{CultureIndex}(:,1);
    case 'b(mult)'
      YVector=Results.Bias{CultureIndex}(:,2);
    case 'IE'
      YVector=Results.QE{CultureIndex}';
  end
  
  NoValues=size(XVector,1);
  if NoValues<100
    PointSize=20;LineSize=1.5;
  elseif NoValues<500
    PointSize=10;LineSize=1;
  else
    PointSize=5;LineSize=0.5;
  end
  
  scatter(handles.axes1,XVector,YVector,PointSize,'MarkerEdgeColor',[0 .5 .5],...
              'MarkerFaceColor',[0 .7 .7],...
              'LineWidth',LineSize);
  if (get(handles.chkLeastSquares, 'Value')==true)
    lsline;
  end
  xlabel([XParamName]);
  ylabel([YParamName]);
  
  %Add the x labels if specified
  if (get(handles.chkPlotNames, 'Value')==true)
    ScatterNames=getappdata(0,'ScatterNames');
    if (str2num(NoCultures)>1)&&(getappdata(0,'IsItemData')==false)
      ScatterNames=ScatterNames(Results.Indexes{CultureIndex});
    end
    XRange=handles.axes1.XLim(2)-handles.axes1.XLim(1);
    YRange=handles.axes1.YLim(2)-handles.axes1.YLim(1);
    dx = XRange/100; dy = YRange/100;
    text(XVector+dx,YVector+dy, ScatterNames);
  end
 
  title(['Scatter Plot: ',XParamName,' vs. ',YParamName]);
  hold off;
catch err
  h=errordlg(err.message,err.identifier); 
  javaFrame = get(handle(h),'JavaFrame');
  javaFrame.setFigureIcon(javax.swing.ImageIcon('icongui.png'));
  uiwait(h); 
end
% --- Executes on button press in chkPlotNames.
function chkPlotNames_Callback(hObject, eventdata, handles)
% hObject    handle to chkPlotNames (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkPlotNames


% --- Executes on selection change in cboYAxis.
function cboYAxis_Callback(hObject, eventdata, handles)
% hObject    handle to cboYAxis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboYAxis contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboYAxis


% --- Executes during object creation, after setting all properties.
function cboYAxis_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboYAxis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cboXAxis.
function cboXAxis_Callback(hObject, eventdata, handles)
% hObject    handle to cboXAxis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboXAxis contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboXAxis
  Params = get(handles.cboXAxis,'String'); 
  ParamName = Params{get(handles.cboXAxis,'Value')};
  
  if  (strcmp(ParamName,'z')==true|| strcmp(ParamName,'IE')==true)
    %If y-axis is currently rater then switch
    if (getappdata(0,'IsItemData')==false)
      %Dealing with items on columns
      set(handles.cboYAxis,'String', getappdata(0,'ComboItemText'));
      setappdata(0,'ScatterNames',getappdata(0,'ColHeaderAll'));
      setappdata(0,'IsItemData',true);
    end
  else
    %If y-axis is currently rater then switch
    if (getappdata(0,'IsItemData')==true)
      set(handles.cboYAxis,'String', getappdata(0,'ComboRaterText'));
      setappdata(0,'ScatterNames',getappdata(0,'RowHeaderAll'));
      setappdata(0,'IsItemData',false);
    end
  end
  
  set(handles.cboYAxis,'Value',1)
 

% --- Executes during object creation, after setting all properties.
function cboXAxis_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboXAxis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chkLeastSquares.
function chkLeastSquares_Callback(hObject, eventdata, handles)
% hObject    handle to chkLeastSquares (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkLeastSquares


% --- Executes on selection change in cboCultureNo.
function cboCultureNo_Callback(hObject, eventdata, handles)
% hObject    handle to cboCultureNo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cboCultureNo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cboCultureNo


% --- Executes during object creation, after setting all properties.
function cboCultureNo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cboCultureNo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% hObject    handle to ConfidenceInterval (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
selection =MFquestdlg([0.3,0.5],'Are you sure that you would like to close the scatterplots pane?','FlexCCT Question','Yes','No','Yes');
switch selection
case 'Yes',
delete(hObject);
case 'No'
return
end %switch
