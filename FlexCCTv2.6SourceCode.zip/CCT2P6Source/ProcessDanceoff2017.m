NoDatasets=376;
MinCluster=2;
MaxCluster=6;
Results=[];

Allz =csvread('C:\CCOut\DO\Base\Allz.csv');
AllD =csvread('C:\CCOut\DO\Base\AllD.csv');
AllBias=csvread('C:\CCOut\DO\Base\AllBias.csv');

AddBiasRuns=csvread('C:\CCOut\DO\RCSV\AddBiasRuns.csv');
MultBiasRuns=csvread('C:\CCOut\DO\RCSV\MultBiasRuns.csv');

for iData=1:NoDatasets
  try
    zName =strcat('C:\CCOut\DO\BaseR\z',num2str(round(iData)),'.csv');
    DName =strcat('C:\CCOut\DO\BaseR\D',num2str(round(iData)),'.csv');
    AddBiasName =strcat('C:\CCOut\DO\BaseR\AddBias',num2str(round(iData)),'.csv');
    MultBiasName =strcat('C:\CCOut\DO\BaseR\MultBias',num2str(round(iData)),'.csv');

    zEst=csvread(zName);
    DEst=csvread(DName);
    AddBiasEst=csvread(AddBiasName);
    MultBiasEst=csvread(MultBiasName);

    Time = zEst(2);
    zEst=zEst(3:size(zEst,1));
    DEst=DEst(3:size(DEst,1));
    AddBiasEst=AddBiasEst(3:size(AddBiasEst,1));
    MultBiasEst=MultBiasEst(3:size(MultBiasEst,1));
    NoItems=size(zEst,1);
    NoUsers=size(DEst,1);

    z=Allz(iData,1:NoItems)';
    D=AllD(1:NoUsers,iData);
    AddBias=AllBias(1:NoUsers,1+2*(iData-1));
    MultBias=AllBias(1:NoUsers,2*iData);

    zMSE=sum((z-zEst).^2,1)/NoItems;
    zMAE=sum(abs(z-zEst),1)/NoItems;
    zCorr=corr(z,zEst);
    DMSE=sum((D-DEst).^2,1)/NoUsers;
    DMAE=sum(abs(D-DEst),1)/NoUsers;
    DCorr=corr(D,DEst);



    if AddBiasRuns(iData,2)==0
      AddBiasMSE=0;
      AddBiasMAE=0;    
      AddBiasCorr=0;
    else
      AddBiasMSE=sum((AddBias-AddBiasEst).^2,1)/NoUsers;
      AddBiasMAE=sum(abs(AddBias-AddBiasEst),1)/NoUsers;
      AddBiasCorr=corr(AddBias,AddBiasEst);
    end
    if MultBiasRuns(iData,2)==0
      MultBiasMSE=0;
      MultBiasMAE=0;
      MultBiasCorr=0;
    else
      MultBiasMSE=sum((MultBias-MultBiasEst).^2,1)/NoUsers;
      MultBiasMAE=sum(abs(MultBias-MultBiasEst),1)/NoUsers; 
      MultBiasCorr=corr(MultBias,MultBiasEst);
    end
    ResultsInfo=[iData,-1,zMSE,zMAE,zCorr,DMSE,DMAE,DCorr,AddBiasMSE,AddBiasMAE,AddBiasCorr,MultBiasMSE,MultBiasMAE,MultBiasCorr,Time];
  catch
    ResultsInfo=[iData,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1];    
  end
    Results=[Results;ResultsInfo];
 end


clear iData NoDatasets  MinCluster MaxCluster Time zEst DEst AddBiasEst MultBiasEst z D AddBias MultBias zMSE zMAE DMSE DMAE AddBiasMSE AddBiasMAE MultBiasMSE MultBiasMAE
