This is version 2.5 of the FlexCCT software.  This software provides a toolkit to allow users to analyze sets of ratings.  The sotware has the following major features.
i) Analyze the number of ratings cultures in the data using scree plots
ii) Calculate rater paramters, such as competency, additive bias, and multiplicative bias.
iii) Calculate "better" aggregate ratings by adjusting ratings for bias and weighting ratings for user competency.
iv) Analyze individual item easiness/difficulty.
v) Implement a range of optimization algorithms.
vi) Allow users to set parameter identifiability settings.
vi) Calculate measures of reliability and consensus adjusted reliability.
vii) Export all results and graphs.
viii) Analyze model residuals.
xi) Create 2D scatterplots of parameters for raters and items.
x) Display a visual analysis of confidence intervals produced using jacknife and bootstrap techniques.
Copyright (C) 2017  Stephen L. France, Mayhar Sharif Vaghefi

This program is free software: you can redistribute it and/or modify  it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.