function [S] = CalcSimilarity(X,P,ParamArray)
%Calculates correlation like similarities between rows. Runs through multiple preprocessing steps
%defined in the ParamArray (details given in the code).  Then calculates
%the covariance matrix for the preprocessed X. 
%INPUTS
%X - the input data matrix (user * item)
%P - Indicator matrix (user * item) . 1 for a item and 0 for no item
%ParamArray -  a column vector of preprocessing parameters.  E.g. [1,3,-1]
%The paramater -1 signifies recalculation. (e.g., previous to recalculation
%any operation uses values from the last caluclated X (e.g. norm of the
%vector).  For example [1,3,-1] gives cosine and [1,-1,3,-1] would be
%incorrect, as X-XBar would be devided by std(X-XBar) not std(X).
%gives correlation and [3] gives a cosine similarity.
%OUTPUTS
%XOut - The output similarity
%Version 0.10 - Stephen France 09/18/2011
%Version 0.20 - Stephen France 05/23/2012  Update for cultural consensus

  [nX,mX]=size(X);
  TempX=X;
  ParamCount = size(ParamArray,2);
  Counter=1;
  while Counter<=ParamCount
    switch ParamArray(Counter)
      case -1
        %Recalculation
        X=TempX;
      case 1
        %Subtract row means
        TempX=TempX-(spmean(X,P,2)*ones(1,mX));
      case 2
        %Subtract column means
        TempX=TempX-(ones(nX,1)*spmean(X,P,1));
      case 3
        %Divide data by the row standard deviation
        TempX=TempX./(spstd(X,P,2)*ones(1,mX));
      case 4
        %Divide data by the column standard deviation
        TempX=TempX./(ones(nX,1)*spstd(X,P,1));
      case 5
        %Divide data by the row maximum
        TempX=TempX./(max(X.*P,[],2)*ones(1,mX));     
      case 6
        %Divide data by the column maximum
        TempX=TempX./(ones(nX,1)*max(X.*P,[],1));    
      case 7
        %Divide data by the row range
        TempX=TempX./(sprange(X,2)*ones(1,mX));     
      case 8
        %Divide data by the column range
        TempX=TempX./(ones(nX,1)*sprange(X,1));    
      case 9
        %Requires an additional parameter
        Counter=Counter+1;
        p=ParamArray(Counter);
        %Divide data by the row p-norm
        TempX=TempX./((sum(X.^p,2)).^(1/p)*ones(1,mX));     
      case 10
        Counter=Counter+1;
        %Requires an additional parameter
        p=ParamArray(Counter);
        %Divide data by the column p-norm
        X=X./(ones(nX,1)*(sum(X.^p,1)).^(1/p));
    end 
    TempX=TempX.*P;
    Counter=Counter+1;
  end
  %Automatic recalculation at end
  X=TempX;
  S=(1/mX).*(X*X');

end

