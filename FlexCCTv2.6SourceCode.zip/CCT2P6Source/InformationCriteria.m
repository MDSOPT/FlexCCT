function [IC] = InformationCriteria(LLHood,NoParams,NoSamples)
%Calculate the most common information criteria
%Inputs
%LLHood - The value of the log likelihood function
%NoParams - The number of model parameters
%NoSamples - The number of samples in the model
%Outputs
%IC - An information criteria structure containing the following
% AIC - The Alkaike information criteria
% CorAIC - The corrected Ailaike information criteria
% BIC - The Baysian information criterion

IC.LLHood=LLHood;
IC.AIC=2*NoParams-2*LLHood;
IC.CorAIC=IC.AIC+((2*NoParams*(NoParams+1))./(NoSamples-NoParams-1));
IC.BIC=-2*LLHood+NoParams*log(NoSamples);
end

