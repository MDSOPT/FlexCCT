function [AllResults,MSE,MAE] = RunCollaborative(X,MissingVal,PPParams,DistParams,WeightParams,FilterParams,HORuns,HOPercent,IsReplace)
%Runs the collaborative filtering algorithm.  Takes a set of review data
%and parameters.  Takes sets of holdout reviews and predicts review scores
%for these reviews.
%INPUTS
%X - Input matrix of reviews (user * item).  Review scores shold be > 0
%MissingVal - The value for missing data in the dataset
%PPParams - Preprocessing parameters (values given in PreProcessX)
%DistParams - Values of b1,b2,b3 for CreateDistances1
%WeightParams - Values of d2,d3,d4,d5,d6 for CalcWeights
%FilterParams - Currently just the value of k
%HORuns - The number of holdout runs
%HOPercent - The percentage of items taken as holdout sample items
%IsReplace - Sampling with replacement 1 Yes 0 No
%OUTPUTS
%Results - Results table.  Each row has holdout sample number, user,
% review, predicted value and value
%MSE - The mean squared error across all holdout samples
%MAE - The mean absolute error across all holdout samples
%Version 0.10 - Stephen France 09/18/2011

  AllResults=[];
  [NoUsers,NoItems]=size(X);
  %Firstly get the non missing indexes and values
  P=~(X==MissingVal);
  [I,J,Val]=find(X.*P);
  XIndexVal=[I,J,Val];
  ReviewCount=size(I,1);
  
  %Hold out samples tk
  HOReviewCount=floor(ReviewCount.*HOPercent./100);
  NHOReviewCount=ReviewCount-HOReviewCount;
  %If sampling without replacement, check maximum
  if (IsReplace == false) && (HOReviewCount*HORuns>ReviewCount)
    fprintf('Number of runs reduced as not enough reviews!\n');
    HOReviewCount = HOReviewCount*HORuns;
  end
  
  AllPerm=randperm(ReviewCount);
  %Cycle through each holdout sample
  for RunCounter=1:HORuns
    %Select the holdout items randomly
    if IsReplace == true
      %Sampling with replacement, take a different random permuatation of
      %items every iteration
      IndexesToTake=AllPerm(1:HOReviewCount);
      IndexesToLeave=AllPerm(HOReviewCount+1:ReviewCount);
      if RunCounter<HORuns
        AllPerm=randperm(ReviewCount);
      end
    else
      IndexesToTake=AllPerm((RunCounter-1)*HOReviewCount+1:RunCounter*HOReviewCount);
      %Remaining reviews should be every review not selected
      if RunCounter==1
        IndexesToLeave= AllPerm(RunCounter*HOReviewCount+1:ReviewCount);
      elseif (RunCounter*HOReviewCount==ReviewCount)
        IndexesToLeave=AllPerm(1:(RunCounter-1)*HOReviewCount);
      else
        IndexesToLeave=[AllPerm(1:(RunCounter-1)*HOReviewCount),AllPerm(RunCounter*HOReviewCount+1:ReviewCount)];
      end
    end
    
    %Configure the X,XHold,P,and PHold matrices as sparse matrics
    XHold=spconvert(XIndexVal(IndexesToTake,:));
    XCur=spconvert(XIndexVal(IndexesToLeave,:));
    PHold=~(XHold==0);
    PCur=~(XCur==0);
    
    %Preprocess X then calculate distance, nearest neighbors, and weights
    %N.B. Missing value is now 0 as matrices are sparse.
    XCurProc = PreProcessX(XCur,PCur,PPParams,0);
    %DistParams(1)=b1,DistParams(2)=b2,DistParams(3)=b3
    D = CreateSparseDistances1(XCurProc,PCur,DistParams(1),DistParams(2),DistParams(3))
    %Create complete neighborhood matrix (May redo for efficiency)
    %k is set to be the number of reviews - 1
    NN = LinearKNN(D,NoUsers-1);
    %Calculate weights between users based on distance/similarity between
    %users
    %WeightParams(1-5)=d2-d6
    Weights = CalcWeights(D,WeightParams(1),WeightParams(2),WeightParams(3),WeightParams(4),WeightParams(5));
    %Currently only one FilterParam, k!
    XPredict = UserFilter(XHold,XCur,PHold,PCur,NN,Weights,FilterParams(1));
    AllResults=[AllResults;[ones(HOReviewCount,1).*RunCounter,XPredict]];
  end
  
  %Calculate MSE and MAE
  ResultCount=size(AllResults,1);
  Diffs=AllResults(:,4)-AllResults(:,6);
  MSE=sum(Diffs.^2)./ResultCount;
  MAE=sum(abs(Diffs))./ResultCount;
end

