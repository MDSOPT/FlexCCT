function [TopIDs,TopRec] = TopList(UserIDs,ItemIDs,XUIRec,SubUserIDs,TopNo)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
  
  [n,m]=size(XUIRec);
 
  nSub=size(SubUserIDs,1);
  TopIDs=zeros(TopNo,nSub);
  TopRec=zeros(TopNo,nSub);
 
  for i=1:nSub
    UserID=SubUserIDs(i);
    %Calculate top 5 values and movie IDs
    [B,IX]=sort(XUIRec(UserID,:),'descend');
    TopRec(:,i)=B(1:TopNo);
    TopIDs(:,i)=ItemIDs(IX(1:TopNo));
    %Give text output for recommendations
    fprintf('recommendations for user %d:\n',UserID)
    for j=1:TopNo
      fprintf(' % d: %.4f\n',TopIDs(j,i),TopRec(j,i))
    end
  end




end

