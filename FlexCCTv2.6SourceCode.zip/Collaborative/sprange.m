function [RangeVals] = sprange(X,P,dim)
%Return mean values accounting for missing data
%Items with missing data are ignored
%INPUTS
%X - The input data (user * item)
%P - An indicator matrix of missing values 1 Present 0 Missing (user *
%item)
%dim - The dimension to aggregate on 
%OUTPUTS
%MeanVals - A vector of maximum values
%Version 0.10 - Stephen France 09/18/2011

  %Convert missing values to 0
  X2=X.*P;
  
  MaxVals=max(X2,[],dim);
  
  %Convert missing values to the maximum values
  X2=X2+(P-1).*(-(max(MaxVals)));
  
  MinVals=min(X2,[],dim);
  
  RangeVals=MaxVals-MinVals;
end

