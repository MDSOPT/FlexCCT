function [XUserFilm] = ContentFilter(XUserFilm,XFilmTerm,CutOff)
  
  

  %Calculates user scores for films
  XUserFilm=(+(XUserFilm>CutOff))*XFilmTerm;

end

