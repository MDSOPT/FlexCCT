function [Assoc] = RecAssoc(P,Mode)
%Calculates associations between items
% Inputs
% P is a n user * m item matrix instance matrix. P(ij) is 1 if user i has
% used/purchased item j and is 0 otherwise
% Mode - The mode for calculating the associations
% ItemCol - The item to create associations for
% 1 - Simple mode ((x&y)/x)
% 2 - Advanced mode
% Outputs
% Assoc - An m*m matrix for x.  Column i contains the associations for item
%Version 0.10 - Stephen France 09/24/2013
  P=full(P);
  [n,m]=size(P);
  %Calculate cross associations and self associations
  XY=P'*P;
  XX=repmat(diag(XY)',m,1);
 
  if (Mode==1)
    %Simple association
    Assoc=(XY./XX);  
  else
    %Advanced association
    NotXY=((1-P')*P)';
    NotXX=n-XX;
    Assoc=(XY./XX)./(NotXY./NotXX);
  end

end

