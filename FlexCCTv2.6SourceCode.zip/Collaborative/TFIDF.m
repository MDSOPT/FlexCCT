function [Out] = TFIDF(X,Mode)
%Calculates TF-IDF (TF*IDF) for each combination of item and term
%TF - Term frequency: The frequency that a term occurs in a documents
%INPUTS
%X - An n item * m term matrix of item-term occurence counts
%Mode 
%  1 - Basic TF , IDF is log(No
%  Documents/No of occurences) of term

  if ~exist('Mode','var')
    Mode=1;
  end  
    
  [n,m]=size(X);
  P=+(X>0);
  
  if Mode==1
    %N.B X is essentially the term frequency
    IDF=log(n./sum(P,1));
    Out=X.*repmat(IDF,n,1);
  end
  
  %Divide by the norm of each row vector
  Norm=(sum(Out.^2,2)).^0.5;
  Out=Out./(repmat(Norm,1,m));
end

