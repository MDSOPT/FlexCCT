function [D] = FastEuclid(X,P,IsUser,IsSquared,Divide)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
[n,m]=size(X);

if (IsUser==true)
  MIJ=(X.*P)*(X.*P)';
  Size=n;
else
  MIJ=(X.*P)'*(X.*P);
  Size=m;
end

MII=diag(MIJ)*ones(1,Size);
MJJ=MII';

D=MII+MJJ-2*MIJ;

if (IsSquared==false)
  D=D.^0.5;
end

D=D./Divide;

end

