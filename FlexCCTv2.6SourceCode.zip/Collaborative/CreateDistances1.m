function [D] = CreateDistances1(X,P,b1,b2,b3)
%Basic distance metric function with three simple parameters
%Implements Minkowski distance metric
%INPUTS
%X  - The transformed X matrix (user * item)
%P  - The binary instances of X (user * item)
%b1 - The weighting for the Jaccard distance
%b2 - The inner power p1 for Minkowski metric
%b3 - The outer power p2 for Minkowski metric
%OUTPUTS
%D - The (user * user) distance matrix
%Version 0.10 - Stephen France 09/18/2011
  
  [n,m]=size(X);
  I=zeros(1,n);
  
  D=zeros(n,n);
  
  for i=1:n-1
    i
    for j=i+1:n
      %Calculate distances by row
      In=I;
      In(i)=1;
      In(j)=-1;
      %Calculate differences between rows
      Diffs=(In*X).*P(i,:).*P(j,:); 
      D(i,j)=(sum(Diffs.^b2)).^b3;
    end
  end
  
  
  %Calculate the Jaccard distances
  D2=zeros(n,n);
  for i=1:n-1
    for j=i+1:n
      D2(i,j)=((+(P(i,:)&P(j,:)))*((+(P(i,:)&P(j,:)))'))./((+(P(i,:)|P(j,:)))*((+(P(i,:)|P(j,:)))'));
    end
  end
  
  D=D+b1.*D2;
  
  %Convert to a full symmetric distance matrix for simplicity
  D=(D+D')./2;
  
end

