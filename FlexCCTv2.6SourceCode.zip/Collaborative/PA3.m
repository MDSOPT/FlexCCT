%Runs the test for coursera programming assignment 3.
% 
% %User IDs are numbered as data rows.  Item IDs have to be found
% NoRuns=size(PA3Run,1);
% RowsCols=PA3Run;
% for i=1:NoRuns
%   RowsCols(i,2)=find(ItemIDs==RowsCols(i,2));
% end
% [RCPredict] = CFUser(XRate,RowsCols,30);

%Go back to original IDs
RCPredict(:,2)=PA3Run(:,2);

 for i=1:NoRuns
   fprintf('%d,%d,%.4f\n',RCPredict(i,1),RCPredict(i,2),RCPredict(i,3))
 end