function [XOut] = PreProcessX(X,P,ParamArray)
%Preprocesses the data matrix X.  Runs through multiple preprocessing steps
%defined in the ParamArray.  
%INPUTS
%X - the input data matrix (user * item)
%P - Indicator matrix (user * item) . 1 for a review and 0 for no review
%ParamArray -  a column vector of parameters.  Each parameter denotes a
%transformationR
%MissingVal - Indicator for the missing value. defaults to 0
%OUTPUTS
%XOut - The Preprocessed X
%Version 0.10 - Stephen France 09/18/2011

  [nX,mX]=size(X);
  ParamCount = length(ParamArray);
  Counter=1;
  while Counter<=ParamCount
    switch ParamArray(Counter)
      case 1
        %Subtract row means
        X=X-(spmean(X,P,2)*ones(1,mX));
      case 2
        %Subtract column means
        X=X-(ones(nX,1)*spmean(X,P,1));
      case 3
        %Divide data by the row standard deviation
        X=X./(spstd(X,P,2)*ones(1,mX));
      case 4
        %Divide data by the column standard deviation
        X=X./(ones(nX,1)*spstd(X,P,1));
      case 5
        %Divide data by the row maximum
        X=X./(max(X.*P,[],2)*ones(1,mX));     
      case 6
        %Divide data by the column maximum
        X=X./(ones(nX,1)*max(X.*P,[],1));    
      case 7
        %Divide data by the row range
        X=X./(sprange(X,2)*ones(1,mX));     
      case 8
        %Divide data by the column range
        X=X./(ones(nX,1)*sprange(X,1));    
      case 9
        %Requires an additional parameter
        Counter=Counter+1;
        p=ParamArray(Counter);
        %Divide data by the row p-norm
        X=X./((sum(X.^p,2)).^(1/p)*ones(1,mX));     
      case 10
        Counter=Counter+1;
        %Requires an additional parameter
        p=ParamArray(Counter);
        %Divide data by the column p-norm
        X=X./(ones(nX,1)*(sum(X.^p,1)).^(1/p));   
    end 
    X=X.*P;
    Counter=Counter+1;
  end
  XOut=X;

end

