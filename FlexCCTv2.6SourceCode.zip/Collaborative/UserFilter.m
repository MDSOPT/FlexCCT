function [XPredict] = UserFilter(XHold,X,PHold,P,NN,W,k)
%  UserFilter - Implement user based collaborative filtering algorithm
%  For each item in the holdout sample, find the k nearest neighbors
%  who have reviewed the item and then predict the review score
%  INPUTS
%  XHold - The value of the holdout sample items
%  X - The matrix of reviews (user * item)
%  PHold - A sparse matrix of reviews
%  P - A (possibly sparse indicator matrix) (user * item)
%  NN - The Nearest neighbors (we calculate all the nearest neighbors!)
%   (user * user - 1)
%  W - The matrix of weights (user * user)
%  k - The number of neighbors to select
%  OUTPUTS
%  XPredict - A matrix of review predictions. Rows of form [user i, item j,
%  real value, predicted value, rounded predicted value]
%  Version 1.00 - Stephen France 09/18/2011

  %Find the index of holdout samples i is users, j is 
  [I,J]=find(PHold==1);
  NNCount=size(NN,2);
  
  %Go through each holdout sample
  HOCount=size(J,1);
  %Results column 
  XPredict=[I,J,zeros(HOCount,3)];
  
  %Calculate mean scores for the users
  UserMeans=spmean(X,P,2);
  
  j=0;
  for HOCounter=1:HOCount
    i=I(HOCounter);
    %Indexes should be ordered by j
    Prevj=j;
    j=J(HOCounter);
    
    if Prevj~=j
    
      %Now match the list of users who have seen movie j
      try
        RIndexes=find(P(:,j));
        %If k>number of people seen the film then set min k
        mink=min(k,size(RIndexes,1));
      catch
        RIndexes=0; 
        mink=0;
      end
    end
    
    NNRow=NN(i,:);

    %Now match the two sets of indices
    %Possible scope for more efficient matching algorithm!!
    NNCounter = 1;
    FoundCount =0;

    %Adjusted NN - The neighbors who have seen film j
    AdjNN=zeros(k,1);
    while (FoundCount<mink) && (NNCounter<=NNCount)
      if ~isempty(find(RIndexes==NNRow(NNCounter)))
        %If isnan this means that the users didn't review any of the same
        %movies.  Discount the user and decrement the number of users
        if ~isnan(W(i,NNRow(NNCounter)))
          FoundCount=FoundCount+1;
          AdjNN(FoundCount)=NNRow(NNCounter);
        end
      end
      NNCounter=NNCounter+1;
    end
    
    %So now have the K nearest neighbors who have reviewed film j make
    %predictions
    AddSum = 0;
    WeightSum = 0;
    for FCounter=1:FoundCount
      CurUseri=AdjNN(FCounter);
      AddSum=AddSum+(X(CurUseri,j)-UserMeans(CurUseri)).*W(i,CurUseri);
      WeightSum=WeightSum + W(i,CurUseri);
    end
    XPredict(HOCounter,3)=XHold(i,j);
    XPredict(HOCounter,4)=UserMeans(i);
    if (FoundCount > 0)
      XPredict(HOCounter,4)=XPredict(HOCounter,4)+((AddSum./WeightSum)./FoundCount);
    end
    if isnan(XPredict(HOCounter,4))
      i  
    end
    XPredict(HOCounter,5)=round(XPredict(HOCounter,4));
  end
  

end

