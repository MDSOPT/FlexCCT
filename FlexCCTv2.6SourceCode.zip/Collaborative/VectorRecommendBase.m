%Ratings and Movietag are the imported 

% [SpRatings] = MakeSparseSeq(Ratings);
% XRate=spconvert(SpRatings);
% XTag=spconvert(MovieTag(:,3:5));
RecMode=2;
[FilmTag] = TFIDF(XTag,1);
[NoUsers,NoItems]=size(XRate);
P=(+(XRate>0));
%The user ratings of different films
if RecMode==1
  UserFilm=(+(XRate>=3.5));
else
  UserFilm=P.*(XRate-repmat(spmean(XRate,P,2),1,NoItems));
end
Indexes=find(sum(P,2)~=0);
UserFilm=UserFilm(Indexes,:);

% 
UserTag=UserFilm*FilmTag;
[NoTags]=size(UserTag,2);
%Normalize the user tag
Norm=(sum(UserTag.^2,2)).^0.5;
UserTag=UserTag./(repmat(Norm,1,NoTags));

%UserFilmCos=1-pdist2(UserTag,FilmTag,'cosine');
UserFilmTemp=UserTag*(FilmTag');
UserFilmCos=zeros(NoUsers,NoItems);
UserFilmCos(Indexes,:)=UserFilmTemp;
%Can only recommend film that users have not seen
UserFilmCos=UserFilmCos.*(1-P)+P*-100;

%So it can be exported as a csv file
UserFilmCos=full(UserFilmCos);

