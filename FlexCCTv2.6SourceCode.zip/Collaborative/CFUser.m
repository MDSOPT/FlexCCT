%User-user collaborative filtering as in Coursera Exercise 4
function [RCPredict] = UserCollaborative(XRate,RowsCols,NoUsers)
%UNTITLED5 Summary of this function goes here
  Penalty=-1000;   %Choose a large negative rating for user who hasn't seen the film
  %Detailed explanation goes here
  [n,m]=size(XRate);
  
  NoPredict=size(RowsCols,1);

  %Calculate correlation
  P=(+(XRate>0));
  UserMeans=spmean(XRate,P,2);
  XRate2=XRate-spmean(XRate,P,2)*ones(1,m);  %Mean center XRate
  %Users with no ratings produce a NaN as no mean
  XRate2(isnan(XRate2))=0;
  XRate2=XRate2.*P;
  
  XNorm=sum(XRate2.^2,2);
  XNorm=XNorm.^0.5;
  XNorm(XNorm==0)=1;         %Cannot divide by 0 norm!!!
  XRate2=XRate2./(XNorm*ones(1,m));
  Sim=(XRate2.*P)*(XRate2.*P)'; %Covariance measure
  UserI=eye(n);
  Sim=(1-UserI).*Sim+UserI.*Penalty;
  
  %Get list of most similar users
  %
  %SimUsers=IX(:,m-NoUsers+1:m);
  
  %Produce ratings for all films that have not been seen
  RCPredict=[RowsCols,zeros(NoPredict,1)];
  SimUsers=Sim(RowsCols(:,1),:);  %Find most similar users for each listed users
  PUsers=P(:,RowsCols(:,2))';  %Find all the users who have seen the specified films
  
  [B,IX] = sort(PUsers.*SimUsers+(1-PUsers).*Penalty,2); %Sort each row in order of siilarity
  %Find the top "NoUsers" users for each row to be predicted
  CUserIndexes=IX(:,n-NoUsers+1:n);
  CUserSim=B(:,n-NoUsers+1:n);
  %Get the mean values for the closest user.
  CUserMeans=UserMeans(CUserIndexes);
  
  for i=1:NoPredict
    Num=XRate(CUserIndexes(i,:),RowsCols(i,2))'-CUserMeans(i,:);
    Num=sum(Num.*CUserSim(i,:),2);
    Denom=sum(abs(CUserSim(i,:)),2);
    RCPredict(i,3)=UserMeans(RowsCols(i,1))+Num./Denom;
  end

end

