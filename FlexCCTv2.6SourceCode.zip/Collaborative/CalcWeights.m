function [W] = CalcWeights(D,d2,d3,d4,d5,d6)
%Creates weights based upon similarities for the collaborative filtering
%algorith. First converts the distances into similarities.  Then transforms
%the similarities using the transformation defined by nominal variable d2.
%INPUTS
%D - Distances (can be either user*user or item*item)
%d2 - The transformation scheme to use (descriptons given in switch)
%d3-d6 - The transformation parameters, dependent on d2
%OUTPUTS
%W - The output weights
%Version 0.10 - Stephen France 09/18/2011

S=max(max(D))-D; 

switch d2
  case 1
    %No transformation
    W=S;
  case 2
    %Linear transformation
    W=d3+d4.*S;
  case 3
    %Quadratic transformation
    W=d3+d4.*S+d4.*(S.^2);
  case 4
    %Cubic transformation
    W=d3+d4.*S+d4.*(S.^2)+d5.*(S.^2);
  case 5
    %Power transformation
    W=d3.*(S.^d4)+d5;
  case 6
    %Negative exponential transformation
    W=d3.*exp(-d4.*S)+d5;
  case 7
    %Logistic transformation
    W=d3+1./(1+exp(-(S-d4)./d5));    
end

