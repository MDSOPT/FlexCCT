function [NewX] = MakeSparseSeq(X)
%INPUT
%A sparse input matrix with three columns
%X(:,1) - Corresponds to rows
%X(:,2) - Corresponds to columns
%X(:,3) - Corrsponds to values
%Makes the rows and columns in sparse data sequential
 
 NewX=X;
 
 for Col=2:2
   XCol=X(:,Col);
   CurVal=1;
   Found=true;
   while Found==true
     CurIndexes=find(XCol>(CurVal-1));
     
     if isempty(CurIndexes)
       Found=false;
     else
       MinVal=min(XCol(CurIndexes));
       XCol(find(XCol==MinVal))=CurVal;
     end
     CurVal=CurVal+1;
   end
   NewX(:,Col)=XCol;
 end


end

