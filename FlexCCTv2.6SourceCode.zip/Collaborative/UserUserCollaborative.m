%User-user collaborative filtering as in Coursera Exercise 4
function [UIPredict] = UserCollaborative(XRate,UserItem,NoUsers)
%UNTITLED5 Summary of this function goes here
  
  %Detailed explanation goes here
  [n,m]=size(XRate);
  
  NoPredict=size(UserItem,1);

  %Calculate correlation
  P=(+(XRate>0));
  XRate=P.*(X-spmean(XRate,P,2));  %Mean center XRate
  XNorm=sum(XRate.^2,2);
  XNorm(XNorm==0)=1;         %Cannot divide by 0 norm!!!
  XRate=XRate./(XNorm*ones(1,m));
  Sim=(XRate.*P)*(XRate.*P)'; %Covariance measure
  
  %Get list of most similar users
  [B,IX] = sortrows(Sim);
  SimUsers=IX(:,m-NoUser+1:m);
  
  %Produce ratings for all films that have not been seen
  UIPredict=[UserItem,zeros(NoPredict,1)];
  SimUsers=UserItem(1,:)
  for i=1:NoPredict
    User=UserItem(1,:);
    Item=UserItem(2,:);
    
  end
  
  %Produce the required text output for the user-item predictions
  

end

