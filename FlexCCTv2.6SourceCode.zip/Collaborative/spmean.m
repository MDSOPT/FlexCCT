function [MeanVals] = spmean(X,P,dim)
%Return mean values accounting for missing data
%Items with missing data are ignored.  
%INPUTS
%X - The input data (user * item)
%P - An indicator matrix of missing values 1 Present 0 Missing (user *
%item)
%dim - The dimension to aggregate on 
%OUTPUTS
%MeanVals - A vector of mean values
%Version 0.10 - Stephen France 09/18/2011

  X2=X.*P;

  SSum=sum(X2,dim);
  
  %Get row and columns where x>0
  SCount=max(sum(P,dim),1);  %
  
  
  MeanVals=SSum./SCount;

end

