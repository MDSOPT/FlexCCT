  tic

  b2=2;
  b3=0.5;
  [n,m]=size(X);
  
  StartEnd=[]; 
  [row,col,v] = find(X);
  X2=[row,col,v];
  clear row col v
  CurStart = 1
  EndRow = size(X2,1);
  CurValue=X2(1,2);
  

  for i=2:EndRow
    if X2(i,2)~=CurValue
      StartEnd=[StartEnd;[CurStart,i-1]];
      CurValue=X2(i,2);
      CurStart = i;
    end  
  end
  
  SECount=size(StartEnd,1);
  D=zeros(n);
  
  
  for i=1:SECount
    StartRow=StartEnd(i,1);
    EndRow=StartEnd(i,2);
    for j=StartRow:EndRow-1
      for k=j+1:EndRow
        D(X2(j,1),X2(k,1))=D(X2(j,1),X2(k,1))+abs(X2(j,3)-X2(k,3))^b2;
      end
    end
  end
  
  D=(D+D')./2;
  D=D.^b3;
  
  M11=P*P';
  M10=P*(1+P')-2.*(M11);
  M01=(1+P)*(P')-2.*(M11);
  
  D2=(M10+M01)./(M11+M10+M01);
  D=D+b1.*D2;
  
  
  toc