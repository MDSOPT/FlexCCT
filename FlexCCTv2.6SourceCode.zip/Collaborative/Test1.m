%First test of collaborative filtering.  MBABeer with simple parameters

%Run simple version with default parameters and a correlation metric
%X=MBABeer;
%Mean center and normalize for correlation
PPParams=[1,9,2];
DistParams=[0.2,2,1];
%Weights=similarities.  Requires no parameters
WeightParams=[1,0,0,0,0];
%Set the value of k to be 5
FilterParams=5;
%Set -1 to be missing value, Set 10 runs each with holdout of 10% of the samples
%Do not sample with replacement
[AllResults,MSE,MAE,RunTimes] = RunCollaborativeTest(X2,0,PPParams,DistParams,WeightParams,FilterParams,10,10,true);
 






