function [StdVals] = spstd(X,P,dim)
%Returnstandard deviations accounting for missing data
%Items with missing data are ignored
%INPUTS
%X - The input data (user * item)
%P - An indicator matrix of missing values 1 Present 0 Missing (user *
%item)
%dim - The dimension to aggregate on 
%OUTPUTS
%StdVals - A vector of standard deviations
%Version 0.10 - Stephen France 09/18/2011

  X2=X.*P;

  SSum=sum(X2,dim);
  SSq=sum(X2.^2,dim);
  
  
  %Get row and columns where x>0
  SCount=sum(P==1,dim);
  
  MeanVals=SSum./SCount;
  
  StdVals=((SSq./SCount)-MeanVals.^2).^0.5;

end

