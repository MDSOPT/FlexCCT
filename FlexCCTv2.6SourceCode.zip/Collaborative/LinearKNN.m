function [NN] = LinearKNN(D,k)
%A simple linear search for k Nearest neighbors (not sure if function
%necessary!
%INPUTS
%D An upper triangular distance matrix
%k The number of neighbors for each item
%OUTPUTS
%NN an n*k matrix of nearest neighbor indexes
%Version 0.10 - Stephen France 09/18/2011

%Sorts columns of distances in columns
[B,IX] = sort(D,2);
NN=IX(2:k+1,:)';



