%Calculate distances for MovieLens and then use classical MDS

%Mean center and normalize for correlation
PPParams=[1,9,2];
DistParams=[0.2,2,1];
%Weights=similarities.  Requires no parameters
WeightParams=[1,0,0,0,0];
%Set the value of k to be 5
FilterParams=5;
%Set -1 to be missing value, Set 10 runs each with holdout of 10% of the samples
%Do not sample with replacement

P=~(XTake'==0);

XCurProc = PreProcessX(XTake',P,PPParams,0);
%DistParams(1)=b1,DistParams(2)=b2,DistParams(3)=b3
D = CreateSparseDistances1(XCurProc,P,DistParams(1),DistParams(2),DistParams(3));







